#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS additem;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (1, '2018-08-23', '1', 'PJEB050', 'Aluminium Body 109.3 x 148', '105', '3', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (2, '2018-08-23', '1', '4412', '18MM PLYWOOD 8x4 dc', '3.600', '3', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (3, '2018-08-23', '1', '4823', 'Paper Based Laminated 7MM', '1.05', '3', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (4, '2018-08-23', '-', '1225222', 'rod', '4.562', '3', '9', '9', '18', '1', 'exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (5, '2018-09-06', '1', '015', 'Monitor', '3520', '3', '9', '9', '18', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (7, '2018-09-21', '2', '101', 'test', '120', '2', '6', '6', '12', '1', 'Exclusive', '');


#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS backup_details;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (8, 'backup-on-2018-09-12-19-55-07.zip', '2018-09-12');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (9, 'backup-on-2018-09-15-15-24-30.zip', '2018-09-15');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (10, 'backup-on-2018-09-17-11-28-43.zip', '2018-09-17');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (11, 'backup-on-2018-09-18-11-15-40.zip', '2018-09-18');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (12, 'backup-on-2018-09-19-11-55-29.zip', '2018-09-19');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (13, 'backup-on-2018-09-20-10-45-04.zip', '2018-09-20');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (14, 'backup-on-2018-09-21-10-58-20.zip', '2018-09-21');


#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS bed_details;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS card;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO card (`id`, `name`, `date`, `status`) VALUES (1, 'Credit Card', '0000-00-00', 1);
INSERT INTO card (`id`, `name`, `date`, `status`) VALUES (2, 'Debit Card', '0000-00-00', 1);


#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS cash_bill;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS cashbill_details;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO cashbill_details (`id`, `date`, `invoicedate`, `invoiceno`, `customerId`, `customername`, `cust_mobno`, `address`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `systemDate`) VALUES (1, '2018-08-24', '2018-08-24', '001', 1, 'Anbu', '09876543210', '#123,abcd nagar,muthu pallam<br />\n2nd street,coimbatore', 'intrastate', 'sgst', 'cgst', '', 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '105', '10', '1050.00', '0', 'percent_wise', '0.00', '1050.00', '9', '94.50', '9', '94.50', '18', '0', '1239.00', '1239.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1239.00', '001240818', '001-2018', 1, 1, '0000-00-00');


#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS cashbill_reports;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '0000-00-00', '2018-08-24', '001', '2018-08-24', NULL, 0, 'Anbu', '09876543210', '#123,abcd nagar,muthu pallam\n2nd street,coimbatore', 'intrastate', 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '105', '10', '1239.00', NULL, '1239.00', NULL, NULL, '1239.00', NULL, NULL, '1', '001-2018', '001240818', '1');


#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS category;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS collection_details;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2018-09-20', NULL, '2018-09-20', NULL, 'R001', 'Arul', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '1000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2018-09-20', NULL, '2018-09-20', NULL, 'R', 'Arul', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '20000', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS company_logo;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO company_logo (`id`, `date`, `image`, `status`) VALUES (1, '2017-12-27', 'images.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS customer_details;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (1, '2018-08-24', 'Intra customer', 'Arul', '', '', '10th street, west main road', 'near by indian bank.', '', 'Tamil nadu', 'coimbatore', '', '', NULL, '0.00', '166139', '20000', '202284', NULL, '', NULL, '641502', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (2, '2018-08-24', 'Intra customer', 'Balaji', '9500480360', '', 'kamaraj nagar,', 'Trichy road', '', 'Tamil Nadu', 'Karur', '', '', NULL, '0.00', '59313.89', NULL, '55124.89', NULL, '', NULL, '641502', NULL, NULL, NULL, NULL, NULL, '1', '', '', '55', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (3, '2018-09-20', 'Intra customer', 'karthik', '', '', 'xfdf', '23,ht', '', 'tn', 'chennai', '', '', NULL, '0.00', '36453.87', NULL, '36453.87', NULL, '', NULL, '600034', NULL, NULL, NULL, NULL, NULL, '1', '', '', '600023', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS customerpo_details;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS dc_delivery;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (1, '2018-09-01', 1, 1, 'Against Inward', 'D001', '2018-09-01', 1, 'Arul', '', '10th street, west main road, near by indian bank.', 'I001', '4562', '2018-09-01', 'Aluminium Body 109.3 x 148', '', '520', '0', '', 'PJEB050', 'Nos', 'D001-18', 'D001010918', 1, 0);
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (2, '2018-09-05', 2, 1, 'Against Inward', 'D002', '2018-09-05', 1, 'Arul', '', '10th street, west main road, near by indian bank.', 'I001', '4562', '2018-09-01', 'Aluminium Body 109.3 x 148', '', '500', '0', '', 'PJEB050', 'Nos', 'D002-18', 'D002050918', 1, 0);
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (3, '2018-09-06', 3, 1, 'Against Inward', 'D003', '2018-09-06', 1, 'Arul', '', '10th street, west main road, near by indian bank.', 'I001', '4562', '2018-09-01', 'Aluminium Body 109.3 x 148', '', '120', '120', '', 'PJEB050', 'Nos', 'D003-18', 'D003060918', 1, 1);
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (4, '2018-09-06', 4, NULL, 'Direct DC', 'D004', '2018-09-06', 2, 'Balaji', '', 'kamaraj nagar,, Trichy road', NULL, NULL, NULL, 'Aluminium Body 109.3 x 148', '', '20', '20', '', 'PJEB050', 'Nos', 'D004-18', 'D004060918', 1, 1);


#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS dcbill_details;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (1, '2018-09-01', 'Against Inward', 'D001', '2018-09-01', 1, 'Arul', '', '10th street, west main road, near by indian bank.', 'I001', '4562', '2018-09-01', 'Aluminium Body 109.3 x 148', '', '520', '', 'PJEB050', 'Nos', 'D001-18', 'D001010918', 1, 0, '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (2, '2018-09-05', 'Against Inward', 'D002', '2018-09-05', 1, 'Arul', '', '10th street, west main road, near by indian bank.', 'I001', '4562', '2018-09-01', 'Aluminium Body 109.3 x 148', '', '500', '', 'PJEB050', 'Nos', 'D002-18', 'D002050918', 1, 0, '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (3, '2018-09-06', 'Against Inward', 'D003', '2018-09-06', 1, 'Arul', '', '10th street, west main road, near by indian bank.', 'I001', '4562', '2018-09-01', 'Aluminium Body 109.3 x 148', '', '120', '', 'PJEB050', 'Nos', 'D003-18', 'D003060918', 1, 1, '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (4, '2018-09-06', 'Direct DC', 'D004', '2018-09-06', 2, 'Balaji', '', 'kamaraj nagar,, Trichy road', NULL, NULL, NULL, 'Aluminium Body 109.3 x 148', '', '20', '', 'PJEB050', 'Nos', 'D004-18', 'D004060918', 1, 1, '');


#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS headers;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS invoice_details;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (1, '2018-09-01', '2018-09-01', '', '1970-01-01', 'INV', 'D001', 'Sales Invoice', 'Against DC', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'D001', '1', '1', 'PJEB050', 'Aluminium Body 109.3 x 148', '', 'Nos', '105', '520', '54600.00', '0', 'percent_wise', '', '54600.00', '9', '4914.00', '9', '4914.00', '18', '', '64428.00', '64428.00', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '0', '0', '0', '1', '64428.00', 'INV010918', 'INV-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (2, '2018-09-05', '2018-09-05', '14523', '2018-09-05', 'INV1', NULL, 'Sales Invoice', 'Direct Invoice', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, 'PJEB050||4823', 'Aluminium Body 109.3 x 148||Paper Based Laminated 7MM', '||', 'Nos||Nos', '105||25', '10||100', '1050.00||2500.00', '0||0', 'percent_wise', '0.00||0.00', '1050.00||2500.00', '9||9', '94.50||225.00', '9||9', '94.50||225.00', '18||18', '189.00||450.00', '1239.00||2950.00', '4189.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '4189.00', NULL, NULL, 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (3, '2018-09-05', '2018-09-05', '', '1970-01-01', 'INV2', 'D002', 'Sales Invoice', 'Against DC', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'D002', '2', '2', 'PJEB050', 'Aluminium Body 109.3 x 148', '', 'Nos', '105', '500', '52500.00', '0', 'percent_wise', '', '52500.00', '9', '4725.00', '9', '4725.00', '18', '', '61950.00', '61950.00', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '0', '0', '0', '1', '61950.00', 'INV2050918', 'INV2-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (4, '2018-09-06', '2018-09-06', '56264', '2018-09-12', 'INV3', NULL, 'Sales Invoice', 'Against PO', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', '26', 'PJEB050', 'Aluminium Body 109.3 x 148', '', 'Nos', '105', '30', '3150.00', '0', 'percent_wise', '', '3150.00', '9', '283.50', '9', '283.50', '18', '', '3717.00', '3717.00', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '0', '0', '0', '1', '3717.00', 'INV3060918', 'INV3-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (5, '2018-09-21', '2018-09-06', '', '2018-09-21', 'INV4', NULL, 'Sales Invoice', 'Direct Invoice', 0, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '015', 'Monitor', '', 'Nos', '3520', '5', '14915.25', '0', 'percent_wise', '0.00', '17600.00', '9', '1342.37', '9', '1342.37', '18', '2684.75', '17600.00', '17600.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '17600.00', NULL, NULL, 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (6, '2018-09-21', '2018-09-21', '', '2018-09-03', 'INV5', NULL, 'Sales Invoice', 'Direct Invoice', 2, 'Balaji', 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '4823', 'Paper Based Laminated 7MM', '', 'Nos', '1.05', '10', '10.50', '0', 'percent_wise', '0.00', '10.50', '9', '0.94', '9', '0.94', '18', '1.89', '12.39', '12.39', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '12.39', 'INV5210918', 'INV5-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (7, '2018-09-21', '2018-09-21', '', '1970-01-01', 'INV6', NULL, 'Sales Invoice', 'Direct Invoice', 2, 'Balaji', 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '4823||4412', 'Paper Based Laminated 7MM||18MM PLYWOOD 8x4 dc', '||', 'Nos||Nos', '1.05||3.600', '10||15', '10.50||54.00', '0||0', 'percent_wise', '0.00||0.00', '10.50||54.00', '9||9', '0.94||4.86', '9||9', '0.94||4.86', '18||18', '1.89||9.72', '12.39||63.72', '76.11', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '76.11', 'INV6210918', 'INV6-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (8, '2018-09-21', '2018-09-21', '', '2018-09-06', 'INV7', NULL, 'Sales Invoice', 'Direct Invoice', 3, 'karthik', 'xfdf, 23,ht, chennai, tn', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, 'PJEB050||015||4823', 'Aluminium Body 109.3 x 148||Monitor||Paper Based Laminated 7MM', '||||', 'Nos||Nos||Nos', '105||3520||1.05', '10||10||12', '1050.00||29830.51||12.60', '0||0||0', 'percent_wise', '0.00||0.00||0.00', '1050.00||35200.00||12.60', '9||9||9', '94.50||2684.75||1.13', '9||9||9', '94.50||2684.75||1.13', '18||18||18', '189.00||5369.49||2.27', '1239.00||35200.00||14.87', '36453.87', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1', '36453.87', 'INV7210918', 'INV7-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (9, '2018-09-21', '2018-09-21', '', '1970-01-01', 'INV8', NULL, 'Sales Invoice', 'Direct Invoice', 2, 'Balaji', 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '4823||PJEB050||015', 'Paper Based Laminated 7MM||Aluminium Body 109.3 x 148||Monitor', '||||', 'Nos||Nos||Nos', '1.05||105||3520', '10||10||10', '10.50||1050.00||29830.51', '0||0||0', 'percent_wise', '0.00||0.00||0.00', '10.50||1050.00||35200.00', '9||9||9', '0.94||94.50||2684.75', '9||9||9', '0.94||94.50||2684.75', '18||18||18', '1.89||189.00||5369.49', '12.39||1239.00||35200.00', '36451.39', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1', '36451.39', 'INV8210918', 'INV8-2018', 1, 1);


#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS invoice_party_statement;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2018-09-01', 'INV', 1, 'Arul', '', '', '', 'Aluminium Body 109.3 x 148', '', '', '', NULL, NULL, '', '', '1', '2018-09-01', '2018-09-01', '64428.00', '-', '-', '', '', '-', '-', NULL, '64428', '-', '-', '-', '-', '64428.00', '-', '64428.00', NULL, NULL, 'INV-2018', 'INV010918', '1');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '-', '-', NULL, '2018-09-05', 'INV1', 1, 'Arul', '', '', '', 'Aluminium Body 109.3 x 148||Paper Based Laminated 7MM', '||', '', '', NULL, NULL, '', '', '1', '2018-09-05', '2018-09-05', '4189.00', '-', '-', '', '', '-', '-', NULL, '68617', '-', '-', '-', '-', '4189.00', '-', '4189.00', NULL, NULL, NULL, NULL, '2');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '-', '-', NULL, '2018-09-05', 'INV2', 1, 'Arul', '', '', '', 'Aluminium Body 109.3 x 148', '', '', '', NULL, NULL, '', '', '1', '2018-09-05', '2018-09-05', '61950.00', '-', '-', '', '', '-', '-', NULL, '130567', '-', '-', '-', '-', '61950.00', '-', '61950.00', NULL, NULL, 'INV2-2018', 'INV2050918', '3');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '-', '-', NULL, '2018-09-06', 'INV3', 1, 'Arul', '', '', '', 'Aluminium Body 109.3 x 148', '', '', '', NULL, NULL, '', '', '1', '2018-09-06', '2018-09-06', '3717.00', '-', '-', '', '', '-', '-', NULL, '134284', '-', '-', '-', '-', '3717.00', '-', '3717.00', NULL, NULL, 'INV3-2018', 'INV3060918', '4');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, 'R', '', NULL, '2018-09-20', '-', 0, 'Arul', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2018-09-20', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '202284', NULL, NULL, NULL, 'Cash', NULL, '20000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '-', '-', NULL, '2018-09-06', 'INV4', 0, 'Arul', '', '', '', 'Monitor', '', '', '', NULL, NULL, '', '', '1', '2018-09-06', '2018-09-06', '17600.00', '-', '-', '', '', '-', '-', NULL, '202284', '-', '-', '-', '-', '17600.00', '-', '17600.00', NULL, NULL, NULL, NULL, '5');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '-', '-', NULL, '2018-09-21', 'INV5', 2, 'Balaji', '', '', '', 'Paper Based Laminated 7MM', '', '', '', NULL, NULL, '', '', '1', '2018-09-21', '2018-09-21', '12.39', '-', '-', '', '', '-', '-', NULL, '18597.39', '-', '-', '-', '-', '12.39', '-', '12.39', NULL, NULL, 'INV5-2018', 'INV5210918', '6');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '-', '-', NULL, '2018-09-21', 'INV6', 2, 'Balaji', '', '', '', 'Paper Based Laminated 7MM||18MM PLYWOOD 8x4 dc', '||', '', '', NULL, NULL, '', '', '1', '2018-09-21', '2018-09-21', '76.11', '-', '-', '', '', '-', '-', NULL, '18673.5', '-', '-', '-', '-', '76.11', '-', '76.11', NULL, NULL, 'INV6-2018', 'INV6210918', '7');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '-', '-', NULL, '2018-09-21', 'INV7', 3, 'karthik', '', '', '', 'Aluminium Body 109.3 x 148||Monitor||Paper Based Laminated 7MM', '||||', '', '', NULL, NULL, '', '', '1', '2018-09-21', '2018-09-21', '36453.87', '-', '-', '', '', '-', '-', NULL, '36453.87', '-', '-', '-', '-', '36453.87', '-', '36453.87', NULL, NULL, 'INV7-2018', 'INV7210918', '8');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (19, '-', '-', NULL, '2018-09-21', 'INV8', 2, 'Balaji', '', '', '', 'Paper Based Laminated 7MM||Aluminium Body 109.3 x 148||Monitor', '||||', '', '', NULL, NULL, '', '', '1', '2018-09-21', '2018-09-21', '36451.39', '-', '-', '', '', '-', '-', NULL, '55124.89', '-', '-', '-', '-', '36451.39', '-', '36451.39', NULL, NULL, 'INV8-2018', 'INV8210918', '9');


#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS invoice_reports;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2018-09-01', 'INV', '2018-09-01', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '', '1', '520', '6', NULL, '64428.00', NULL, NULL, '64428.00', NULL, NULL, '1', 'INV-2018', 'INV010918', '1');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '2018-09-05', 'INV1', '2018-09-05', NULL, NULL, 0, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '2018-09-05', '14523', NULL, 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '', '105', '10', '1239.00', NULL, '4189.00', NULL, NULL, '4189.00', NULL, NULL, '1', NULL, NULL, '2');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '2018-09-05', 'INV1', '2018-09-05', NULL, NULL, 0, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '2018-09-05', '14523', NULL, '4823', NULL, 'Paper Based Laminated 7MM', '', '25', '100', '2950.00', NULL, '4189.00', NULL, NULL, '4189.00', NULL, NULL, '1', NULL, NULL, '2');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '2018-09-05', 'INV2', '2018-09-05', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '', '1', '500', '6', NULL, '61950.00', NULL, NULL, '61950.00', NULL, NULL, '1', 'INV2-2018', 'INV2050918', '3');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '2018-09-06', 'INV3', '2018-09-06', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '2018-09-12', '56264', NULL, 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '', '1', '30', '3', NULL, '3717.00', NULL, NULL, '3717.00', NULL, NULL, '1', 'INV3-2018', 'INV3060918', '4');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '2018-09-21', 'INV4', '2018-09-06', NULL, NULL, 0, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '2018-09-21', '', NULL, '015', NULL, 'Monitor', '', '3520', '5', '17600.00', NULL, '17600.00', NULL, NULL, '17600.00', NULL, NULL, '1', NULL, NULL, '5');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, '2018-09-21', 'INV5', '2018-09-21', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '2018-09-03', '', NULL, '4823', NULL, 'Paper Based Laminated 7MM', '', '1', '10', '1', NULL, '12.39', NULL, NULL, '12.39', NULL, NULL, '1', 'INV5-2018', 'INV5210918', '6');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '2018-09-21', 'INV6', '2018-09-21', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '4823', NULL, 'Paper Based Laminated 7MM', '', '1', '10', '1', NULL, '76.11', NULL, NULL, '76.11', NULL, NULL, '1', 'INV6-2018', 'INV6210918', '7');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (23, '2018-09-21', 'INV6', '2018-09-21', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '4412', NULL, '18MM PLYWOOD 8x4 dc', '', '.', '15', '2', NULL, '76.11', NULL, NULL, '76.11', NULL, NULL, '1', 'INV6-2018', 'INV6210918', '7');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (24, '2018-09-21', 'INV7', '2018-09-21', NULL, NULL, 3, 'karthik', NULL, NULL, NULL, 'xfdf, 23,ht, chennai, tn', 'intrastate', 'intrastate', '', '', NULL, '2018-09-06', '', NULL, 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '', '1', '10', '1', NULL, '36453.87', NULL, NULL, '36453.87', NULL, NULL, '1', 'INV7-2018', 'INV7210918', '8');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (25, '2018-09-21', 'INV7', '2018-09-21', NULL, NULL, 3, 'karthik', NULL, NULL, NULL, 'xfdf, 23,ht, chennai, tn', 'intrastate', 'intrastate', '', '', NULL, '2018-09-06', '', NULL, '015', NULL, 'Monitor', '', '0', '10', '2', NULL, '36453.87', NULL, NULL, '36453.87', NULL, NULL, '1', 'INV7-2018', 'INV7210918', '8');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (26, '2018-09-21', 'INV7', '2018-09-21', NULL, NULL, 3, 'karthik', NULL, NULL, NULL, 'xfdf, 23,ht, chennai, tn', 'intrastate', 'intrastate', '', '', NULL, '2018-09-06', '', NULL, '4823', NULL, 'Paper Based Laminated 7MM', '', '5', '12', '3', NULL, '36453.87', NULL, NULL, '36453.87', NULL, NULL, '1', 'INV7-2018', 'INV7210918', '8');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (27, '2018-09-21', 'INV8', '2018-09-21', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '4823', NULL, 'Paper Based Laminated 7MM', '', '1', '10', '1', NULL, '36451.39', NULL, NULL, '36451.39', NULL, NULL, '1', 'INV8-2018', 'INV8210918', '9');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (28, '2018-09-21', 'INV8', '2018-09-21', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '', '.', '10', '2', NULL, '36451.39', NULL, NULL, '36451.39', NULL, NULL, '1', 'INV8-2018', 'INV8210918', '9');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (29, '2018-09-21', 'INV8', '2018-09-21', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '015', NULL, 'Monitor', '', '0', '10', '.', NULL, '36451.39', NULL, NULL, '36451.39', NULL, NULL, '1', 'INV8-2018', 'INV8210918', '9');


#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS inward_delivery;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (1, 1, '2018-09-01', 'I001', '2018-09-01', 'Arul', '10th street, west main road, near by indian bank.', '4562', '2018-09-01', 'Aluminium Body 109.3 x 148', '', '1520', '380', '', 'PJEB050', 'Nos', 'I001-18', 'I001010918', 1, 1);
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (2, 2, '2018-09-06', 'I002', '2018-09-06', 'Balaji', 'kamaraj nagar,, Trichy road', '656312', '2018-09-06', 'Paper Based Laminated 7MM', '', '560', '560', '', '4823', 'Nos', 'I002-18', 'I002060918', 1, 1);
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (3, 3, '2018-09-06', 'I003', '2018-09-06', 'Arul', '10th street, west main road, near by indian bank.', '65452', '2018-09-06', 'Aluminium Body 109.3 x 148', '', '300', '300', '', 'PJEB050', 'Nos', 'I003-18', 'I003060918', 1, 1);
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (4, 4, '2018-09-06', 'I004', '2018-09-06', 'Arul', '10th street, west main road, near by indian bank.', '3124', '2018-09-06', 'Paper Based Laminated 7MM', '', '300', '300', '', '4823', 'Nos', 'I004-18', 'I004060918', 1, 1);


#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS inward_details;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (1, '2018-09-01', 'I001', '2018-09-01', 'Arul', '10th street, west main road, near by indian bank.', '4562', '2018-09-01', 'Aluminium Body 109.3 x 148', '', '1520', '', 'PJEB050', 'Nos', 'I001-18', 'I001010918', 1, 0, '1');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (2, '2018-09-06', 'I002', '2018-09-06', 'Balaji', 'kamaraj nagar,, Trichy road', '656312', '2018-09-06', 'Paper Based Laminated 7MM', '', '560', '', '4823', 'Nos', 'I002-18', 'I002060918', 1, 1, '2');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (3, '2018-09-06', 'I003', '2018-09-06', 'Arul', '10th street, west main road, near by indian bank.', '65452', '2018-09-06', 'Aluminium Body 109.3 x 148', '', '300', '', 'PJEB050', 'Nos', 'I003-18', 'I003060918', 1, 1, '3');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (4, '2018-09-06', 'I004', '2018-09-06', 'Arul', '10th street, west main road, near by indian bank.', '3124', '2018-09-06', 'Paper Based Laminated 7MM', '', '300', '', '4823', 'Nos', 'I004-18', 'I004060918', 1, 1, '4');


#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS job_data;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS job_details;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS jobinward_data;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS jobinward_details;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS login_details;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (1, 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'Myoffice!@#$%', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (5, 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', 1, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (6, 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', 0, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (7, 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', 0, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (8, 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', 1, 0, 0);


#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS po_party_statements;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS preference_details;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS preference_settings;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO preference_settings (`id`, `quotation`, `expenses`, `dc`, `voucher`, `debit`, `credit`, `purchase`, `invoicePrefix`, `invoice`, `proforma_invoicePrefix`, `proforma_invoice`, `inward`, `cashbill_invoice`, `purchaseorder`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`) VALUES (1, '101', '001', '', '', '001', '001', '001', 'INV', '', 'P', '', '', '', '', 'Myoffice Solutions', '04222570103', '8608701222', '#91, Dr. Jaganathan Nagar, ', 'Civil Aerodrome Post', 'Coimbatore', '641 014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '04222570103', '8608701333', '#91, Dr. Jaganathan Nagar, ', 'Civil Aerodrome Post', 'Coimbatore', '641 014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'percent_wise', 'without_stock', 'with_item');


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS profile;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO profile (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`) VALUES (1, NULL, 'Myoffice CRM', 'GST Billing Demo', '9943744177', '0422-2668244', ' #91, Dr, Jaganathan Nagar CMC opp', 'Civil Aerodrome Post', 'Dharmapuri', '641035', 'Tamil Nadu', 'info@idreamdevelopers.com', 'www.idreamdevelopers.org', '12345', '54321', '33AFYPV3340K1ZT', '', '1', 'admin', 'Myoffice!@#$%', 'THE KARUR VYSYA BANK LTD.,', '1748115000002961', 'SARAVANAMPATTI', 'KVBL0001748');


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS proforma_invoice_details;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO proforma_invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (1, '2018-09-17', '2018-09-17', '7410', '2018-09-17', 'P001', NULL, 'Sales Invoice', '0', 2, 'Balaji', 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'TRICHY', 'TRUCKS', 'dsfd', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, 'PJEB050', 'Aluminium Body 109.3 x 148', '', 'Nos', '105', '150', '15750.00', '0', 'percent_wise', '0.00', '15750.00', '9', '1417.50', '9', '1417.50', '18', '2835.00', '18585.00', '18585.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '18585.00', 'P001170918', 'P001-2018', 1, 1);
INSERT INTO proforma_invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (2, '2018-09-17', '2018-09-17', '852', '2018-09-17', 'P002', NULL, 'Sales Invoice', '0', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'ERODE', 'Lorry', 'TN 48 PS 9630', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '015', 'Monitor', '', 'Nos', '3520', '20', '59661.02', '0', 'percent_wise', '0.00', '70400.00', '9', '5369.49', '9', '5369.49', '18', '10738.98', '70400.00', '70400.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '70400.00', 'P002170918', 'P002-2018', 1, 1);


#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS proforma_invoice_reports;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO proforma_invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2018-09-17', 'P001', '2018-09-17', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', 'TRICHY', 'dsfd', NULL, '2018-09-17', '7410', NULL, 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '', '1', '150', '1', NULL, '18585.00', NULL, NULL, '18585.00', NULL, NULL, '1', 'P001-2018', 'P001170918', '1');
INSERT INTO proforma_invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2018-09-17', 'P002', '2018-09-17', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', 'ERODE', 'TN 48 PS 9630', NULL, '2018-09-17', '852', NULL, '015', NULL, 'Monitor', '', '3', '20', '7', NULL, '70400.00', NULL, NULL, '70400.00', NULL, NULL, '1', 'P002-2018', 'P002170918', '2');


#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS proinvoice_party_statement;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO proinvoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2018-09-17', 'P001', 2, 'Balaji', '', '', '', 'Aluminium Body 109.3 x 148', '', '', '', NULL, NULL, '', '', '1', '2018-09-17', '2018-09-17', '18585.00', '-', '-', '', '', '-', '-', NULL, '18585', '-', '-', '-', '-', '18585.00', '-', '18585.00', NULL, NULL, 'P001-2018', 'P001170918', '1');
INSERT INTO proinvoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '-', '-', NULL, '2018-09-17', 'P002', 1, 'Arul', '', '', '', 'Monitor', '', '', '', NULL, NULL, '', '', '1', '2018-09-17', '2018-09-17', '70400.00', '-', '-', '', '', '-', '-', NULL, '222284', '-', '-', '-', '-', '70400.00', '-', '70400.00', NULL, NULL, 'P002-2018', 'P002170918', '2');


#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS purchase_collection;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS purchase_details;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS purchase_reports;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS purchaseorder_details;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (5, '2018-07-11', '2018-07-11', '2018-07-11', 'Direct PO', 'P002', '152595', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '29911||0', 'KGV 5131 Shaft||ISO 30 MICRO BORING HEAD', 'NOS||NOS', '2500||5500', '10||1', NULL, '0||0', '25000.00||5500.00', '0||0', 'percent_wise', '0.00||0.00', '25000.00||5500.00', '9||9', '2250.00||495.00', '9||9', '2250.00||495.00', '0||0', '0||0', '29500.00||6490.00', '35990.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '35990.00', 'P002110718', 'P002-2018', 1, 0);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (6, '2018-07-12', '2018-07-12', '2018-07-12', 'Direct PO', 'P003', '4555', NULL, 13, 'procos  mechatronics pvt ltd', 'no.5/153/7,poolakkadu thottam, arasur,, coimbatrore, tamilnadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '29911', 'KGV 5131 Shaft', 'NOS', '2500', '10', NULL, '0', '25000.00', '0', 'percent_wise', '0.00', '25000.00', '9', '2250.00', '9', '2250.00', '0', '0', '29500.00', '29500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '29500.00', 'P003120718', 'P003-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (7, '2018-07-12', '2018-07-12', '2018-07-12', 'Direct PO', 'P004', '155', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '29911', 'KGV 5131 Shaft', 'NOS', '2500', '10', NULL, '0', '25000.00', '0', 'percent_wise', '0.00', '25000.00', '9', '2250.00', '9', '2250.00', '0', '0', '29500.00', '29500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '29500.00', 'P004120718', 'P004-2018', 1, 0);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (8, '2018-07-13', '2018-07-13', '2018-07-13', 'Direct PO', 'P005', '4552', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '0', '8 INCH STONE CORBERANDUM', 'NOS', '580', '10', NULL, '0', '5800.00', '0', 'percent_wise', '0.00', '5800.00', '9', '522.00', '9', '522.00', '0', '0', '6844.00', '6844.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '6844.00', 'P005130718', 'P005-2018', 1, 0);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (9, '2018-07-13', '2018-07-13', '2018-07-13', 'Direct PO', 'P006', '565', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73090090', '1130010023 spacer', 'NOS', '78', '5', NULL, '0', '390.00', '0', 'percent_wise', '0.00', '390.00', '9', '35.10', '9', '35.10', '0', '0', '460.20', '460.20', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '460.20', 'P006130718', 'P006-2018', 1, 0);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (10, '2018-07-17', '2018-07-17', '2018-07-17', 'Direct PO', 'P007', '4165', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '29911||0', 'KGV 5131 Shaft||12 ADJUST WRINCH', 'NOS||NOS', '2500||340', '10||030', NULL, '0||0', '25000.00||10200.00', '0||0', 'percent_wise', '0.00||0.00', '25000.00||10200.00', '9||9', '2250.00||918.00', '9||9', '2250.00||918.00', '0||0', '0||0', '29500.00||12036.00', '41536.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '41536.00', 'P007170718', 'P007-2018', 1, 0);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (11, '2018-07-17', '2018-07-17', '2018-07-17', 'Direct PO', 'P008', '5659832', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '0||84099990', '8 INCH STONE CORBERANDUM||FB.00.SA004_DECK HINGE _502943', 'NOS||NOS', '580||53', '10||10', NULL, '0||0', '5800.00||530.00', '10||10', 'percent_wise', '580.00||53.00', '5220.00||477.00', '9||9', '469.80||42.93', '9||9', '469.80||42.93', '0||0', '0||0', '6159.60||562.86', '6722.46', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '6722.46', 'P008170718', 'P008-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (12, '2018-07-26', '2018-07-26', '2018-07-26', 'Direct PO', 'P009', '1452', NULL, 13, 'procos  mechatronics pvt ltd', 'no.5/153/7,poolakkadu thottam, arasur,, coimbatrore, tamilnadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73181110', '1130500081 spacer', 'NOS', '40', '100', NULL, '0', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '360.00', '9', '360.00', '0', '0', '4720.00', '4720.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '4720.00', 'P009260718', 'P009-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (14, '2018-07-26', '2018-07-26', '2018-07-26', 'Direct PO', 'P010', '56122325', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '4418', 'PA-01-105-018 NYLON BLOCK', 'NOS', '145', '20', '20', '0', '2900.00', '0', 'percent_wise', '0.00', '2900.00', '9', '261.00', '9', '261.00', '0', '0', '3422.00', '3422.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '3422.00', 'P010260718', 'P010-2018', 1, 0);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (15, '2018-08-24', '2018-08-24', '2018-08-24', 'Direct PO', 'P011', '1452', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '29911', 'KGV 5131 Shaft', 'NOS', '2500', '10', '10', '0', '25000.00', '0', 'percent_wise', '0.00', '25000.00', '9', '2250.00', '9', '2250.00', '0', '0', '29500.00', '29500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '29500.00', 'P011240818', 'P011-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (16, '2018-08-24', '2018-08-24', '2018-08-24', 'Direct PO', 'P011', '1452', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '29911', 'KGV 5131 Shaft', 'NOS', '2500', '10', '10', '0', '25000.00', '0', 'percent_wise', '0.00', '25000.00', '9', '2250.00', '9', '2250.00', '0', '0', '29500.00', '29500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '29500.00', 'P011240818', 'P011-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (17, '2018-08-24', '2018-08-24', '2018-08-24', 'Direct PO', 'P011', '1452', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '29911', 'KGV 5131 Shaft', 'NOS', '2500', '10', '10', '0', '25000.00', '0', 'percent_wise', '0.00', '25000.00', '9', '2250.00', '9', '2250.00', '0', '0', '29500.00', '29500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '29500.00', 'P011240818', 'P011-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (18, '2018-09-06', '2018-09-06', '2018-09-06', 'Direct PO', 'P012', '14633', NULL, 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '105', '120', '120', '0', '12600.00', '0', 'percent_wise', '0.00', '12600.00', '9', '1134.00', '9', '1134.00', '0', '0', '14868.00', '14868.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '14868.00', 'P012060918', 'P012-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (19, '2018-09-15', '2018-09-15', '2018-09-15', 'Direct PO', 'P013', '5642', NULL, 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '105', '10', '10', '0', '1050.00', '0', 'percent_wise', '0.00', '1050.00', '9', '94.50', '9', '94.50', '0', '0', '1239.00', '1239.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1239.00', 'P013150918', 'P013-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (20, '2018-09-15', '2018-09-15', '2018-09-15', 'Direct PO', 'P013', '5642', NULL, 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '105', '10', '10', '0', '1050.00', '0', 'percent_wise', '0.00', '1050.00', '9', '94.50', '9', '94.50', '0', '0', '1239.00', '1239.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1239.00', 'P013150918', 'P013-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (21, '2018-09-20', '2018-09-20', '2018-09-20', 'Direct PO', 'P014', '12', NULL, 3, 'karthik', 'xfdf, 23,ht, chennai, tn', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '84795000', 'defr', 'Nos', '23545', '2', '2', '0', '47090.00', '0', 'percent_wise', '0.00', '47090.00', '9', '4238.10', '9', '4238.10', '0', '0', '55566.20', '55566.20', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '55566.20', 'P014200918', 'P014-2018', 1, 1);


#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS purchaseorder_reports;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (10, '4', '2018-04-21', '', 'P001', '10317183042534', NULL, '2018-04-20', NULL, 0, 'CRAFTSMAN AUTOMATION PRIVATE LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', NULL, '2018-03-28', NULL, NULL, '73090090', '1130010020 SPACER', 'NOS', '1', '50', NULL, '', '9853.00', '16933.00', NULL, NULL, NULL, NULL, NULL, '16933.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2018', 'P001210418');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (11, '4', '2018-04-21', '', 'P001', '10317183042534', NULL, '2018-04-20', NULL, 0, 'CRAFTSMAN AUTOMATION PRIVATE LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', NULL, '2018-03-28', NULL, NULL, '73090090', '1130010021 SPACER', 'NOS', '6', '50', NULL, '', '3540.00', '16933.00', NULL, NULL, NULL, NULL, NULL, '16933.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2018', 'P001210418');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (12, '4', '2018-04-21', '', 'P001', '10317183042534', NULL, '2018-04-20', NULL, 0, 'CRAFTSMAN AUTOMATION PRIVATE LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', NULL, '2018-03-28', NULL, NULL, '73090090', '1130010022 SPACER', 'NOS', '7', '50', NULL, '', '3540.00', '16933.00', NULL, NULL, NULL, NULL, NULL, '16933.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2018', 'P001210418');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (13, '5', '2018-07-11', 'Direct PO', 'P002', '152595', NULL, '2018-07-11', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-11', NULL, NULL, '29911', 'KGV 5131 Shaft', 'NOS', '2', '10', NULL, '0', '29500.00', '35990.00', NULL, NULL, NULL, NULL, NULL, '35990.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P002-2018', 'P002110718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (14, '5', '2018-07-11', 'Direct PO', 'P002', '152595', NULL, '2018-07-11', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-11', NULL, NULL, '0', 'ISO 30 MICRO BORING HEAD', 'NOS', '5', '1', NULL, '0', '6490.00', '35990.00', NULL, NULL, NULL, NULL, NULL, '35990.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P002-2018', 'P002110718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (15, '6', '2018-07-12', 'Direct PO', 'P003', '4555', NULL, '2018-07-12', NULL, 13, 'procos  mechatronics pvt ltd', 'no.5/153/7,poolakkadu thottam, arasur,, coimbatrore, tamilnadu', '0', '2018-07-12', NULL, NULL, '29911', 'KGV 5131 Shaft', 'NOS', '2', '10', NULL, '0', '29500.00', '29500.00', NULL, NULL, NULL, NULL, NULL, '29500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P003-2018', 'P003120718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (16, '7', '2018-07-12', 'Direct PO', 'P004', '155', NULL, '2018-07-12', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-12', NULL, NULL, '29911', 'KGV 5131 Shaft', 'NOS', '2', '10', NULL, '0', '29500.00', '29500.00', NULL, NULL, NULL, NULL, NULL, '29500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P004-2018', 'P004120718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (17, '8', '2018-07-13', 'Direct PO', 'P005', '4552', NULL, '2018-07-13', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-13', NULL, NULL, '0', '8 INCH STONE CORBERANDUM', 'NOS', '5', '10', NULL, '0', '6844.00', '6844.00', NULL, NULL, NULL, NULL, NULL, '6844.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P005-2018', 'P005130718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (18, '9', '2018-07-13', 'Direct PO', 'P006', '565', NULL, '2018-07-13', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-13', NULL, NULL, '73090090', '1130010023 spacer', 'NOS', '7', '5', NULL, '0', '460.20', '460.20', NULL, NULL, NULL, NULL, NULL, '460.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P006-2018', 'P006130718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (19, '10', '2018-07-17', 'Direct PO', 'P007', '4165', NULL, '2018-07-17', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', '2018-07-17', NULL, NULL, '29911', 'KGV 5131 Shaft', 'NOS', '2', '10', NULL, '0', '29500.00', '41536.00', NULL, NULL, NULL, NULL, NULL, '41536.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P007-2018', 'P007170718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (20, '10', '2018-07-17', 'Direct PO', 'P007', '4165', NULL, '2018-07-17', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', '2018-07-17', NULL, NULL, '0', '12 ADJUST WRINCH', 'NOS', '5', '030', NULL, '0', '12036.00', '41536.00', NULL, NULL, NULL, NULL, NULL, '41536.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P007-2018', 'P007170718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (21, '11', '2018-07-17', 'Direct PO', 'P008', '5659832', NULL, '2018-07-17', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-17', NULL, NULL, '0', '8 INCH STONE CORBERANDUM', 'NOS', '5', '10', NULL, '0', '6159.60', '6722.46', NULL, NULL, NULL, NULL, NULL, '6722.46', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P008-2018', 'P008170718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (22, '11', '2018-07-17', 'Direct PO', 'P008', '5659832', NULL, '2018-07-17', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-17', NULL, NULL, '84099990', 'FB.00.SA004_DECK HINGE _502943', 'NOS', '8', '10', NULL, '0', '562.86', '6722.46', NULL, NULL, NULL, NULL, NULL, '6722.46', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P008-2018', 'P008170718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (23, '12', '2018-07-26', 'Direct PO', 'P009', '1452', NULL, '2018-07-26', NULL, 13, 'procos  mechatronics pvt ltd', 'no.5/153/7,poolakkadu thottam, arasur,, coimbatrore, tamilnadu', '0', '2018-07-26', NULL, NULL, '73181110', '1130500081 spacer', 'NOS', '4', '100', NULL, '0', '4720.00', '4720.00', NULL, NULL, NULL, NULL, NULL, '4720.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P009-2018', 'P009260718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (24, '14', '2018-07-26', 'Direct PO', 'P010', '56122325', NULL, '2018-07-26', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', '2018-07-26', NULL, NULL, '4418', 'PA-01-105-018 NYLON BLOCK', 'NOS', '1', '20', '5', '0', '3422.00', '3422.00', NULL, NULL, NULL, NULL, NULL, '3422.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P010-2018', 'P010260718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (25, '17', '2018-08-24', 'Direct PO', 'P011', '1452', NULL, '2018-08-24', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', '2018-08-24', NULL, NULL, '29911', 'KGV 5131 Shaft', 'NOS', '2', '10', '10', '0', '29500.00', '29500.00', NULL, NULL, NULL, NULL, NULL, '29500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P011-2018', 'P011240818');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (26, '18', '2018-09-06', 'Direct PO', 'P012', '14633', NULL, '2018-09-06', NULL, 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '0', '2018-09-06', NULL, NULL, 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '1', '120', '120', '0', '14868.00', '14868.00', NULL, NULL, NULL, NULL, NULL, '14868.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P012-2018', 'P012060918');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (27, '20', '2018-09-15', 'Direct PO', 'P013', '5642', NULL, '2018-09-15', NULL, 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '0', '2018-09-15', NULL, NULL, 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '1', '10', '10', '0', '1239.00', '1239.00', NULL, NULL, NULL, NULL, NULL, '1239.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P013-2018', 'P013150918');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (28, '21', '2018-09-20', 'Direct PO', 'P014', '12', NULL, '2018-09-20', NULL, 3, 'karthik', 'xfdf, 23,ht, chennai, tn', '0', '2018-09-20', NULL, NULL, '84795000', 'defr', 'Nos', '2', '2', '2', '0', '55566.20', '55566.20', NULL, NULL, NULL, NULL, NULL, '55566.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P014-2018', 'P014200918');


#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS quotation_details;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS sales_return;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS stock;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (1, '2018-09-21', 'PJEB050', NULL, '9', '9', '18', 'Aluminium Body 109.3 x 148', '150', '105', '150', '', '1', '-20', NULL, NULL, '', '2018-09-06', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (2, '2018-09-21', '4823', NULL, '9', '9', '18', 'Paper Based Laminated 7MM', '1500', '1.05', '1500', '', '1', '1458', NULL, NULL, '', '2018-09-06', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (3, '2018-09-06', '1225222', NULL, '9', '9', '18', 'rod', '250', '4.562', '250', '', '1', '250', NULL, NULL, '', '2018-09-06', 'exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (4, '2018-09-21', '4412', NULL, '9', '9', '18', '18MM PLYWOOD 8x4 dc', '120', '3.600', '120', '', '1', '105', NULL, NULL, '', '2018-09-06', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (5, '2018-09-20', '84795000', NULL, '9', '9', '18', 'defr', '3', '23545', '3', '', '1', '3', NULL, NULL, '', '2018-09-20', 'Exclusive');


#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS stock_reports;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (1, '2018-09-06', 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '1', '150', 'FromAddStock', '2018-09-06', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (2, '2018-09-06', '4823', NULL, 'Paper Based Laminated 7MM', '1', '1500', 'FromAddStock', '2018-09-06', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (3, '2018-09-06', '1225222', NULL, 'rod', '1', '250', 'FromAddStock', '2018-09-06', NULL, NULL, 'exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (4, '2018-09-06', '4412', NULL, '18MM PLYWOOD 8x4 dc', '1', '120', 'FromAddStock', '2018-09-06', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (5, '2018-09-20', '84795000', NULL, 'defr', '1', '3', 'FromAddStock', '2018-09-20', NULL, NULL, 'Exclusive');


#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS tbl_person;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS uom;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (1, '2018-08-23', 'Nos', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (2, '2018-08-23', 'set', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (3, '2018-08-23', 'kgs', 1);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS user_menu;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS vat_details;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (1, '2018-08-23', 'gst', '5', 'gst @ 5 %', '2.5', '2.5', '5', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (2, '2018-08-23', 'gst', '12', 'gst @ 12 %', '6', '6', '12', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (3, '2018-08-23', 'gst', '18', 'gst @ 18 %', '9', '9', '18', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (4, '2018-08-23', 'gst', '28', 'gst @ 28 %', '14', '14', '28', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS vendor_details;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS voucher;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (2, '2018-09-20', 'R', 1, 'Arul', '2018-09-20', 'payment', 'services', 'Cash', '0', '', '', '0', '', '20000', 'Cash', NULL, NULL, '20000', '20000', '1', 0);


