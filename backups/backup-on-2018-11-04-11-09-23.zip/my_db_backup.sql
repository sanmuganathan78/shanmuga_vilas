#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS additem;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (1, '2018-08-23', '1', 'PJEB050', 'Aluminium Body 109.3 x 148', '105', '3', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (2, '2018-08-23', '1', '4412', '18MM PLYWOOD 8x4 dc', '3.600', '3', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (3, '2018-08-23', '1', '4823', 'Paper Based Laminated 7MM', '1.05', '3', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (4, '2018-08-23', '-', '1225222', 'rod', '4.562', '3', '9', '9', '18', '1', 'exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (5, '2018-09-06', '1', '015', 'Monitor', '3520', '3', '9', '9', '18', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (7, '2018-09-21', '2', '101', 'test', '120', '2', '6', '6', '12', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (8, '2018-09-25', '4', 'ra001', 'sample', '100', '1', '2.5', '2.5', '5', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (9, '2018-09-26', '1', 'Lenova', '19073667082', '9999', '3', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (10, '2018-10-04', '2', '99752', 'Iinstalation m couch', '50000', '3', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (11, '2018-10-23', '1', '1012', 'Steel', '100000', '2', '6', '6', '12', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (12, '2018-10-25', '1', '998898', 'bush u', '300', '4', '14', '14', '28', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (14, '2018-10-28', '1', '30041010', 'sertaol', '42', '2', '6', '6', '12', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (15, '2018-10-29', '1', '151515', 'MF 5245 PD', '0', '2', '6', '6', '12', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (16, '2018-10-29', '1', '12345', 'tissue paper', '1000', '3', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (17, '2018-10-30', '1', '5211', 'FILTERBAG', '1000', '2', '6', '6', '12', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (18, '2018-11-01', '3', '3003', 'SAFOOF BODY MASS  1 KGS', '699', '2', '6', '6', '12', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (19, '2018-11-01', '3', '3003', 'SAFOOF TURBO MASS 1KGS', '849', '2', '6', '6', '12', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (20, '2018-11-01', '3', '3003', 'SAFOOF MAGA PRO 3 KGS', '4421', '2', '6', '6', '12', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (21, '2018-11-01', '3', '3003', 'SAFOOF BODY MASS 3 KGS', '0', '2', '6', '6', '12', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (22, '2018-11-01', '3', '3003', 'SAFOOF BODY MASS 5KGS', '0', '2', '6', '6', '12', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (23, '2018-11-01', '3', '3003', 'SAFOOF TURBO MASS 3 KGS', '0', '2', '6', '6', '12', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (24, '2018-11-02', '1', '101', 'pencil', '5', '3', '9', '9', '18', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (25, '2018-11-02', '1', '102', 'eraser', '10', '3', '9', '9', '18', '1', 'Inclusive', '');


#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS backup_details;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (8, 'backup-on-2018-09-12-19-55-07.zip', '2018-09-12');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (9, 'backup-on-2018-09-15-15-24-30.zip', '2018-09-15');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (10, 'backup-on-2018-09-17-11-28-43.zip', '2018-09-17');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (11, 'backup-on-2018-09-18-11-15-40.zip', '2018-09-18');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (12, 'backup-on-2018-09-19-11-55-29.zip', '2018-09-19');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (13, 'backup-on-2018-09-20-10-45-04.zip', '2018-09-20');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (14, 'backup-on-2018-09-21-10-58-20.zip', '2018-09-21');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (15, 'backup-on-2018-09-23-12-06-45.zip', '2018-09-23');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (16, 'backup-on-2018-09-24-10-28-09.zip', '2018-09-24');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (17, 'backup-on-2018-09-25-10-24-14.zip', '2018-09-25');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (18, 'backup-on-2018-09-26-10-39-25.zip', '2018-09-26');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (19, 'backup-on-2018-09-26-10-39-25.zip', '2018-09-26');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (20, 'backup-on-2018-09-27-10-56-25.zip', '2018-09-27');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (21, 'backup-on-2018-09-28-10-43-51.zip', '2018-09-28');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (22, 'backup-on-2018-09-29-11-04-03.zip', '2018-09-29');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (23, 'backup-on-2018-10-01-13-35-00.zip', '2018-10-01');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (24, 'backup-on-2018-10-02-12-03-16.zip', '2018-10-02');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (25, 'backup-on-2018-10-03-16-14-28.zip', '2018-10-03');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (26, 'backup-on-2018-10-04-15-19-21.zip', '2018-10-04');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (27, 'backup-on-2018-10-05-11-41-44.zip', '2018-10-05');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (28, 'backup-on-2018-10-06-12-42-54.zip', '2018-10-06');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (29, 'backup-on-2018-10-07-10-00-57.zip', '2018-10-07');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (30, 'backup-on-2018-10-08-10-38-18.zip', '2018-10-08');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (31, 'backup-on-2018-10-09-11-08-49.zip', '2018-10-09');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (32, 'backup-on-2018-10-10-11-06-25.zip', '2018-10-10');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (33, 'backup-on-2018-10-11-13-11-48.zip', '2018-10-11');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (34, 'backup-on-2018-10-12-10-23-47.zip', '2018-10-12');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (35, 'backup-on-2018-10-13-10-36-06.zip', '2018-10-13');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (36, 'backup-on-2018-10-15-12-24-22.zip', '2018-10-15');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (37, 'backup-on-2018-10-18-17-37-43.zip', '2018-10-18');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (38, 'backup-on-2018-10-22-11-33-02.zip', '2018-10-22');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (39, 'backup-on-2018-10-23-10-59-57.zip', '2018-10-23');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (40, 'backup-on-2018-10-24-00-09-03.zip', '2018-10-24');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (41, 'backup-on-2018-10-25-12-20-46.zip', '2018-10-25');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (42, 'backup-on-2018-10-26-11-29-06.zip', '2018-10-26');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (43, 'backup-on-2018-10-27-10-55-11.zip', '2018-10-27');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (44, 'backup-on-2018-10-28-14-28-40.zip', '2018-10-28');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (45, 'backup-on-2018-10-29-12-19-07.zip', '2018-10-29');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (46, 'backup-on-2018-10-30-16-47-35.zip', '2018-10-30');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (47, 'backup-on-2018-10-31-10-13-08.zip', '2018-10-31');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (48, 'backup-on-2018-11-01-10-57-52.zip', '2018-11-01');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (49, 'backup-on-2018-11-02-10-46-53.zip', '2018-11-02');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (50, 'backup-on-2018-11-03-00-34-55.zip', '2018-11-03');


#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS bed_details;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS card;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO card (`id`, `name`, `date`, `status`) VALUES (1, 'Credit Card', '0000-00-00', 1);
INSERT INTO card (`id`, `name`, `date`, `status`) VALUES (2, 'Debit Card', '0000-00-00', 1);


#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS cash_bill;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS cashbill_details;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO cashbill_details (`id`, `date`, `invoicedate`, `invoiceno`, `customerId`, `customername`, `cust_mobno`, `address`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `systemDate`) VALUES (1, '2018-08-24', '2018-08-24', '001', 1, 'Anbu', '09876543210', '#123,abcd nagar,muthu pallam<br />\n2nd street,coimbatore', 'intrastate', 'sgst', 'cgst', '', 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '105', '10', '1050.00', '0', 'percent_wise', '0.00', '1050.00', '9', '94.50', '9', '94.50', '18', '0', '1239.00', '1239.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1239.00', '001240818', '001-2018', 1, 1, '0000-00-00');
INSERT INTO cashbill_details (`id`, `date`, `invoicedate`, `invoiceno`, `customerId`, `customername`, `cust_mobno`, `address`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `systemDate`) VALUES (2, '2018-09-25', '2018-09-25', '002', 2, 'ashok', '', '', 'intrastate', 'sgst', 'cgst', '', 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '105', '120', '12600.00', '0', 'percent_wise', '0.00', '12600.00', '9', '1134.00', '9', '1134.00', '18', '0', '14868.00', '15868.00', '', '', '0.00', '', '0.00', '', '', '0.00', '1000', '0', '0.00', '0', '0.00', '0', '', '1000.00', '0', '0', '1', '15868.00', '002250918', '002-2018', 1, 1, '0000-00-00');
INSERT INTO cashbill_details (`id`, `date`, `invoicedate`, `invoiceno`, `customerId`, `customername`, `cust_mobno`, `address`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `systemDate`) VALUES (3, '2018-10-29', '2018-10-29', '003', 3, 'grt', '987654321', '', 'intrastate', 'sgst', 'cgst', '', '12345', 'tissue paper', 'Nos', '1000', '50', '50000.00', '0', 'percent_wise', '0.00', '50000.00', '9', '4500.00', '9', '4500.00', '18', '0', '59000.00', '59000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '59000.00', '003291018', '003-2018', 1, 1, '0000-00-00');


#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS cashbill_reports;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '0000-00-00', '2018-08-24', '001', '2018-08-24', NULL, 0, 'Anbu', '09876543210', '#123,abcd nagar,muthu pallam\n2nd street,coimbatore', 'intrastate', 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '105', '10', '1239.00', NULL, '1239.00', NULL, NULL, '1239.00', NULL, NULL, '1', '001-2018', '001240818', '1');
INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '0000-00-00', '2018-09-25', '002', '2018-09-25', NULL, 0, 'ashok', '', '', 'intrastate', 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '105', '120', '14868.00', NULL, '15868.00', NULL, NULL, '15868.00', NULL, NULL, '1', '002-2018', '002250918', '2');
INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '0000-00-00', '2018-10-29', '003', '2018-10-29', NULL, 0, 'grt', '987654321', '', 'intrastate', '12345', NULL, 'tissue paper', '1000', '50', '59000.00', NULL, '59000.00', NULL, NULL, '59000.00', NULL, NULL, '1', '003-2018', '003291018', '3');


#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS category;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS collection_details;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2018-09-20', NULL, '2018-09-20', NULL, 'R001', 'Arul', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '1000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2018-09-20', NULL, '2018-09-20', NULL, 'R', 'Arul', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '20000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '2018-09-24', NULL, '2018-09-24', NULL, 'R1', 'Arul', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '1000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '2018-09-25', NULL, '2018-09-25', NULL, 'R2', 'ragul', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '205821.06', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '2018-10-04', NULL, '2018-10-04', NULL, 'R5', 's corts', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Bank ICICI BANK', NULL, NULL, NULL, NULL, '400000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '2018-10-29', NULL, '2018-10-29', NULL, 'R7', 'Arul', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Bank KARUR VYSYA BANK', NULL, NULL, NULL, NULL, '50000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '2018-10-29', NULL, '2018-10-29', NULL, 'R8', 'Balaji', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '20000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '2018-10-29', NULL, '2018-10-29', NULL, 'R9', 'Balaji', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cheque ING VYSYA 121212', NULL, NULL, NULL, NULL, '20000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '2018-10-29', NULL, '2018-10-29', NULL, 'R10', 'SRINIVASAREDDY R', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '50000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '2018-10-29', NULL, '2018-10-29', NULL, 'R11', 'SRINIVASAREDDY R', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '145000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '2018-11-02', NULL, '2018-11-02', NULL, 'R12', 'Arul', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '1000', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS company_logo;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO company_logo (`id`, `date`, `image`, `status`) VALUES (1, '2017-12-27', 'images.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS customer_details;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (1, '2018-08-24', 'Intra customer', 'Arul', '', '', '10th street, west main road', 'near by indian bank.', '', 'Tamil nadu', 'coimbatore', '', '', NULL, '0.00', '281924.15', '1000', '280230.45', '67112.85', '', NULL, '641502', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (2, '2018-08-24', 'Intra customer', 'Balaji', '9500480360', '', 'kamaraj nagar,', 'Trichy road', '', 'Tamil Nadu', 'Karur', '', '', NULL, '0.00', '515983.44', '20000', '596131.62', '7294.00', '', NULL, '641502', NULL, NULL, NULL, NULL, NULL, '1', '', '', '55', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (3, '2018-09-23', 'Intra customer', 'karthik', '', '', 'xfdf', '23,ht', '', 'tn', 'chennai', '', '', NULL, '0.00', '36453.87', NULL, '36453.87', NULL, '', NULL, '600034', NULL, NULL, NULL, NULL, NULL, '1', '', '', '600023av', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (4, '2018-09-25', 'Intra customer', 'ragul', '', '', 'peelamedu', 'cbe', '', 'tamilnadu', 'cbe', '', '', NULL, '0.00', '1926.8', '205821.06', '-203894.26', NULL, '', NULL, '641004', NULL, NULL, NULL, NULL, NULL, '1', '', '', '641004', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (5, '2018-09-25', 'Intra supplier', 'kumar', '', '', 'cbe', 'cbe north', '', 'tn', 'cbe', '', '', NULL, '0.00', '410323.59', '12890', '185882.99', NULL, '', NULL, '642612', NULL, NULL, NULL, NULL, NULL, '1', '', '', 'tn', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (6, '2018-10-04', 'Inter customer', 's corts', '', '', 'lat 115', ' set 24 ', '', 'hariyana', 'faridabadh', '', '', NULL, '100000', '13531575', '400000', '47768745', NULL, '', NULL, '121005', NULL, NULL, NULL, NULL, NULL, '1', '', '', '06', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (7, '2018-10-04', 'Intra supplier', 'mn industry', '', '', 'zone street  68', 'paries corner ', '', 'tamin nadu', 'chennai', '', '', NULL, '150000', '265747.8', '5000', '210747.8', NULL, '', NULL, '600001', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (8, '2018-10-29', 'Inter customer', 'SRINIVASAREDDY R', '9008169736', '', 'MARSUR (VOP)', 'ANEKAL', 'RAMAREDDY', 'KARANADAKA', 'ANEKAL', '', '', NULL, '0.00', '677900', '145000', '482900', NULL, '', NULL, '560520', NULL, NULL, NULL, NULL, NULL, '1', '', '', '34', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (9, '2018-11-02', 'Intra customer', 'SAINT GOBIAN', '', '', 'MAINROAD', 'CHENNAI', '', 'TAMILNADU', 'CHENNAI', '', '', NULL, '50000', '11200.00', NULL, '61200', NULL, '', NULL, '600028', NULL, NULL, NULL, NULL, NULL, '1', '', '', '12345', '3456bjhnjhuw', '', '', '', '');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS customerpo_details;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS dc_delivery;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (1, '2018-10-30', 1, NULL, 'Direct DC', 'D', '2018-10-30', 9, 'SAINT GOBIAN', 'TN 18S 0327', 'MAINROAD, CHENNAI', NULL, NULL, NULL, 'FILTERBAG', '', '10', '0', 'FIST', '5211', 'Nos', 'D-18', 'D301018', 1, 0);


#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS dcbill_details;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (1, '2018-10-30', 'Direct DC', 'D', '2018-10-30', 9, 'SAINT GOBIAN', 'TN 18S 0327', 'MAINROAD, CHENNAI', NULL, NULL, NULL, 'FILTERBAG', '', '10', 'FIST', '5211', 'Nos', 'D-18', 'D301018', 1, 0, '');


#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (1, '2018-10-04', '001', 'raja', '2018-10-04', 'salary advance', 'Cash', '0', '', '', '0', '', '5000', 'Credit Card', 'Cash', '5000', '1', 'salary', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (2, '2018-10-07', '002', 'pandian', '2018-10-06', 'sep salary', 'Cash', '0', '', '', '0', '', '10000', 'Credit Card', 'Cash', '10000', '1', 'salary', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (3, '2018-10-24', '003', 'raja', '2018-10-24', 'advance', 'Cash', '0', '', '', '0', '', '1000', 'Credit Card', 'Cash', '1000', '1', 'salary', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (4, '2018-10-27', '004', 'saran', '2018-10-27', 'advance', 'Cash', '0', '', '', '0', '', '200', 'Credit Card', 'Cash', '200', '1', 'eb bill', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (5, '2018-10-29', '005', 'SRINIVASAREDDY R', '2018-10-29', 'S234455555555', 'Cash', '0', '', '', '0', '', '50000', 'Credit Card', 'Cash', '50000', '1', 'maintance', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (6, '2018-10-29', '006', 'SRINIVASAREDDY R', '2018-10-29', 'POOJAI', 'Cash', '0', '', '', '0', '', '200', 'Credit Card', 'Cash', '200', '1', 'maintance', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (7, '2018-10-29', '007', 'SRINIVASAREDDY R', '2018-10-29', 'FULE', 'Cash', '0', '', '', '0', '', '500', 'Credit Card', 'Cash', '500', '1', 'maintance', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (8, '2018-10-30', '008', 'SAMSON', '2018-10-30', 'ADVANCE', 'Cash', '0', '', '', '0', '', '5000', 'Credit Card', 'Cash', '5000', '1', 'salary', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (10, '2018-10-31', '009', 'SAMSON', '2018-10-31', 'advance', 'Cash', '0', '', '', '0', '', '5000', 'Credit Card', 'Cash', '5000', '1', 'eb bill', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (11, '2018-10-31', '010', 'dddddddd', '2018-10-31', 'ggggg', 'Cash', '0', '', '', '0', '', '0', 'Credit Card', 'Cash', NULL, '1', 'eb bill', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (12, '2018-10-31', '011', 'SAMSON', '2018-10-31', 'ADVANCE', 'Cash', '0', '', '', '0', '', '1000', 'Credit Card', 'Cash', '1000', '1', 'salary', '');


#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS headers;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (1, '2018-10-04', 1, 'salary');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (2, '2018-10-04', 1, 'eb bill');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (3, '2018-10-24', 1, 'eb');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (4, '2018-10-24', 1, 'salary');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (5, '2018-10-25', 1, 'maintance');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (6, '2018-10-27', 1, 'teaboy');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (7, '2018-10-29', 1, 'tea ');


#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS invoice_details;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (1, '2018-10-29', '2018-10-29', '101', '2018-10-29', 'INV', NULL, 'Sales Invoice', 'Direct Invoice', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'Trichy', 'Trucks', 'TN 38 PR 54120', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '015', 'Monitor', '', 'Nos', '3520', '10', '29830.51', '0', 'percent_wise', '0.00', '35200.00', '9', '2684.75', '9', '2684.75', '18', '5369.49', '35200.00', '35200.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '35200.00', 'INV291018', 'INV-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (2, '2018-10-29', '2018-10-29', '5102', '2018-10-31', 'INV1', NULL, 'Sales Invoice', 'Direct Invoice', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '', 'Trucks', 'TN 38 PR 5102', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '015', 'Monitor', '', 'Nos', '3520', '10', '29830.51', '0', 'percent_wise', '0.00', '35200.00', '9', '2684.75', '9', '2684.75', '18', '5369.49', '35200.00', '35200.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '35200.00', 'INV1291018', 'INV1-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (5, '2018-10-29', '2018-10-29', '101', '2018-10-30', 'INV2', NULL, 'Sales Invoice', 'Direct Invoice', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '', 'Van', 'TN 38 PR8520', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '015||101||ra001', 'Monitor||test||sample', '||||', 'Nos||set||123', '3520||120||100', '1||10||2', '2983.05||1200.00||200.00', '0||0||0', 'percent_wise', '0.00||0.00||0.00', '3520.00||1200.00||200.00', '9||6||2.5', '268.47||72.00||5.00', '9||6||2.5', '268.47||72.00||5.00', '18||12||5', '536.95||144.00||10.00', '3520.00||1344.00||210.00', '5074.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1', '5074.00', 'INV2291018', 'INV2-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (6, '2018-10-29', '2018-10-29', '', '1970-01-01', 'INV3', NULL, 'Sales Invoice', 'Direct Invoice', 0, 'Balaji', 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'Coimbatore', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '99752', 'Iinstalation m couch', 's32334444', 'set', '70000', '1', '70000.00', '0', 'percent_wise', '0.00', '70000.00', '9', '6300.00', '9', '6300.00', '18', '12600.00', '82600.00', '82600.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '82600.00', NULL, NULL, 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (7, '2018-10-29', '2018-10-29', '', '1970-01-01', 'INV4', NULL, 'Sales Invoice', 'Direct Invoice', 8, 'SRINIVASAREDDY R', 'MARSUR (VOP), ANEKAL, ANEKAL, KARANADAKA', 'KA', '', '', 'interstate', 'interstate', '', '', 'igst', NULL, '0', NULL, '151515', 'MF 5245 PD', 's32334444', 'Nos', '600000', '1', '600000.00', '0', 'percent_wise', '0.00', '600000.00', '6', '36000.00', '6', '36000.00', '12', '72000.00', '672000.00', '672000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '672000.00', 'INV4291018', 'INV4-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (8, '2018-10-29', '2018-10-29', '', '1970-01-01', 'INV5', NULL, 'Sales Invoice', 'Direct Invoice', 2, 'Balaji', 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '151515||PJEB050', 'MF 5245 PD||Aluminium Body 109.3 x 148', 's32334444||12121212', 'Nos||Nos', '50000||105', '1||1', '50000.00||105.00', '0||0', 'percent_wise', '0.00||0.00', '50000.00||105.00', '6||9', '3000.00||9.45', '6||9', '3000.00||9.45', '12||18', '6000.00||18.90', '56000.00||123.90', '56123.90', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '56123.90', 'INV5291018', 'INV5-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (9, '2018-10-29', '2018-10-29', '2', '2018-10-29', 'INV6', NULL, 'Sales Invoice', 'Direct Invoice', 8, 'SRINIVASAREDDY R', 'MARSUR (VOP), ANEKAL, ANEKAL, KARANADAKA', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '12345', 'tissue paper', '', 'Nos', '500', '10', '5000.00', '0', 'percent_wise', '0.00', '5000.00', '9', '450.00', '9', '450.00', '18', '900.00', '5900.00', '5900.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '5900.00', 'INV6291018', 'INV6-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (10, '2018-10-29', '2018-10-29', '', '1970-01-01', 'INV7', NULL, 'Sales Invoice', 'Direct Invoice', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, 'ra001||101||998898', 'sample||test||bush u', '||||', '123||set||Nos', '100||120||300', '10||10||10', '1000.00||1200.00||3000.00', '0||0||0', 'percent_wise', '0.00||0.00||0.00', '1000.00||1200.00||3000.00', '2.5||6||14', '25.00||72.00||420.00', '2.5||6||14', '25.00||72.00||420.00', '5||12||28', '50.00||144.00||840.00', '1050.00||1344.00||3840.00', '6234.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1', '6234.00', 'INV7291018', 'INV7-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (11, '2018-10-30', '2018-10-30', '', '1970-01-01', 'INV8', 'D', 'Sales Invoice', 'Against DC', 9, 'SAINT GOBIAN', 'MAINROAD, CHENNAI, CHENNAI, TAMILNADU', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'D', '1', '1', '5211', 'FILTERBAG', '', 'Nos', '1000', '10', '10000.00', '0', 'percent_wise', '', '10000.00', '6', '600.00', '6', '600.00', '12', '', '11200.00', '11200.00', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '0', '0', '0', '1', '11200.00', 'INV8301018', 'INV8-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (12, '2018-11-01', '2018-11-01', '101', '2018-11-07', 'INV9', NULL, 'Sales Invoice', 'Direct Invoice', 2, 'Balaji', 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', '', 'VAN', 'TN 48  PR 4101', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '3003||3003||3003||3003||3003||3003', 'SAFOOF BODY MASS  1 KGS||SAFOOF BODY MASS  1 KGS||SAFOOF BODY MASS  1 KGS||SAFOOF TURBO MASS 1KGS||SAFOOF TURBO MASS 1KGS||SAFOOF MAGA PRO 3 KGS', '||||||||||', 'kgs||kgs||kgs||kgs||kgs||kgs', '699||2116||2850||849||2223||4421', '60||96||28||12||24||12', '37446.43||181371.43||71250.00||9096.43||47635.71||47367.86', '0||0||0||0||0||0', 'percent_wise', '0.00||0.00||0.00||0.00||0.00||0.00', '41940.00||203136.00||79800.00||10188.00||53352.00||53052.00', '6||6||6||6||6||6', '2246.79||10882.29||4275.00||545.79||2858.14||2842.07', '6||6||6||6||6||6', '2246.79||10882.29||4275.00||545.79||2858.14||2842.07', '12||12||12||12||12||12', '4493.57||21764.57||8550.00||1091.57||5716.29||5684.14', '41940.00||203136.00||79800.00||10188.00||53352.00||53052.00', '441468.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1||1||1', '441468.00', 'INV9011118', 'INV9-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (13, '2018-11-02', '2018-11-02', '', '1970-01-01', 'INV10', NULL, 'Sales Invoice', 'Direct Invoice', 0, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '12345||4823', 'tissue paper||Paper Based Laminated 7MM', '||', 'Nos||Nos', '1000||1.05', '2||1', '2000.00||1.05', '0||0', 'percent_wise', '0.00||0.00', '2000.00||1.05', '9||9', '180.00||0.09', '9||9', '180.00||0.09', '18||18', '360.00||0.19', '2360.00||1.24', '2361.24', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '2361.24', NULL, NULL, 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (14, '2018-11-02', '2018-11-02', '', '1970-01-01', 'INV11', NULL, 'Sales Invoice', 'Direct Invoice', 2, 'Balaji', 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, 'ra001', 'sample', '', '123', '100', '2', '200.00', '0', 'percent_wise', '0.00', '200.00', '2.5', '5.00', '2.5', '5.00', '5', '10.00', '210.00', '210.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '210.00', 'INV11021118', 'INV11-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (15, '2018-11-02', '2018-11-02', '101', '2018-11-01', 'INV12', NULL, 'Sales Invoice', 'Direct Invoice', 2, 'Balaji', 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'trichy', 'van', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '101', 'pencil', '', 'Nos', '5', '1', '4.24', '0', 'percent_wise', '0.00', '5.00', '9', '0.38', '9', '0.38', '18', '0.76', '5.00', '5.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '5.00', 'INV12021118', 'INV12-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (16, '2018-11-02', '2018-11-02', '', '1970-01-01', 'INV13', NULL, 'Sales Invoice', 'Direct Invoice', 2, 'Balaji', 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '102', 'eraser', '', 'Nos', '10', '2', '16.95', '0', 'percent_wise', '0.00', '20.00', '9', '1.53', '9', '1.53', '18', '3.05', '20.00', '20.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '20.00', 'INV13021118', 'INV13-2018', 1, 1);


#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS invoice_party_statement;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2018-10-29', 'INV', 1, 'Arul', '', '', '', 'Monitor', '', '', '', NULL, NULL, '', '', '1', '2018-10-29', '2018-10-29', '35200.00', '-', '-', '', '', '-', '-', NULL, '282361.21', '-', '-', '-', '-', '35200.00', '-', '35200.00', NULL, NULL, 'INV-2018', 'INV291018', '1');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '-', '-', NULL, '2018-10-29', 'INV1', 1, 'Arul', '', '', '', 'Monitor', '', '', '', NULL, NULL, '', '', '1', '2018-10-29', '2018-10-29', '35200.00', '-', '-', '', '', '-', '-', NULL, '317561.21', '-', '-', '-', '-', '35200.00', '-', '35200.00', NULL, NULL, 'INV1-2018', 'INV1291018', '2');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, 'R7', '', NULL, '2018-10-29', '-', 0, 'Arul', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2018-10-29', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '267561.21', NULL, NULL, NULL, 'Bank KARUR VYSYA BANK', NULL, '50000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '-', '-', NULL, '2018-10-29', 'INV2', 1, 'Arul', '', '', '', 'Monitor||test||sample', '||||', '', '', NULL, NULL, '', '', '1', '2018-10-29', '2018-10-29', '5074.00', '-', '-', '', '', '-', '-', NULL, '272635.21', '-', '-', '-', '-', '5074.00', '-', '5074.00', NULL, NULL, 'INV2-2018', 'INV2291018', '5');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '-', '-', NULL, '2018-10-29', 'INV3', 2, 'Balaji', '', '', '', 'Iinstalation m couch', 's32334444', '', '', NULL, NULL, '', '', '1', '2018-10-29', '2018-10-29', '82600.00', '-', '-', '', '', '-', '-', NULL, '138304.72', '-', '-', '-', '-', '82600.00', '-', '82600.00', NULL, NULL, NULL, NULL, '6');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, 'R8', '', NULL, '2018-10-29', '-', 0, 'Balaji', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2018-10-29', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '118304.72', NULL, NULL, NULL, 'Cash', NULL, '20000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, 'R9', '', NULL, '2018-10-29', '-', 0, 'Balaji', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2018-10-29', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '98304.72', NULL, NULL, NULL, 'Cheque ING VYSYA 121212', NULL, '20000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '-', '-', NULL, '2018-10-29', 'INV4', 8, 'SRINIVASAREDDY R', '', '', '', 'MF 5245 PD', 's32334444', '', '', NULL, NULL, '', '', '1', '2018-10-29', '2018-10-29', '672000.00', '-', '-', '', '', '-', '-', NULL, '672000', '-', '-', '-', '-', '672000.00', '-', '672000.00', NULL, NULL, 'INV4-2018', 'INV4291018', '7');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, 'R10', '', NULL, '2018-10-29', '-', 0, 'SRINIVASAREDDY R', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2018-10-29', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '622000', NULL, NULL, NULL, 'Cash', NULL, '50000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, 'R11', '', NULL, '2018-10-29', '-', 0, 'SRINIVASAREDDY R', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2018-10-29', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '477000', NULL, NULL, NULL, 'Cash', NULL, '145000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '-', '-', NULL, '2018-10-29', 'INV5', 2, 'Balaji', '', '', '', 'MF 5245 PD||Aluminium Body 109.3 x 148', 's32334444||12121212', '', '', NULL, NULL, '', '', '1', '2018-10-29', '2018-10-29', '56123.90', '-', '-', '', '', '-', '-', NULL, '154428.62', '-', '-', '-', '-', '56123.90', '-', '56123.90', NULL, NULL, 'INV5-2018', 'INV5291018', '8');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '-', '-', NULL, '2018-10-29', 'INV6', 8, 'SRINIVASAREDDY R', '', '', '', 'tissue paper', '', '', '', NULL, NULL, '', '', '1', '2018-10-29', '2018-10-29', '5900.00', '-', '-', '', '', '-', '-', NULL, '482900', '-', '-', '-', '-', '5900.00', '-', '5900.00', NULL, NULL, 'INV6-2018', 'INV6291018', '9');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '-', '-', NULL, '2018-10-29', 'INV7', 1, 'Arul', '', '', '', 'sample||test||bush u', '||||', '', '', NULL, NULL, '', '', '1', '2018-10-29', '2018-10-29', '6234.00', '-', '-', '', '', '-', '-', NULL, '278869.21', '-', '-', '-', '-', '6234.00', '-', '6234.00', NULL, NULL, 'INV7-2018', 'INV7291018', '10');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '-', '-', NULL, '2018-10-30', 'INV8', 9, 'SAINT GOBIAN', '', '', '', 'FILTERBAG', '', '', '', NULL, NULL, '', '', '1', '2018-10-30', '2018-10-30', '11200.00', '-', '-', '', '', '-', '-', NULL, '61200', '-', '-', '-', '-', '11200.00', '-', '11200.00', NULL, NULL, 'INV8-2018', 'INV8301018', '11');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '-', '-', NULL, '2018-11-01', 'INV9', 2, 'Balaji', '', '', '', 'SAFOOF BODY MASS  1 KGS||SAFOOF BODY MASS  1 KGS||SAFOOF BODY MASS  1 KGS||SAFOOF TURBO MASS 1KGS||SAFOOF TURBO MASS 1KGS||SAFOOF MAGA PRO 3 KGS', '||||||||||', '', '', NULL, NULL, '', '', '1', '2018-11-01', '2018-11-01', '441468.00', '-', '-', '', '', '-', '-', NULL, '595896.62', '-', '-', '-', '-', '441468.00', '-', '441468.00', NULL, NULL, 'INV9-2018', 'INV9011118', '12');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '-', '-', NULL, '2018-11-02', 'INV10', 1, 'Arul', '', '', '', 'tissue paper||Paper Based Laminated 7MM', '||', '', '', NULL, NULL, '', '', '1', '2018-11-02', '2018-11-02', '2361.24', '-', '-', '', '', '-', '-', NULL, '281230.45', '-', '-', '-', '-', '2361.24', '-', '2361.24', NULL, NULL, NULL, NULL, '13');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, 'R12', '', NULL, '2018-11-02', '-', 0, 'Arul', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2018-11-02', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '280230.45', NULL, NULL, NULL, 'Cash', NULL, '1000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '-', '-', NULL, '2018-11-02', 'INV11', 2, 'Balaji', '', '', '', 'sample', '', '', '', NULL, NULL, '', '', '1', '2018-11-02', '2018-11-02', '210.00', '-', '-', '', '', '-', '-', NULL, '596106.62', '-', '-', '-', '-', '210.00', '-', '210.00', NULL, NULL, 'INV11-2018', 'INV11021118', '14');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (23, '-', '-', NULL, '2018-11-02', 'INV12', 2, 'Balaji', '', '', '', 'pencil', '', '', '', NULL, NULL, '', '', '1', '2018-11-02', '2018-11-02', '5.00', '-', '-', '', '', '-', '-', NULL, '596111.62', '-', '-', '-', '-', '5.00', '-', '5.00', NULL, NULL, 'INV12-2018', 'INV12021118', '15');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (24, '-', '-', NULL, '2018-11-02', 'INV13', 2, 'Balaji', '', '', '', 'eraser', '', '', '', NULL, NULL, '', '', '1', '2018-11-02', '2018-11-02', '20.00', '-', '-', '', '', '-', '-', NULL, '596131.62', '-', '-', '-', '-', '20.00', '-', '20.00', NULL, NULL, 'INV13-2018', 'INV13021118', '16');


#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS invoice_reports;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2018-10-29', 'INV', '2018-10-29', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', 'Trichy', 'TN 38 PR 54120', NULL, '2018-10-29', '101', NULL, '015', NULL, 'Monitor', '', '3', '10', '3', NULL, '35200.00', NULL, NULL, '35200.00', NULL, NULL, '1', 'INV-2018', 'INV291018', '1');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2018-10-29', 'INV1', '2018-10-29', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', 'TN 38 PR 5102', NULL, '2018-10-31', '5102', NULL, '015', NULL, 'Monitor', '', '3', '10', '3', NULL, '35200.00', NULL, NULL, '35200.00', NULL, NULL, '1', 'INV1-2018', 'INV1291018', '2');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '2018-10-29', 'INV2', '2018-10-29', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', 'TN 38 PR8520', NULL, '2018-10-30', '101', NULL, '015', NULL, 'Monitor', '', '3', '1', '3', NULL, '5074.00', NULL, NULL, '5074.00', NULL, NULL, '1', 'INV2-2018', 'INV2291018', '5');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '2018-10-29', 'INV2', '2018-10-29', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', 'TN 38 PR8520', NULL, '2018-10-30', '101', NULL, '101', NULL, 'test', '', '5', '10', '5', NULL, '5074.00', NULL, NULL, '5074.00', NULL, NULL, '1', 'INV2-2018', 'INV2291018', '5');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '2018-10-29', 'INV2', '2018-10-29', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', 'TN 38 PR8520', NULL, '2018-10-30', '101', NULL, 'ra001', NULL, 'sample', '', '2', '2', '2', NULL, '5074.00', NULL, NULL, '5074.00', NULL, NULL, '1', 'INV2-2018', 'INV2291018', '5');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, '2018-10-29', 'INV3', '2018-10-29', NULL, NULL, 0, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', 'Coimbatore', '', NULL, '1970-01-01', '', NULL, '99752', NULL, 'Iinstalation m couch', 's32334444', '70000', '1', '82600.00', NULL, '82600.00', NULL, NULL, '82600.00', NULL, NULL, '1', NULL, NULL, '6');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '2018-10-29', 'INV4', '2018-10-29', NULL, NULL, 8, 'SRINIVASAREDDY R', NULL, NULL, NULL, 'MARSUR (VOP), ANEKAL, ANEKAL, KARANADAKA', 'interstate', 'interstate', 'KA', '', NULL, '1970-01-01', '', NULL, '151515', NULL, 'MF 5245 PD', 's32334444', '6', '1', '6', NULL, '672000.00', NULL, NULL, '672000.00', NULL, NULL, '1', 'INV4-2018', 'INV4291018', '7');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '2018-10-29', 'INV5', '2018-10-29', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '151515', NULL, 'MF 5245 PD', 's32334444', '5', '1', '5', NULL, '56123.90', NULL, NULL, '56123.90', NULL, NULL, '1', 'INV5-2018', 'INV5291018', '8');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '2018-10-29', 'INV5', '2018-10-29', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '12121212', '0', '1', '6', NULL, '56123.90', NULL, NULL, '56123.90', NULL, NULL, '1', 'INV5-2018', 'INV5291018', '8');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '2018-10-29', 'INV6', '2018-10-29', NULL, NULL, 8, 'SRINIVASAREDDY R', NULL, NULL, NULL, 'MARSUR (VOP), ANEKAL, ANEKAL, KARANADAKA', 'intrastate', 'intrastate', '', '', NULL, '2018-10-29', '2', NULL, '12345', NULL, 'tissue paper', '', '5', '10', '5', NULL, '5900.00', NULL, NULL, '5900.00', NULL, NULL, '1', 'INV6-2018', 'INV6291018', '9');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '2018-10-29', 'INV7', '2018-10-29', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, 'ra001', NULL, 'sample', '', '1', '10', '1', NULL, '6234.00', NULL, NULL, '6234.00', NULL, NULL, '1', 'INV7-2018', 'INV7291018', '10');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (19, '2018-10-29', 'INV7', '2018-10-29', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '101', NULL, 'test', '', '0', '10', '0', NULL, '6234.00', NULL, NULL, '6234.00', NULL, NULL, '1', 'INV7-2018', 'INV7291018', '10');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '2018-10-29', 'INV7', '2018-10-29', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '998898', NULL, 'bush u', '', '0', '10', '5', NULL, '6234.00', NULL, NULL, '6234.00', NULL, NULL, '1', 'INV7-2018', 'INV7291018', '10');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, '2018-10-30', 'INV8', '2018-10-30', NULL, NULL, 9, 'SAINT GOBIAN', NULL, NULL, NULL, 'MAINROAD, CHENNAI, CHENNAI, TAMILNADU', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '5211', NULL, 'FILTERBAG', '', '1', '10', '1', NULL, '11200.00', NULL, NULL, '11200.00', NULL, NULL, '1', 'INV8-2018', 'INV8301018', '11');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '2018-11-01', 'INV9', '2018-11-01', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', 'TN 48  PR 4101', NULL, '2018-11-07', '101', NULL, '3003', NULL, 'SAFOOF BODY MASS  1 KGS', '', '6', '60', '4', NULL, '441468.00', NULL, NULL, '441468.00', NULL, NULL, '1', 'INV9-2018', 'INV9011118', '12');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (23, '2018-11-01', 'INV9', '2018-11-01', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', 'TN 48  PR 4101', NULL, '2018-11-07', '101', NULL, '3003', NULL, 'SAFOOF BODY MASS  1 KGS', '', '9', '96', '1', NULL, '441468.00', NULL, NULL, '441468.00', NULL, NULL, '1', 'INV9-2018', 'INV9011118', '12');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (24, '2018-11-01', 'INV9', '2018-11-01', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', 'TN 48  PR 4101', NULL, '2018-11-07', '101', NULL, '3003', NULL, 'SAFOOF BODY MASS  1 KGS', '', '9', '28', '9', NULL, '441468.00', NULL, NULL, '441468.00', NULL, NULL, '1', 'INV9-2018', 'INV9011118', '12');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (25, '2018-11-01', 'INV9', '2018-11-01', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', 'TN 48  PR 4101', NULL, '2018-11-07', '101', NULL, '3003', NULL, 'SAFOOF TURBO MASS 1KGS', '', '|', '12', '4', NULL, '441468.00', NULL, NULL, '441468.00', NULL, NULL, '1', 'INV9-2018', 'INV9011118', '12');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (26, '2018-11-01', 'INV9', '2018-11-01', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', 'TN 48  PR 4101', NULL, '2018-11-07', '101', NULL, '3003', NULL, 'SAFOOF TURBO MASS 1KGS', '', '|', '24', '0', NULL, '441468.00', NULL, NULL, '441468.00', NULL, NULL, '1', 'INV9-2018', 'INV9011118', '12');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (27, '2018-11-01', 'INV9', '2018-11-01', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', 'TN 48  PR 4101', NULL, '2018-11-07', '101', NULL, '3003', NULL, 'SAFOOF MAGA PRO 3 KGS', '', '2', '12', '.', NULL, '441468.00', NULL, NULL, '441468.00', NULL, NULL, '1', 'INV9-2018', 'INV9011118', '12');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (29, '2018-11-02', 'INV10', '2018-11-02', NULL, NULL, 0, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '12345', NULL, 'tissue paper', '', '1000', '2', '2360.00', NULL, '2361.24', NULL, NULL, '2361.24', NULL, NULL, '1', NULL, NULL, '13');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (30, '2018-11-02', 'INV10', '2018-11-02', NULL, NULL, 0, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '4823', NULL, 'Paper Based Laminated 7MM', '', '1.05', '1', '1.24', NULL, '2361.24', NULL, NULL, '2361.24', NULL, NULL, '1', NULL, NULL, '13');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (31, '2018-11-02', 'INV11', '2018-11-02', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, 'ra001', NULL, 'sample', '', '1', '2', '2', NULL, '210.00', NULL, NULL, '210.00', NULL, NULL, '1', 'INV11-2018', 'INV11021118', '14');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (32, '2018-11-02', 'INV12', '2018-11-02', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', 'trichy', '', NULL, '2018-11-01', '101', NULL, '101', NULL, 'pencil', '', '5', '1', '5', NULL, '5.00', NULL, NULL, '5.00', NULL, NULL, '1', 'INV12-2018', 'INV12021118', '15');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (33, '2018-11-02', 'INV13', '2018-11-02', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '102', NULL, 'eraser', '', '1', '2', '2', NULL, '20.00', NULL, NULL, '20.00', NULL, NULL, '1', 'INV13-2018', 'INV13021118', '16');


#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS inward_delivery;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (1, 1, '2018-11-02', 'I', '2018-11-02', 'Arul', '10th street, west main road, near by indian bank.', '1001', '2018-11-02', 'sample', '', '1', '1', 'fgggg', 'ra001', '123', 'I-18', 'I021118', 1, 1);


#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS inward_details;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (1, '2018-11-02', 'I', '2018-11-02', 'Arul', '10th street, west main road, near by indian bank.', '1001', '2018-11-02', 'sample', '', '1', 'fgggg', 'ra001', '123', 'I-18', 'I021118', 1, 1, '1');


#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS job_data;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS job_details;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS jobinward_data;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS jobinward_details;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS login_details;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (1, 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'Myoffice!@#$%', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (5, 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', 1, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (6, 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', 0, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (7, 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', 0, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (8, 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', 1, 0, 0);


#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS po_party_statements;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2018-09-25', '2018-09-25', '-', 'P001', 5, 'kumar', NULL, NULL, 'Aluminium Body 109.3 x 148', NULL, '12890.00', '-', '-', '-', NULL, '-', '12890', NULL, '-', '-', '-', '-', '-', '12390.00', '-', NULL, '-', NULL, '12890.00', NULL, '002', '2018-09-25', '1', 'P001250918', 'P001-2018', '1');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2018-09-25', NULL, 'R3', NULL, 0, 'kumar', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '12890', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (3, '2018-10-04', '2018-10-04', '-', 'P002', 7, 'mn industry', NULL, NULL, 'Iinstalation m couch', NULL, '265500.00', '-', '-', '-', NULL, '-', '415500', NULL, '-', '-', '-', '-', '-', '265500.00', '-', NULL, '-', NULL, '265500.00', NULL, '2', '2018-10-04', '1', 'P002041018', 'P002-2018', '2');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (4, '2018-10-04', NULL, 'R4', NULL, 0, 'mn industry', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '215500', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank STATE BANK OF INDIA', NULL, '200000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (5, '2018-10-18', NULL, 'R6', NULL, 0, 'mn industry', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '210500', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cheque INDIAN OVERSEAS 1111', NULL, '5000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (6, '2018-10-24', '2018-10-24', '-', 'P003', 7, 'mn industry', NULL, NULL, 'Aluminium Body 109.3 x 148', NULL, '247.80', '-', '-', '-', NULL, '-', '210747.8', NULL, '-', '-', '-', '-', '-', '247.80', '-', NULL, '-', NULL, '247.80', NULL, '11', '2018-10-24', '1', 'P003241018', 'P003-2018', '3');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (7, '2018-10-27', '2018-10-27', '-', 'P004', 5, 'kumar', NULL, NULL, 'Paper Based Laminated 7MM', NULL, '12.39', '-', '-', '-', NULL, '-', '-12877.61', NULL, '-', '-', '-', '-', '-', '12.39', '-', NULL, '-', NULL, '12.39', NULL, '12', '2018-10-27', '1', 'P004271018', 'P004-2018', '4');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (9, '2018-11-01', '2018-11-01', '-', 'P005', 0, 'kumar', NULL, NULL, 'SAFOOF BODY MASS  1 KGS||SAFOOF BODY MASS 3 KGS||SAFOOF BODY MASS 5KGS||SAFOOF TURBO MASS 1KGS||SAFOOF TURBO MASS 3 KGS||SAFOOF MAGA PRO 3 KGS', NULL, '198660.60', '-', '-', '-', NULL, '-', '185782.99', NULL, '-', '-', '-', '-', '-', '18873.00||91411.20||35910.00||4584.60||24008.40||23873.40', '-', NULL, '-', NULL, '198660.60', NULL, '101', '2018-11-01', '1', NULL, NULL, '5');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (10, '2018-11-01', '2018-11-02', '-', 'P006', 5, 'kumar', NULL, NULL, 'eraser', NULL, '100.00', '-', '-', '-', NULL, '-', '185882.99', NULL, '-', '-', '-', '-', '-', '100.00', '-', NULL, '-', NULL, '100.00', NULL, '5001', '2018-11-01', '1', 'P006021118', 'P006-2018', '6');


#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS preference_details;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS preference_settings;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO preference_settings (`id`, `quotation`, `expenses`, `dc`, `voucher`, `debit`, `credit`, `purchase`, `invoicePrefix`, `invoice`, `proforma_invoicePrefix`, `proforma_invoice`, `inward`, `cashbill_invoice`, `purchaseorder`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`) VALUES (1, '', '', '', '', '', '001', '', 'INV', '', 'P', '', '', '', '', 'Myoffice Solutions', '04222570103', '8608701222', '#91, Dr. Jaganathan Nagar, ', 'Civil Aerodrome Post', 'Coimbatore', '641 014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '04222570103', '8608701333', '#91, Dr. Jaganathan Nagar, ', 'Civil Aerodrome Post', 'Coimbatore', '641 014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'percent_wise', 'without_stock', 'with_item');


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS profile;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO profile (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`) VALUES (1, NULL, 'Myoffice BILLING', 'Myoffice BILLING', '9943744177', '0422-2668244', ' #91, Dr, Jaganathan Nagar CMC opp', 'Civil Aerodrome Post', 'Dharmapuri', '641035', 'Tamil Nadu', 'info@idreamdevelopers.com', 'www.idreamdevelopers.org', '12345', '54321', '33AFYPV3340K1ZT', '', '1', 'admin', 'Myoffice!@#$%', 'THE KARUR VYSYA BANK LTD.,', '1748115000002961', 'SARAVANAMPATTI', 'KVBL0001748');


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS proforma_invoice_details;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO proforma_invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (1, '2018-09-17', '2018-09-17', '7410', '2018-09-17', 'P001', NULL, 'Sales Invoice', '0', 2, 'Balaji', 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'TRICHY', 'TRUCKS', 'dsfd', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, 'PJEB050', 'Aluminium Body 109.3 x 148', '', 'Nos', '105', '150', '15750.00', '0', 'percent_wise', '0.00', '15750.00', '9', '1417.50', '9', '1417.50', '18', '2835.00', '18585.00', '18585.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '18585.00', 'P001170918', 'P001-2018', 1, 1);
INSERT INTO proforma_invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (2, '2018-09-17', '2018-09-17', '852', '2018-09-17', 'P002', NULL, 'Sales Invoice', '0', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'ERODE', 'Lorry', 'TN 48 PS 9630', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '015', 'Monitor', '', 'Nos', '3520', '20', '59661.02', '0', 'percent_wise', '0.00', '70400.00', '9', '5369.49', '9', '5369.49', '18', '10738.98', '70400.00', '70400.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '70400.00', 'P002170918', 'P002-2018', 1, 1);
INSERT INTO proforma_invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (3, '2018-09-27', '2018-09-27', '8520', '2018-09-27', 'P003', NULL, 'Sales Invoice', '0', 2, 'Balaji', NULL, '', '', '', 'interstate', 'interstate', '', '', 'igst', NULL, '0', NULL, '101||4823||PJEB050', 'test||Paper Based Laminated 7MM||Aluminium Body 109.3 x 148', '||||', 'set||Nos||Nos', '120||1.05||105', '10||15||20', '1200.00||15.75||2100.00', '0||0||0', 'percent_wise', '0.00||0.00||0.00', '1200.00||15.75||2100.00', '6||9||9', '72.00||1.42||189.00', '6||9||9', '72.00||1.42||189.00', '12||18||18', '144.00||2.83||378.00', '1344.00||18.59||2478.00', '3840.59', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1', '3840.59', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS proforma_invoice_reports;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO proforma_invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2018-09-17', 'P001', '2018-09-17', NULL, NULL, 2, 'Balaji', NULL, NULL, NULL, 'kamaraj nagar,, Trichy road, Karur, Tamil Nadu', 'intrastate', 'intrastate', 'TRICHY', 'dsfd', NULL, '2018-09-17', '7410', NULL, 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '', '1', '150', '1', NULL, '18585.00', NULL, NULL, '18585.00', NULL, NULL, '1', 'P001-2018', 'P001170918', '1');
INSERT INTO proforma_invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2018-09-17', 'P002', '2018-09-17', NULL, NULL, 1, 'Arul', NULL, NULL, NULL, '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', 'intrastate', 'intrastate', 'ERODE', 'TN 48 PS 9630', NULL, '2018-09-17', '852', NULL, '015', NULL, 'Monitor', '', '3', '20', '7', NULL, '70400.00', NULL, NULL, '70400.00', NULL, NULL, '1', 'P002-2018', 'P002170918', '2');
INSERT INTO proforma_invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '2018-09-27', 'P003', '2018-09-27', NULL, NULL, 0, 'Balaji', NULL, NULL, NULL, NULL, 'interstate', 'interstate', '', '', NULL, '2018-09-27', '8520', NULL, '101', NULL, 'test', '', '120', '10', '1344.00', NULL, '3840.59', NULL, NULL, '3840.59', NULL, NULL, '1', NULL, NULL, '3');
INSERT INTO proforma_invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '2018-09-27', 'P003', '2018-09-27', NULL, NULL, 0, 'Balaji', NULL, NULL, NULL, NULL, 'interstate', 'interstate', '', '', NULL, '2018-09-27', '8520', NULL, '4823', NULL, 'Paper Based Laminated 7MM', '', '1.05', '15', '18.59', NULL, '3840.59', NULL, NULL, '3840.59', NULL, NULL, '1', NULL, NULL, '3');
INSERT INTO proforma_invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '2018-09-27', 'P003', '2018-09-27', NULL, NULL, 0, 'Balaji', NULL, NULL, NULL, NULL, 'interstate', 'interstate', '', '', NULL, '2018-09-27', '8520', NULL, 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '', '105', '20', '2478.00', NULL, '3840.59', NULL, NULL, '3840.59', NULL, NULL, '1', NULL, NULL, '3');


#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS proinvoice_party_statement;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO proinvoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2018-09-17', 'P001', 2, 'Balaji', '', '', '', 'Aluminium Body 109.3 x 148', '', '', '', NULL, NULL, '', '', '1', '2018-09-17', '2018-09-17', '18585.00', '-', '-', '', '', '-', '-', NULL, '18585', '-', '-', '-', '-', '18585.00', '-', '18585.00', NULL, NULL, 'P001-2018', 'P001170918', '1');
INSERT INTO proinvoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '-', '-', NULL, '2018-09-17', 'P002', 1, 'Arul', '', '', '', 'Monitor', '', '', '', NULL, NULL, '', '', '1', '2018-09-17', '2018-09-17', '70400.00', '-', '-', '', '', '-', '-', NULL, '222284', '-', '-', '-', '-', '70400.00', '-', '70400.00', NULL, NULL, 'P002-2018', 'P002170918', '2');
INSERT INTO proinvoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '-', '-', NULL, '2018-09-27', 'P003', 2, 'Balaji', '', '', '', 'test||Paper Based Laminated 7MM||Aluminium Body 109.3 x 148', '||||', '', '', NULL, NULL, '', '', '1', '2018-09-27', '2018-09-27', '3840.59', '-', '-', '', '', '-', '-', NULL, '55703.48', '-', '-', '-', '-', '3840.59', '-', '3840.59', NULL, NULL, NULL, NULL, '3');


#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS purchase_collection;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO purchase_collection (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2018-09-25', '0000-00-00', NULL, NULL, '2018-09-25', NULL, 'R3', 'kumar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, '12890', NULL, NULL, NULL, NULL, NULL);
INSERT INTO purchase_collection (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2018-10-04', '0000-00-00', NULL, NULL, '2018-10-04', NULL, 'R4', 'mn industry', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Bank STATE BANK OF INDIA', NULL, NULL, NULL, '200000', NULL, NULL, NULL, NULL, NULL);
INSERT INTO purchase_collection (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (3, '2018-10-18', '0000-00-00', NULL, NULL, '2018-10-18', NULL, 'R6', 'mn industry', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cheque INDIAN OVERSEAS 1111', NULL, NULL, NULL, '5000', NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS purchase_details;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2018-09-25', '2018-09-25', '2018-09-25', 'P001', 5, 'kumar', 'cbe, cbe north, cbe, tn', '002', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '105', '100', '10500.00', '0', 'percent_wise', '0.00', '10500.00', '9', '945.00', '9', '945.00', '18', '1890.00', '12390.00', '12890.00', '', '0', '0.00', '0', '0.00', '0', '0.00', '0.00', '500', '0', '0.00', '0', '0.00', '0', '0.00', '500.00', '0', '0', '1', '12890.00', 'P001250918', 'P001-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2018-10-04', '2018-10-04', '2018-10-04', 'P002', 7, 'mn industry', 'zone street  68, paries corner , chennai, tamin nadu', '2', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '99752', 'Iinstalation m couch', 'set', '45000', '5', '225000.00', '0', 'percent_wise', '0.00', '225000.00', '9', '20250.00', '9', '20250.00', '18', '40500.00', '265500.00', '265500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '265500.00', 'P002041018', 'P002-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (3, '2018-10-24', '2018-10-24', '2018-10-24', 'P003', 7, 'mn industry', 'zone street  68, paries corner , chennai, tamin nadu', '11', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '105', '2', '210.00', '0', 'percent_wise', '0.00', '210.00', '9', '18.90', '9', '18.90', '18', '37.80', '247.80', '247.80', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '247.80', 'P003241018', 'P003-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (4, '2018-10-27', '2018-10-27', '2018-10-27', 'P004', 5, 'kumar', 'cbe, cbe north, cbe, tn', '12', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '4823', 'Paper Based Laminated 7MM', 'Nos', '1.05', '10', '10.50', '0', 'percent_wise', '0.00', '10.50', '9', '0.94', '9', '0.94', '18', '1.89', '12.39', '12.39', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '12.39', 'P004271018', 'P004-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (5, '2018-11-01', '2018-11-01', '2018-11-01', 'P005', 5, 'kumar', 'cbe, cbe north, cbe, tn', '101', 'interstate', 'interstate', '', '', 'igst', '3003||3003||3003||3003||3003||3003', 'SAFOOF BODY MASS  1 KGS||SAFOOF BODY MASS 3 KGS||SAFOOF BODY MASS 5KGS||SAFOOF TURBO MASS 1KGS||SAFOOF TURBO MASS 3 KGS||SAFOOF MAGA PRO 3 KGS', 'kgs||kgs||kgs||kgs||kgs||kgs', '699||2116||2850||849||2223||4421', '60||96||28||12||24||12', '16850.89||81617.14||32062.50||4093.39||21436.07||21315.54', '55||55||55||55||55||55', 'percent_wise', '||||||||||', '18873.00||91411.20||35910.00||4584.60||24008.40||23873.40', '6||6||6||6||6||6', '1011.05||4897.03||1923.75||245.60||1286.16||1278.93', '6||6||6||6||6||6', '1011.05||4897.03||1923.75||245.60||1286.16||1278.93', '12||12||12||12||12||12', '2022.11||9794.06||3847.50||491.21||2572.33||2557.86', '18873.00||91411.20||35910.00||4584.60||24008.40||23873.40', '198660.60', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1||1||1', '198660.60', 'P005011118', 'P005-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (6, '2018-11-02', '2018-11-02', '2018-11-01', 'P006', 5, 'kumar', 'cbe, cbe north, cbe, tn', '5001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '102', 'eraser', 'Nos', '10', '10', '84.75', '0', 'percent_wise', '100', '100.00', '9', '7.63', '9', '7.63', '18', '15.25', '100.00', '100.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '100.00', 'P006021118', 'P006-2018', 1, 1);


#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS purchase_reports;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2018-09-25', 'P001', '2018-09-25', NULL, 5, 'kumar', 'cbe, cbe north, cbe, tn', '002', '2018-09-25', NULL, NULL, 'PJEB050', 'Aluminium Body 109.3 x 148', '1', '100', '1', '12890.00', NULL, NULL, NULL, NULL, NULL, '12890.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2018', 'P001250918');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '2', '2018-10-04', 'P002', '2018-10-04', NULL, 7, 'mn industry', 'zone street  68, paries corner , chennai, tamin nadu', '2', '2018-10-04', NULL, NULL, '99752', 'Iinstalation m couch', '4', '5', '2', '265500.00', NULL, NULL, NULL, NULL, NULL, '265500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P002-2018', 'P002041018');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '3', '2018-10-24', 'P003', '2018-10-24', NULL, 7, 'mn industry', 'zone street  68, paries corner , chennai, tamin nadu', '11', '2018-10-24', NULL, NULL, 'PJEB050', 'Aluminium Body 109.3 x 148', '1', '2', '2', '247.80', NULL, NULL, NULL, NULL, NULL, '247.80', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P003-2018', 'P003241018');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '4', '2018-10-27', 'P004', '2018-10-27', NULL, 5, 'kumar', 'cbe, cbe north, cbe, tn', '12', '2018-10-27', NULL, NULL, '4823', 'Paper Based Laminated 7MM', '1', '10', '1', '12.39', NULL, NULL, NULL, NULL, NULL, '12.39', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P004-2018', 'P004271018');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (11, '5', '2018-11-01', 'P005', '2018-11-01', NULL, 0, 'kumar', 'cbe, cbe north, cbe, tn', '101', '2018-11-01', NULL, NULL, '3003', 'SAFOOF BODY MASS  1 KGS', '6', '60', '1', '198660.60', NULL, NULL, NULL, NULL, NULL, '198660.60', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (12, '5', '2018-11-01', 'P005', '2018-11-01', NULL, 0, 'kumar', 'cbe, cbe north, cbe, tn', '101', '2018-11-01', NULL, NULL, '3003', 'SAFOOF BODY MASS 3 KGS', '9', '96', '8', '198660.60', NULL, NULL, NULL, NULL, NULL, '198660.60', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (13, '5', '2018-11-01', 'P005', '2018-11-01', NULL, 0, 'kumar', 'cbe, cbe north, cbe, tn', '101', '2018-11-01', NULL, NULL, '3003', 'SAFOOF BODY MASS 5KGS', '9', '28', '8', '198660.60', NULL, NULL, NULL, NULL, NULL, '198660.60', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (14, '5', '2018-11-01', 'P005', '2018-11-01', NULL, 0, 'kumar', 'cbe, cbe north, cbe, tn', '101', '2018-11-01', NULL, NULL, '3003', 'SAFOOF TURBO MASS 1KGS', '|', '12', '7', '198660.60', NULL, NULL, NULL, NULL, NULL, '198660.60', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (15, '5', '2018-11-01', 'P005', '2018-11-01', NULL, 0, 'kumar', 'cbe, cbe north, cbe, tn', '101', '2018-11-01', NULL, NULL, '3003', 'SAFOOF TURBO MASS 3 KGS', '|', '24', '3', '198660.60', NULL, NULL, NULL, NULL, NULL, '198660.60', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (16, '5', '2018-11-01', 'P005', '2018-11-01', NULL, 0, 'kumar', 'cbe, cbe north, cbe, tn', '101', '2018-11-01', NULL, NULL, '3003', 'SAFOOF MAGA PRO 3 KGS', '2', '12', '.', '198660.60', NULL, NULL, NULL, NULL, NULL, '198660.60', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (17, '6', '2018-11-02', 'P006', '2018-11-02', NULL, 5, 'kumar', 'cbe, cbe north, cbe, tn', '5001', '2018-11-01', NULL, NULL, '102', 'eraser', '1', '10', '1', '100.00', NULL, NULL, NULL, NULL, NULL, '100.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P006-2018', 'P006021118');


#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS purchaseorder_details;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (9, '2018-07-13', '2018-07-13', '2018-07-13', 'Direct PO', 'P006', '565', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73090090', '1130010023 spacer', 'NOS', '78', '5', NULL, '0', '390.00', '0', 'percent_wise', '0.00', '390.00', '9', '35.10', '9', '35.10', '0', '0', '460.20', '460.20', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '460.20', 'P006130718', 'P006-2018', 1, 0);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (10, '2018-07-17', '2018-07-17', '2018-07-17', 'Direct PO', 'P007', '4165', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '29911||0', 'KGV 5131 Shaft||12 ADJUST WRINCH', 'NOS||NOS', '2500||340', '10||030', NULL, '0||0', '25000.00||10200.00', '0||0', 'percent_wise', '0.00||0.00', '25000.00||10200.00', '9||9', '2250.00||918.00', '9||9', '2250.00||918.00', '0||0', '0||0', '29500.00||12036.00', '41536.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '41536.00', 'P007170718', 'P007-2018', 1, 0);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (11, '2018-07-17', '2018-07-17', '2018-07-17', 'Direct PO', 'P008', '5659832', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '0||84099990', '8 INCH STONE CORBERANDUM||FB.00.SA004_DECK HINGE _502943', 'NOS||NOS', '580||53', '10||10', NULL, '0||0', '5800.00||530.00', '10||10', 'percent_wise', '580.00||53.00', '5220.00||477.00', '9||9', '469.80||42.93', '9||9', '469.80||42.93', '0||0', '0||0', '6159.60||562.86', '6722.46', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '6722.46', 'P008170718', 'P008-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (12, '2018-07-26', '2018-07-26', '2018-07-26', 'Direct PO', 'P009', '1452', NULL, 13, 'procos  mechatronics pvt ltd', 'no.5/153/7,poolakkadu thottam, arasur,, coimbatrore, tamilnadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73181110', '1130500081 spacer', 'NOS', '40', '100', NULL, '0', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '360.00', '9', '360.00', '0', '0', '4720.00', '4720.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '4720.00', 'P009260718', 'P009-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (14, '2018-07-26', '2018-07-26', '2018-07-26', 'Direct PO', 'P010', '56122325', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '4418', 'PA-01-105-018 NYLON BLOCK', 'NOS', '145', '20', '20', '0', '2900.00', '0', 'percent_wise', '0.00', '2900.00', '9', '261.00', '9', '261.00', '0', '0', '3422.00', '3422.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '3422.00', 'P010260718', 'P010-2018', 1, 0);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (15, '2018-08-24', '2018-08-24', '2018-08-24', 'Direct PO', 'P011', '1452', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '29911', 'KGV 5131 Shaft', 'NOS', '2500', '10', '10', '0', '25000.00', '0', 'percent_wise', '0.00', '25000.00', '9', '2250.00', '9', '2250.00', '0', '0', '29500.00', '29500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '29500.00', 'P011240818', 'P011-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (16, '2018-08-24', '2018-08-24', '2018-08-24', 'Direct PO', 'P011', '1452', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '29911', 'KGV 5131 Shaft', 'NOS', '2500', '10', '10', '0', '25000.00', '0', 'percent_wise', '0.00', '25000.00', '9', '2250.00', '9', '2250.00', '0', '0', '29500.00', '29500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '29500.00', 'P011240818', 'P011-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (17, '2018-08-24', '2018-08-24', '2018-08-24', 'Direct PO', 'P011', '1452', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '29911', 'KGV 5131 Shaft', 'NOS', '2500', '10', '10', '0', '25000.00', '0', 'percent_wise', '0.00', '25000.00', '9', '2250.00', '9', '2250.00', '0', '0', '29500.00', '29500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '29500.00', 'P011240818', 'P011-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (18, '2018-09-06', '2018-09-06', '2018-09-06', 'Direct PO', 'P012', '14633', NULL, 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '105', '120', '120', '0', '12600.00', '0', 'percent_wise', '0.00', '12600.00', '9', '1134.00', '9', '1134.00', '0', '0', '14868.00', '14868.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '14868.00', 'P012060918', 'P012-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (19, '2018-09-15', '2018-09-15', '2018-09-15', 'Direct PO', 'P013', '5642', NULL, 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '105', '10', '10', '0', '1050.00', '0', 'percent_wise', '0.00', '1050.00', '9', '94.50', '9', '94.50', '0', '0', '1239.00', '1239.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1239.00', 'P013150918', 'P013-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (20, '2018-09-15', '2018-09-15', '2018-09-15', 'Direct PO', 'P013', '5642', NULL, 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '105', '10', '10', '0', '1050.00', '0', 'percent_wise', '0.00', '1050.00', '9', '94.50', '9', '94.50', '0', '0', '1239.00', '1239.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1239.00', 'P013150918', 'P013-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (21, '2018-09-20', '2018-09-20', '2018-09-20', 'Direct PO', 'P014', '12', NULL, 3, 'karthik', 'xfdf, 23,ht, chennai, tn', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '84795000', 'defr', 'Nos', '23545', '2', '2', '0', '47090.00', '0', 'percent_wise', '0.00', '47090.00', '9', '4238.10', '9', '4238.10', '0', '0', '55566.20', '55566.20', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '55566.20', 'P014200918', 'P014-2018', 1, 1);


#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS purchaseorder_reports;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (10, '4', '2018-04-21', '', 'P001', '10317183042534', NULL, '2018-04-20', NULL, 0, 'CRAFTSMAN AUTOMATION PRIVATE LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', NULL, '2018-03-28', NULL, NULL, '73090090', '1130010020 SPACER', 'NOS', '1', '50', NULL, '', '9853.00', '16933.00', NULL, NULL, NULL, NULL, NULL, '16933.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2018', 'P001210418');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (11, '4', '2018-04-21', '', 'P001', '10317183042534', NULL, '2018-04-20', NULL, 0, 'CRAFTSMAN AUTOMATION PRIVATE LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', NULL, '2018-03-28', NULL, NULL, '73090090', '1130010021 SPACER', 'NOS', '6', '50', NULL, '', '3540.00', '16933.00', NULL, NULL, NULL, NULL, NULL, '16933.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2018', 'P001210418');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (12, '4', '2018-04-21', '', 'P001', '10317183042534', NULL, '2018-04-20', NULL, 0, 'CRAFTSMAN AUTOMATION PRIVATE LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', NULL, '2018-03-28', NULL, NULL, '73090090', '1130010022 SPACER', 'NOS', '7', '50', NULL, '', '3540.00', '16933.00', NULL, NULL, NULL, NULL, NULL, '16933.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2018', 'P001210418');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (13, '5', '2018-07-11', 'Direct PO', 'P002', '152595', NULL, '2018-07-11', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-11', NULL, NULL, '29911', 'KGV 5131 Shaft', 'NOS', '2', '10', NULL, '0', '29500.00', '35990.00', NULL, NULL, NULL, NULL, NULL, '35990.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P002-2018', 'P002110718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (14, '5', '2018-07-11', 'Direct PO', 'P002', '152595', NULL, '2018-07-11', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-11', NULL, NULL, '0', 'ISO 30 MICRO BORING HEAD', 'NOS', '5', '1', NULL, '0', '6490.00', '35990.00', NULL, NULL, NULL, NULL, NULL, '35990.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P002-2018', 'P002110718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (16, '7', '2018-07-12', 'Direct PO', 'P004', '155', NULL, '2018-07-12', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-12', NULL, NULL, '29911', 'KGV 5131 Shaft', 'NOS', '2', '10', NULL, '0', '29500.00', '29500.00', NULL, NULL, NULL, NULL, NULL, '29500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P004-2018', 'P004120718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (17, '8', '2018-07-13', 'Direct PO', 'P005', '4552', NULL, '2018-07-13', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-13', NULL, NULL, '0', '8 INCH STONE CORBERANDUM', 'NOS', '5', '10', NULL, '0', '6844.00', '6844.00', NULL, NULL, NULL, NULL, NULL, '6844.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P005-2018', 'P005130718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (18, '9', '2018-07-13', 'Direct PO', 'P006', '565', NULL, '2018-07-13', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-13', NULL, NULL, '73090090', '1130010023 spacer', 'NOS', '7', '5', NULL, '0', '460.20', '460.20', NULL, NULL, NULL, NULL, NULL, '460.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P006-2018', 'P006130718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (19, '10', '2018-07-17', 'Direct PO', 'P007', '4165', NULL, '2018-07-17', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', '2018-07-17', NULL, NULL, '29911', 'KGV 5131 Shaft', 'NOS', '2', '10', NULL, '0', '29500.00', '41536.00', NULL, NULL, NULL, NULL, NULL, '41536.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P007-2018', 'P007170718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (20, '10', '2018-07-17', 'Direct PO', 'P007', '4165', NULL, '2018-07-17', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', '2018-07-17', NULL, NULL, '0', '12 ADJUST WRINCH', 'NOS', '5', '030', NULL, '0', '12036.00', '41536.00', NULL, NULL, NULL, NULL, NULL, '41536.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P007-2018', 'P007170718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (21, '11', '2018-07-17', 'Direct PO', 'P008', '5659832', NULL, '2018-07-17', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-17', NULL, NULL, '0', '8 INCH STONE CORBERANDUM', 'NOS', '5', '10', NULL, '0', '6159.60', '6722.46', NULL, NULL, NULL, NULL, NULL, '6722.46', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P008-2018', 'P008170718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (22, '11', '2018-07-17', 'Direct PO', 'P008', '5659832', NULL, '2018-07-17', NULL, 7, 'VISHAL PRECISION PRODUCTS PVT LTD', '113-A, KAVERY NAGAR, VILANKURICHI ROAD, PEELAMEDU, COIMBATORE , TAMILNADU', '0', '2018-07-17', NULL, NULL, '84099990', 'FB.00.SA004_DECK HINGE _502943', 'NOS', '8', '10', NULL, '0', '562.86', '6722.46', NULL, NULL, NULL, NULL, NULL, '6722.46', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P008-2018', 'P008170718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (23, '12', '2018-07-26', 'Direct PO', 'P009', '1452', NULL, '2018-07-26', NULL, 13, 'procos  mechatronics pvt ltd', 'no.5/153/7,poolakkadu thottam, arasur,, coimbatrore, tamilnadu', '0', '2018-07-26', NULL, NULL, '73181110', '1130500081 spacer', 'NOS', '4', '100', NULL, '0', '4720.00', '4720.00', NULL, NULL, NULL, NULL, NULL, '4720.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P009-2018', 'P009260718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (24, '14', '2018-07-26', 'Direct PO', 'P010', '56122325', NULL, '2018-07-26', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', '2018-07-26', NULL, NULL, '4418', 'PA-01-105-018 NYLON BLOCK', 'NOS', '1', '20', '5', '0', '3422.00', '3422.00', NULL, NULL, NULL, NULL, NULL, '3422.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P010-2018', 'P010260718');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (25, '17', '2018-08-24', 'Direct PO', 'P011', '1452', NULL, '2018-08-24', NULL, 4, 'CRAFTSMAN AUTOMATION LIMITED UNIT 111', '123/4,SANGOTHIPALAYAM ROAD, ARASUR POST, COIMBATORE , TAMILNADU', '0', '2018-08-24', NULL, NULL, '29911', 'KGV 5131 Shaft', 'NOS', '2', '10', '10', '0', '29500.00', '29500.00', NULL, NULL, NULL, NULL, NULL, '29500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P011-2018', 'P011240818');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (26, '18', '2018-09-06', 'Direct PO', 'P012', '14633', NULL, '2018-09-06', NULL, 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '0', '2018-09-06', NULL, NULL, 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '1', '120', '120', '0', '14868.00', '14868.00', NULL, NULL, NULL, NULL, NULL, '14868.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P012-2018', 'P012060918');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (27, '20', '2018-09-15', 'Direct PO', 'P013', '5642', NULL, '2018-09-15', NULL, 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', '0', '2018-09-15', NULL, NULL, 'PJEB050', 'Aluminium Body 109.3 x 148', 'Nos', '1', '10', '10', '0', '1239.00', '1239.00', NULL, NULL, NULL, NULL, NULL, '1239.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P013-2018', 'P013150918');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (28, '21', '2018-09-20', 'Direct PO', 'P014', '12', NULL, '2018-09-20', NULL, 3, 'karthik', 'xfdf, 23,ht, chennai, tn', '0', '2018-09-20', NULL, NULL, '84795000', 'defr', 'Nos', '2', '2', '2', '0', '55566.20', '55566.20', NULL, NULL, NULL, NULL, NULL, '55566.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P014-2018', 'P014200918');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (29, '6', '2018-09-24', '', 'P003', '4555', NULL, '2018-07-12', NULL, 13, 'procos  mechatronics pvt ltd', 'no.5/153/7,poolakkadu thottam, arasur,, coimbatrore, tamilnadu', NULL, '2018-07-12', NULL, NULL, '29911', 'KGV 5131 Shaft', 'NOS', '2', '10', NULL, '', '29500.00', '29500.00', NULL, NULL, NULL, NULL, NULL, '29500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P003-2018', 'P003240918');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (31, '22', '2018-10-22', '', 'P015', '102', NULL, '2018-09-28', NULL, 3, 'karthik', 'xfdf, 23,ht, chennai, tn', NULL, '2018-09-28', NULL, NULL, '015', 'Monitor', 'Nos', '3', '10', NULL, '', '35200.00', '35200.00', NULL, NULL, NULL, NULL, NULL, '35200.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P015-2018', 'P015221018');


#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS quotation_details;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO quotation_details (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2018-09-25', '2018-09-25', NULL, NULL, 'Q101', 4, 'ragul', 'peelamedu, cbe, cbe, tamilnadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '4823', 'Paper Based Laminated 7MM', NULL, 'Nos', '1.05', '1000', '1050.00', '0', '0.00', '1050.00', '9', '94.50', '9', '94.50', '18', '', '1239.00', '1239.00', NULL, NULL, '0', NULL, '1239.00', NULL, NULL, 1, 1);
INSERT INTO quotation_details (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2018-09-25', '2018-09-25', NULL, NULL, 'Q101', 4, 'ragul', 'peelamedu, cbe, cbe, tamilnadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '4823', 'Paper Based Laminated 7MM', NULL, 'Nos', '1.05', '1000', '1050.00', '0', '0.00', '1050.00', '9', '94.50', '9', '94.50', '18', '', '1239.00', '1239.00', NULL, NULL, '0', NULL, '1239.00', NULL, NULL, 1, 1);
INSERT INTO quotation_details (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (3, '2018-10-09', '2018-10-09', NULL, NULL, 'Q102', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, 'PJEB050', 'Aluminium Body 109.3 x 148', NULL, 'Nos', '105', '5', '525.00', '0', '0.00', '525.00', '9', '47.25', '9', '47.25', '18', '', '619.50', '619.50', NULL, NULL, '0', NULL, '619.50', NULL, NULL, 1, 1);
INSERT INTO quotation_details (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (4, '2018-10-09', '2018-10-09', NULL, NULL, 'Q103', 1, 'Arul', '10th street, west main road, near by indian bank., coimbatore, Tamil nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, 'PJEB050', 'Aluminium Body 109.3 x 148', NULL, 'Nos', '34800', '120', '4176000.00', '0', '0.00', '4176000.00', '9', '375840.00', '9', '375840.00', '18', '', '4927680.00', '4927680.00', NULL, NULL, '0', NULL, '4927680.00', NULL, NULL, 1, 1);
INSERT INTO quotation_details (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (5, '2018-10-24', '2018-10-24', NULL, NULL, 'Q104', 0, 'SARAVANAN', '3RD STREET', NULL, NULL, 'intrastate', NULL, NULL, NULL, 'PJEB050', 'Aluminium Body 109.3 x 148', NULL, 'Nos', '105', '10', '1050.00', '0', '0.00', '1050.00', '9', '94.50', '9', '94.50', '18', '', '1239.00', '1239.00', NULL, NULL, '0', NULL, '1239.00', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS sales_return;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS stock;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (1, '2018-10-29', 'PJEB050', NULL, '9', '9', '18', 'Aluminium Body 109.3 x 148', '2', '105', '2', '', '1', '-200', NULL, NULL, '', '2018-10-24', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (2, '2018-11-02', '4823', NULL, '9', '9', '18', 'Paper Based Laminated 7MM', '10', '1.05', '10', '', '1', '1446', NULL, NULL, '', '2018-10-27', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (3, '2018-09-06', '1225222', NULL, '9', '9', '18', 'rod', '250', '4.562', '250', '', '1', '250', NULL, NULL, '', '2018-09-06', 'exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (4, '2018-09-21', '4412', NULL, '9', '9', '18', '18MM PLYWOOD 8x4 dc', '120', '3.600', '120', '', '1', '105', NULL, NULL, '', '2018-09-06', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (5, '2018-09-20', '84795000', NULL, '9', '9', '18', 'defr', '3', '23545', '3', '', '1', '3', NULL, NULL, '', '2018-09-20', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (6, '2018-09-27', 'Lenova', NULL, '9', '9', '18', '19073667082', '5', '9999', '5', '', '1', '4', NULL, NULL, '', '2018-09-26', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (7, '2018-10-29', '99752', NULL, '9', '9', '18', 'Iinstalation m couch', '5', '50000', '5', '', '1', '-66', NULL, NULL, '', '2018-10-04', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (8, '2018-10-29', '998898', NULL, '14', '14', '28', 'bush u', '10', '300', '10', '', '1', '0', NULL, NULL, '', '2018-10-25', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (9, '2018-11-02', '12345', NULL, '9', '9', '18', 'tissue paper', '100', '1000', '100', '', '1', '38', NULL, NULL, '', '2018-10-29', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (10, '2018-10-30', '5211', NULL, '6', '6', '12', 'FILTERBAG', '100', '1000', '100', '', '1', '90', NULL, NULL, '', '2018-10-30', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (11, '2018-11-01', '3003', NULL, '6', '6', '12', 'SAFOOF BODY MASS  1 KGS', '60', '699', '60', '', '', '60', NULL, NULL, '', '2018-11-01', 'Inclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (12, '2018-11-01', '3003', NULL, '6', '6', '12', 'SAFOOF BODY MASS 3 KGS', '96', '2116', '96', '', '', '96', NULL, NULL, '', '2018-11-01', 'Inclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (13, '2018-11-01', '3003', NULL, '6', '6', '12', 'SAFOOF BODY MASS 5KGS', '28', '2850', '28', '', '', '28', NULL, NULL, '', '2018-11-01', 'Inclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (14, '2018-11-01', '3003', NULL, '6', '6', '12', 'SAFOOF TURBO MASS 1KGS', '12', '849', '12', '', '', '12', NULL, NULL, '', '2018-11-01', 'Inclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (15, '2018-11-01', '3003', NULL, '6', '6', '12', 'SAFOOF TURBO MASS 3 KGS', '24', '2223', '24', '', '', '24', NULL, NULL, '', '2018-11-01', 'Inclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (16, '2018-11-01', '3003', NULL, '6', '6', '12', 'SAFOOF MAGA PRO 3 KGS', '12', '4421', '12', '', '', '12', NULL, NULL, '', '2018-11-01', 'Inclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (17, '2018-11-02', '102', NULL, '9', '9', '18', 'eraser', '10', '10', '10', '', '', '8', NULL, NULL, '', '2018-11-02', 'Inclusive');


#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS stock_reports;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (1, '2018-09-06', 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', '1', '150', 'FromAddStock', '2018-09-06', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (2, '2018-09-06', '4823', NULL, 'Paper Based Laminated 7MM', '1', '1500', 'FromAddStock', '2018-09-06', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (3, '2018-09-06', '1225222', NULL, 'rod', '1', '250', 'FromAddStock', '2018-09-06', NULL, NULL, 'exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (4, '2018-09-06', '4412', NULL, '18MM PLYWOOD 8x4 dc', '1', '120', 'FromAddStock', '2018-09-06', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (5, '2018-09-20', '84795000', NULL, 'defr', '1', '3', 'FromAddStock', '2018-09-20', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (6, '2018-09-25', 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', NULL, '100', '', NULL, '1', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (7, '2018-09-26', 'Lenova', NULL, '19073667082', '1', '5', 'FromAddStock', '2018-09-26', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (8, '2018-10-04', '99752', NULL, 'Iinstalation m couch', '1', '100', 'FromAddStock', '2018-10-04', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (9, '2018-10-04', '99752', NULL, 'Iinstalation m couch', NULL, '5', '', NULL, '2', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (10, '2018-10-24', 'PJEB050', NULL, 'Aluminium Body 109.3 x 148', NULL, '2', '', NULL, '3', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (11, '2018-10-25', '998898', NULL, 'bush u', '1', '10', 'FromAddStock', '2018-10-25', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (12, '2018-10-27', '4823', NULL, 'Paper Based Laminated 7MM', NULL, '10', '', NULL, '4', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (13, '2018-10-29', '12345', NULL, 'tissue paper', '1', '100', 'FromAddStock', '2018-10-29', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (14, '2018-10-30', '5211', NULL, 'FILTERBAG', '1', '100', 'FromAddStock', '2018-10-30', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (21, '2018-11-01', '3003', NULL, 'SAFOOF BODY MASS  1 KGS', NULL, '60', '', '2018-11-01', '5', NULL, 'Inclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (22, '2018-11-01', '3003', NULL, 'SAFOOF BODY MASS 3 KGS', NULL, '96', '', '2018-11-01', '5', NULL, 'Inclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (23, '2018-11-01', '3003', NULL, 'SAFOOF BODY MASS 5KGS', NULL, '28', '', '2018-11-01', '5', NULL, 'Inclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (24, '2018-11-01', '3003', NULL, 'SAFOOF TURBO MASS 1KGS', NULL, '12', '', '2018-11-01', '5', NULL, 'Inclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (25, '2018-11-01', '3003', NULL, 'SAFOOF TURBO MASS 3 KGS', NULL, '24', '', '2018-11-01', '5', NULL, 'Inclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (26, '2018-11-01', '3003', NULL, 'SAFOOF MAGA PRO 3 KGS', NULL, '12', '', '2018-11-01', '5', NULL, 'Inclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (27, '2018-11-02', '102', NULL, 'eraser', NULL, '10', '', '2018-11-02', '6', NULL, 'Inclusive');


#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS tbl_person;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS uom;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (1, '2018-08-23', 'Nos', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (2, '2018-08-23', 'set', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (3, '2018-08-23', 'kgs', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (4, '2018-09-23', '123', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (5, '2018-10-04', 'no', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (6, '2018-10-27', 'ltr', 1);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS user_menu;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS vat_details;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (1, '2018-08-23', 'gst', '5', 'gst @ 5 %', '2.5', '2.5', '5', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (3, '2018-08-23', 'gst', '18', 'gst @ 18 %', '9', '9', '18', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (4, '2018-08-23', 'gst', '28', 'gst @ 28 %', '14', '14', '28', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (5, '2018-10-04', 'gst', '24', 'gst @ 24 %', '12', '12', '24', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (11, '2018-11-02', 'gst', '32', 'gst @ 32 %', '16', '16', '32', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS vendor_details;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS voucher;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (2, '2018-09-20', 'R', 1, 'Arul', '2018-09-20', 'payment', 'services', 'Cash', '0', '', '', '0', '', '20000', 'Cash', NULL, NULL, '20000', '20000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (3, '2018-09-24', 'R1', 1, 'Arul', '2018-09-24', 'payment', 'service', 'Cash', '0', '', '', '0', '', '1000', 'Cash', NULL, NULL, '1000', '1000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (4, '2018-09-25', 'R2', 4, 'ragul', '2018-09-25', 'payment', '', 'Cash', '0', '', '', '0', '', '205821.06', 'Cash', NULL, NULL, '205821.06', '205821.06', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (5, '2018-09-25', 'R3', 5, 'kumar', '2018-09-25', 'receipt', '', 'Cash', '0', '', '', '0', '', '12890', 'Cash', NULL, NULL, '12890', '12890', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (6, '2018-10-04', 'R4', 7, 'mn industry', '2018-10-04', 'receipt', 'mn purchise', 'Bank', '0', '', '', 'STATE BANK OF INDIA', '200000', '', 'Bank STATE BANK OF INDIA', '2', NULL, '200000', '200000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (7, '2018-10-04', 'R5', 6, 's corts', '2018-10-04', 'payment', 'mn sales', 'Bank', '0', '', '', 'ICICI BANK', '400000', '', 'Bank ICICI BANK', '3', NULL, '400000', '400000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (8, '2018-10-18', 'R6', 7, 'mn industry', '2018-10-18', 'receipt', '', 'Cheque', 'INDIAN OVERSEAS', '1111', '5000', '0', '', '', 'Cheque INDIAN OVERSEAS 1111', NULL, '01-11-2018', '5000', '5000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (9, '2018-10-29', 'R7', 1, 'Arul', '2018-10-29', 'payment', 'bank loan', 'Bank', 'UNION BANK OF INDIA', '', '', 'KARUR VYSYA BANK', '50000', '', 'Bank KARUR VYSYA BANK', '0', NULL, '50000', '50000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (10, '2018-10-29', 'R8', 2, 'Balaji', '2018-10-29', 'payment', '', 'Cash', '0', '', '', '0', '', '20000', 'Cash', NULL, NULL, '20000', '20000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (11, '2018-10-29', 'R9', 2, 'Balaji', '2018-10-29', 'payment', '', 'Cheque', 'ING VYSYA', '121212', '20000', '0', '', '', 'Cheque ING VYSYA 121212', NULL, '24-10-2018', '20000', '20000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (12, '2018-10-29', 'R10', 8, 'SRINIVASAREDDY R', '2018-10-29', 'payment', '', 'Cash', '0', '', '', '0', '', '50000', 'Cash', NULL, NULL, '50000', '50000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (13, '2018-10-29', 'R11', 8, 'SRINIVASAREDDY R', '2018-10-29', 'payment', '', 'Cash', '0', '', '', '0', '', '145000', 'Cash', NULL, NULL, '145000', '145000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (14, '2018-11-02', 'R12', 1, 'Arul', '2018-11-02', 'payment', 'services', 'Cash', '0', '', '', '0', '', '1000', 'Cash', NULL, NULL, '1000', '1000', '1', 0);


