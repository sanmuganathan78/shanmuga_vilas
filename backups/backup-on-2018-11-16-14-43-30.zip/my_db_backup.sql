#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS additem;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (1, '2018-11-16', '1', '201', 'Steel', '150', '1', '12', '12', '24', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (2, '2018-11-16', '2', '202', 'Paper bundle', '200', '2', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (3, '2018-11-16', '2', '203', 'Tissues paper', '150', '1', '12', '12', '24', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (4, '2018-11-16', '1', '204', 'ink bottle', '0', '3', '16', '16', '32', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (5, '2018-11-16', '2', '205', 'Ribbon paper', '100', '4', '2.5', '2.5', '5', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (6, '2018-11-16', '3', '206', 'Colour paper', '100', '4', '2.5', '2.5', '5', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (7, '2018-11-16', '1', '207', 'Reynolds pen', '100', '2', '9', '9', '18', '1', 'Exclusive', '');


#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS backup_details;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS bed_details;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS card;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO card (`id`, `name`, `date`, `status`) VALUES (1, 'Credit Card', '0000-00-00', 1);
INSERT INTO card (`id`, `name`, `date`, `status`) VALUES (2, 'Debit Card', '0000-00-00', 1);


#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS cash_bill;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS cashbill_details;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS cashbill_reports;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS category;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS collection_details;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS company_logo;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO company_logo (`id`, `date`, `image`, `status`) VALUES (1, '2017-12-27', 'images.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS customer_details;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (1, '2018-11-16', 'Intra customer', 'Arul Murgan', '95002368541', '', '15th Gopala Puram', 'West , Raithina puram', 'vincent', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, NULL, '0', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '44', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (2, '2018-11-16', 'Intra customer', 'chandrasekar', '8500123698', '', '12th, lakshmi puram Street,', 'West main road', 'priya', 'Tamil nadu', 'coimbatore.', '', '', NULL, '0.00', NULL, NULL, '0', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '55', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (3, '2018-11-16', 'Intra supplier', 'Harish kumar', '72136954132', '', 'kumaren nagar', 'Namakkal road,', 'kumar', 'Tamil Nadu', 'Erode', '', '', NULL, '0.00', NULL, NULL, '0', NULL, '', NULL, '641502', NULL, NULL, NULL, NULL, NULL, '1', '', '', '55', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (4, '2018-11-16', 'Intra supplier', 'uma gowri', '', '', 'mariamman  temple', 'Near by city union bank', 'kumareesh', 'TamilNadu', 'Salem', '', '', NULL, '0.00', NULL, NULL, '0', NULL, '', NULL, '641023', NULL, NULL, NULL, NULL, NULL, '1', '', '', '55', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS customerpo_details;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS dc_delivery;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS dcbill_details;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS headers;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (1, '2018-11-16', 1, 'worker');


#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS invoice_details;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS invoice_party_statement;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS invoice_reports;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS inward_delivery;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS inward_details;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS job_data;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS job_details;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS jobinward_data;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS jobinward_details;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS login_details;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (1, 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'Myoffice!@#$%', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (5, 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', 1, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (6, 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', 0, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (7, 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', 0, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (8, 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', 1, 0, 0);


#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS po_party_statements;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS preference_details;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS preference_settings;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO preference_settings (`id`, `quotation`, `expenses`, `dc`, `voucher`, `debit`, `credit`, `purchase`, `invoicePrefix`, `invoice`, `proforma_invoicePrefix`, `proforma_invoice`, `inward`, `cashbill_invoice`, `purchaseorder`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`) VALUES (1, '', '', '', '', '', '001', '', 'INV', '', 'P', '', '', '', '', 'Myoffice Solutions', '04222570103', '8608701222', '#91, Dr. Jaganathan Nagar, ', 'Civil Aerodrome Post', 'Coimbatore', '641 014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '04222570103', '8608701333', '#91, Dr. Jaganathan Nagar, ', 'Civil Aerodrome Post', 'Coimbatore', '641 014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'percent_wise', 'without_stock', 'with_item');


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS profile;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO profile (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`) VALUES (1, NULL, 'Myoffice BILLING', 'Myoffice BILLING', '9943744177', '0422-2668244', ' #91, Dr, Jaganathan Nagar CMC opp', 'Civil Aerodrome Post', 'Dharmapuri', '641035', 'Tamil Nadu', 'info@idreamdevelopers.com', 'www.idreamdevelopers.org', '12345', '54321', '33AFYPV3340K1ZT', '', '1', 'admin', 'Myoffice!@#$%', 'THE KARUR VYSYA BANK LTD.,', '1748115000002961', 'SARAVANAMPATTI', 'KVBL0001748');


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS proforma_invoice_details;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS proforma_invoice_reports;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS proinvoice_party_statement;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS purchase_collection;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS purchase_details;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS purchase_reports;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS purchaseorder_details;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS purchaseorder_reports;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS quotation_details;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS sales_return;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS stock;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS stock_reports;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS tbl_person;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS uom;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (1, '2018-11-16', 'nos', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (2, '2018-11-16', 'mtr', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (3, '2018-11-16', 'gram', 1);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS user_menu;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS vat_details;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (1, '2018-11-16', 'gst', '24', 'gst @ 24 %', '12', '12', '24', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (2, '2018-11-16', 'gst', '18', 'gst @ 18 %', '9', '9', '18', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (3, '2018-11-16', 'gst', '32', 'gst @ 32 %', '16', '16', '32', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (4, '2018-11-16', 'gst', '5', 'gst @ 5 %', '2.5', '2.5', '5', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS vendor_details;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS voucher;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

