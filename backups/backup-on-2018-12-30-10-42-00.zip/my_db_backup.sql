#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS additem;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (1, '2018-11-16', '1', '201', 'Steel', '150', '1', '12', '12', '24', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (2, '2018-11-16', '2', '202', 'Paper bundle', '200', '2', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (3, '2018-11-16', '2', '203', 'Tissues paper', '150', '1', '12', '12', '24', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (4, '2018-11-16', '1', '204', 'ink bottle', '0', '3', '16', '16', '32', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (5, '2018-11-16', '2', '205', 'Ribbon paper', '100', '4', '2.5', '2.5', '5', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (6, '2018-11-16', '3', '206', 'Colour paper', '100', '4', '2.5', '2.5', '5', '1', 'Inclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (7, '2018-11-16', '1', '207', 'Reynolds pen', '100', '2', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (9, '2018-11-27', '5', '111', 'fanta orange', '1000', '2', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (10, '2018-11-29', '5', '0', 'paint', '100', '2', '9', '9', '18', '1', 'Exclusive', '');
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`) VALUES (11, '2018-12-05', '4', '789', 'bush', '50', '2', '9', '9', '18', '1', 'Exclusive', '');


#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS backup_details;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (1, 'backup-on-2018-11-16-14-43-30.zip', '2018-11-16');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (2, 'backup-on-2018-11-21-10-05-39.zip', '2018-11-21');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (3, 'backup-on-2018-11-22-13-00-13.zip', '2018-11-22');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (4, 'backup-on-2018-11-23-11-40-47.zip', '2018-11-23');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (5, 'backup-on-2018-11-27-10-43-01.zip', '2018-11-27');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (6, 'backup-on-2018-11-28-11-08-38.zip', '2018-11-28');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (7, 'backup-on-2018-11-29-10-49-50.zip', '2018-11-29');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (8, 'backup-on-2018-11-30-10-38-47.zip', '2018-11-30');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (9, 'backup-on-2018-12-01-11-23-24.zip', '2018-12-01');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (10, 'backup-on-2018-12-03-13-12-16.zip', '2018-12-03');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (11, 'backup-on-2018-12-04-10-34-11.zip', '2018-12-04');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (12, 'backup-on-2018-12-05-11-13-20.zip', '2018-12-05');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (13, 'backup-on-2018-12-06-14-09-14.zip', '2018-12-06');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (14, 'backup-on-2018-12-07-07-51-09.zip', '2018-12-07');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (15, 'backup-on-2018-12-08-12-23-00.zip', '2018-12-08');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (16, 'backup-on-2018-12-10-13-22-58.zip', '2018-12-10');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (17, 'backup-on-2018-12-11-13-10-14.zip', '2018-12-11');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (18, 'backup-on-2018-12-13-07-01-36.zip', '2018-12-13');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (19, 'backup-on-2018-12-15-11-21-29.zip', '2018-12-15');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (20, 'backup-on-2018-12-17-12-33-04.zip', '2018-12-17');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (21, 'backup-on-2018-12-18-17-02-33.zip', '2018-12-18');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (22, 'backup-on-2018-12-20-17-21-24.zip', '2018-12-20');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (23, 'backup-on-2018-12-21-10-36-41.zip', '2018-12-21');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (24, 'backup-on-2018-12-22-13-15-38.zip', '2018-12-22');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (25, 'backup-on-2018-12-26-12-52-54.zip', '2018-12-26');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (26, 'backup-on-2018-12-27-11-15-16.zip', '2018-12-27');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (27, 'backup-on-2018-12-28-12-47-52.zip', '2018-12-28');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES (28, 'backup-on-2018-12-29-16-13-44.zip', '2018-12-29');


#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS bed_details;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS card;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO card (`id`, `name`, `date`, `status`) VALUES (1, 'Credit Card', '0000-00-00', 1);
INSERT INTO card (`id`, `name`, `date`, `status`) VALUES (2, 'Debit Card', '0000-00-00', 1);


#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS cash_bill;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS cashbill_details;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO cashbill_details (`id`, `date`, `invoicedate`, `invoiceno`, `customerId`, `customername`, `cust_mobno`, `address`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `systemDate`) VALUES (1, '2018-11-16', '2018-11-16', '', 1, 'kumareesh', '854133693610', '', 'intrastate', 'sgst', 'cgst', '', '202', 'Paper bundle', 'mtr', '200', '0', '0.00', '0', 'percent_wise', '', '0.00', '9', '0.00', '9', '0.00', '0', '0', '0.00', '0.00', '', '0', '', '0', '', '0', '0', '', '', '0', '', '0', '', '0', '0', '', '0', '0', '1', '0.00', NULL, NULL, 1, 1, '2018-11-16');
INSERT INTO cashbill_details (`id`, `date`, `invoicedate`, `invoiceno`, `customerId`, `customername`, `cust_mobno`, `address`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `systemDate`) VALUES (2, '2018-11-16', '2018-11-16', '1', 2, 'karthik kumar', '755896131470', '', 'intrastate', 'sgst', 'cgst', '', '203', 'Tissues paper', 'mtr', '150', '2', '300.00', '0', 'percent_wise', '0.00', '300.00', '12', '36.00', '12', '36.00', '24', '0', '372.00', '372.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '372.00', '1161118', '1-2018', 1, 1, '0000-00-00');
INSERT INTO cashbill_details (`id`, `date`, `invoicedate`, `invoiceno`, `customerId`, `customername`, `cust_mobno`, `address`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `systemDate`) VALUES (3, '2018-11-16', '2018-11-16', '2', 3, 'Manjupriya', '8541236671', '', 'intrastate', 'sgst', 'cgst', '', '205||206||204', 'Ribbon paper||Colour paper||ink bottle', 'mtr||gram||nos', '100||100||0', '10||20||1', '1000.00||1904.76||0.00', '0||0||0', 'percent_wise', '||||', '1000.00||2000.00||0.00', '2.5||2.5||16', '25.00||47.62||0.00', '2.5||2.5||16', '25.00||47.62||0.00', '0||0||0', '5||5||32', '1050.00||2000.00||0.00', '3050.00', '', '0', '', '0', '', '0', '0', '', '', '0', '', '0', '', '0', '0', '', '0', '0', '1||1||1', '3050.00', NULL, NULL, 1, 1, '2018-11-16');
INSERT INTO cashbill_details (`id`, `date`, `invoicedate`, `invoiceno`, `customerId`, `customername`, `cust_mobno`, `address`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `systemDate`) VALUES (4, '2018-11-21', '2018-11-21', '3', 4, 'srinivasan', '515', 'mbj', 'intrastate', 'sgst', 'cgst', '', '001', 'SENIOR DELEX', 'nos', '850', '1', '809.52', '0', 'percent_wise', '0.00', '850.00', '2.5', '20.24', '2.5', '20.24', '5', '0', '850.00', '1370.00', '500', '0', '0.00', '0', '0.00', '0', '', '500.00', '20', '0', '0.00', '0', '0.00', '0', '', '20.00', '0', '0', '1', '1370.00', '3211118', '3-2018', 1, 1, '0000-00-00');
INSERT INTO cashbill_details (`id`, `date`, `invoicedate`, `invoiceno`, `customerId`, `customername`, `cust_mobno`, `address`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `systemDate`) VALUES (5, '2018-11-22', '2018-11-22', '4', 5, 'stand mill stores', '', '93/32 a annadueia road a.v.thetar backbide', 'intrastate', 'sgst', 'cgst', '', '202||205', 'Paper bundle||Ribbon paper', 'mtr||mtr', '200||100', '1||1', '200.00||100.00', '0||0', 'percent_wise', '0.00||0.00', '200.00||100.00', '9||2.5', '18.00||2.50', '9||2.5', '18.00||2.50', '18||5', '0||0', '236.00||105.00', '861.00', '500', '0', '0.00', '0', '0.00', '0', '', '500.00', '20', '0', '0.00', '0', '0.00', '0', '', '20.00', '0', '0', '1||1', '861.00', '4221118', '4-2018', 1, 1, '0000-00-00');
INSERT INTO cashbill_details (`id`, `date`, `invoicedate`, `invoiceno`, `customerId`, `customername`, `cust_mobno`, `address`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `systemDate`) VALUES (6, '2018-11-29', '2018-11-29', '5', 6, 'suresh', '', 'coimbatore', 'intrastate', 'sgst', 'cgst', '', '0', 'paint', 'ltr', '100', '10', '1000.00', '0', 'percent_wise', '0.00', '1000.00', '9', '90.00', '9', '90.00', '18', '0', '1180.00', '1180.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1180.00', '5291118', '5-2018', 1, 1, '0000-00-00');


#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS cashbill_reports;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '0000-00-00', '2018-11-16', '', '2018-11-16', NULL, 1, 'kumareesh', NULL, '', 'intrastate', '202', NULL, 'Paper bundle', '200', '0', '0.00', NULL, '0.00', NULL, NULL, '0.00', NULL, NULL, '1', NULL, NULL, '1');
INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '0000-00-00', '2018-11-16', '1', '2018-11-16', NULL, 0, 'karthik kumar', '755896131470', '', 'intrastate', '203', NULL, 'Tissues paper', '150', '2', '372.00', NULL, '372.00', NULL, NULL, '372.00', NULL, NULL, '1', '1-2018', '1161118', '2');
INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '0000-00-00', '2018-11-16', '2', '2018-11-16', NULL, 3, 'Manjupriya', NULL, '', 'intrastate', '205', NULL, 'Ribbon paper', '100', '10', '1050.00', NULL, '3050.00', NULL, NULL, '3050.00', NULL, NULL, '1', NULL, NULL, '3');
INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, '0000-00-00', '2018-11-16', '2', '2018-11-16', NULL, 3, 'Manjupriya', NULL, '', 'intrastate', '206', NULL, 'Colour paper', '100', '20', '2000.00', NULL, '3050.00', NULL, NULL, '3050.00', NULL, NULL, '1', NULL, NULL, '3');
INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, '0000-00-00', '2018-11-16', '2', '2018-11-16', NULL, 3, 'Manjupriya', NULL, '', 'intrastate', '204', NULL, 'ink bottle', '0', '1', '0.00', NULL, '3050.00', NULL, NULL, '3050.00', NULL, NULL, '1', NULL, NULL, '3');
INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '0000-00-00', '2018-11-21', '3', '2018-11-21', NULL, 0, 'srinivasan', '515', 'mbj', 'intrastate', '001', NULL, 'SENIOR DELEX', '850', '1', '850.00', NULL, '1370.00', NULL, NULL, '1370.00', NULL, NULL, '1', '3-2018', '3211118', '4');
INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '0000-00-00', '2018-11-22', '4', '2018-11-22', NULL, 0, 'stand mill stores', '', '93/32 a annadueia road a.v.thetar backbide', 'intrastate', '202', NULL, 'Paper bundle', '200', '1', '236.00', NULL, '861.00', NULL, NULL, '861.00', NULL, NULL, '1', '4-2018', '4221118', '5');
INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '0000-00-00', '2018-11-22', '4', '2018-11-22', NULL, 0, 'stand mill stores', '', '93/32 a annadueia road a.v.thetar backbide', 'intrastate', '205', NULL, 'Ribbon paper', '100', '1', '105.00', NULL, '861.00', NULL, NULL, '861.00', NULL, NULL, '1', '4-2018', '4221118', '5');
INSERT INTO cashbill_reports (`id`, `date`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '0000-00-00', '2018-11-29', '5', '2018-11-29', NULL, 0, 'suresh', '', 'coimbatore', 'intrastate', '0', NULL, 'paint', '100', '10', '1180.00', NULL, '1180.00', NULL, NULL, '1180.00', NULL, NULL, '1', '5-2018', '5291118', '6');


#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS category;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS collection_details;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2018-11-27', NULL, '2018-11-27', NULL, 'R1', 'chandrasekar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '10000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2018-11-29', NULL, '2018-11-29', NULL, 'R2', 'chandrasekar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '10000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '2018-12-11', NULL, '2018-12-11', NULL, 'R3', 'chandrasekar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cheque INDIAN OVERSEAS 123233', NULL, NULL, NULL, NULL, '20000', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS company_logo;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO company_logo (`id`, `date`, `image`, `status`) VALUES (1, '2017-12-27', 'images.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS customer_details;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (1, '2018-11-16', 'Intra customer', 'kumareesh', '854133693610', '', '', 'West , Raithina puram', 'vincent', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', '8590', '0', '13900', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '44', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (2, '2018-11-16', 'Intra customer', 'chandrasekar', '8500123698', '', '12th, lakshmi puram Street,', 'West main road', 'priya', 'Tamil nadu', 'coimbatore.', '', '', NULL, '0.00', '56772', '20000', '27512', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '55', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (3, '2018-11-16', 'Intra customer', 'Manjupriya', '8541236671', '', '', 'Namakkal road,', 'kumar', 'Tamil Nadu', 'Erode', '', '', NULL, '0.00', '-6564', '6100', '1652', NULL, '', NULL, '641502', NULL, NULL, NULL, NULL, NULL, '1', '', '', '55', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (4, '2018-11-16', 'Intra supplier', 'uma gowri', '', '', 'mariamman  temple', 'Near by city union bank', 'kumareesh', 'TamilNadu', 'Salem', '', '', NULL, '0.00', '8146.4', NULL, '8146.4', NULL, '', NULL, '641023', NULL, NULL, NULL, NULL, NULL, '1', '', '', '55', '', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (5, '2018-12-29', 'Inter supplier', 'Ganesh kumar', '', '', 'kumaren street', 'Trichy road', 'jayakumar', 'Tamil Nadu', 'THANJAVUR', '', '', NULL, '0.00', '136238.8', '50000', '86238.8', '1928.4', '', NULL, '615402', NULL, NULL, NULL, NULL, NULL, '1', '', '', '55', '78452WJLKM85410', '', '', '', '');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`) VALUES (6, '2018-11-21', 'Intra customer', 'STAND MILL STORS', '', '', '93/32-a av theater annadueru road ', 'COIMBATORE', '', NULL, 'TAMILNADU', '', '', NULL, '25000', '19100', NULL, '44100', NULL, '', NULL, '64014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS customerpo_details;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS dc_delivery;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (10, '2018-11-27', 4, 4, 'Against Inward', 'D1', '2018-11-27', 1, 'kumareesh', '', ', West , Raithina puram', 'I3', '45621', '2018-11-27', 'Paper bundle', '', '10', '10', 'Welding', '202', 'mtr', 'D1-18', 'D1271118', 1, 1);
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (11, '2018-11-27', 5, NULL, 'Direct DC', 'D2', '2018-11-27', 1, 'kumareesh', '', ', West , Raithina puram', NULL, NULL, NULL, 'fanta orange', '', '100', '100', '', '111', 'ltr', 'D2-18', 'D2271118', 1, 1);
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (12, '2018-11-29', 6, NULL, 'Direct DC', 'D3', '2018-11-29', 2, 'chandrasekar', '', '12th, lakshmi puram Street,, West main road', NULL, NULL, NULL, 'paint', '', '10', '10', '1st', '0', 'ltr', 'D3-18', 'D3291118', 1, 1);
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (13, '2018-12-05', 7, 5, 'Against Inward', 'D4', '2018-12-05', 1, 'kumareesh', '', ', West , Raithina puram', 'I4', '1451', '2018-12-05', 'Paper bundle', '', '50', '50', '', '202', 'mtr', 'D4-18', 'D4051218', 1, 1);
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (14, '2018-12-05', 8, 6, 'Against Inward', 'D5', '2018-12-05', 1, 'kumareesh', '', ', West , Raithina puram', 'I5', '55', '2018-12-05', 'bush', '', '5', '5', '', '789', 'NOS', 'D5-18', 'D5051218', 1, 1);
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (15, '2018-12-20', 9, 7, 'Against Inward', 'D6', '2018-12-20', 6, 'STAND MILL STORS', '', '93/32-a av theater annadueru road , COIMBATORE', 'I6', '10112', '2018-12-20', 'Steel', '', '50', '0', '', '201', 'nos', 'D6-18', 'D6201218', 1, 0);
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (16, '2018-12-20', 10, 7, 'Against Inward', 'D7', '2018-12-20', 6, 'STAND MILL STORS', '', '93/32-a av theater annadueru road , COIMBATORE', 'I6', '10112', '2018-12-20', 'Steel', '', '50', '0', '', '201', 'nos', 'D7-18', 'D7201218', 1, 0);
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (17, '2018-12-28', 3, NULL, 'Direct DC', 'D', '2018-11-23', 1, 'kumareesh', '', ', West , Raithina puram', NULL, NULL, NULL, 'Steel', '', '2', '2', 'return', '201', 'nos', 'D-18', 'D281218', 1, 1);


#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS dcbill_details;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (3, '2018-12-28', 'Direct DC', 'D', '2018-11-23', 1, 'kumareesh', '', ', West , Raithina puram', '0', NULL, NULL, 'Steel', '', '2', 'return', '201', 'nos', 'D-18', 'D281218', 1, 1, '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (4, '2018-11-27', 'Against Inward', 'D1', '2018-11-27', 1, 'kumareesh', '', ', West , Raithina puram', 'I3', '45621', '2018-11-27', 'Paper bundle', '', '10', 'Welding', '202', 'mtr', 'D1-18', 'D1271118', 1, 1, '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (5, '2018-11-27', 'Direct DC', 'D2', '2018-11-27', 1, 'kumareesh', '', ', West , Raithina puram', NULL, NULL, NULL, 'fanta orange', '', '100', '', '111', 'ltr', 'D2-18', 'D2271118', 1, 1, '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (6, '2018-11-29', 'Direct DC', 'D3', '2018-11-29', 2, 'chandrasekar', '', '12th, lakshmi puram Street,, West main road', NULL, NULL, NULL, 'paint', '', '10', '1st', '0', 'ltr', 'D3-18', 'D3291118', 1, 1, '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (7, '2018-12-05', 'Against Inward', 'D4', '2018-12-05', 1, 'kumareesh', '', ', West , Raithina puram', 'I4', '1451', '2018-12-05', 'Paper bundle', '', '50', '', '202', 'mtr', 'D4-18', 'D4051218', 1, 1, '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (8, '2018-12-05', 'Against Inward', 'D5', '2018-12-05', 1, 'kumareesh', '', ', West , Raithina puram', 'I5', '55', '2018-12-05', 'bush', '', '5', '', '789', 'NOS', 'D5-18', 'D5051218', 1, 1, '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (9, '2018-12-20', 'Against Inward', 'D6', '2018-12-20', 6, 'STAND MILL STORS', '', '93/32-a av theater annadueru road , COIMBATORE', 'I6', '10112', '2018-12-20', 'Steel', '', '50', '', '201', 'nos', 'D6-18', 'D6201218', 1, 1, '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (10, '2018-12-20', 'Against Inward', 'D7', '2018-12-20', 6, 'STAND MILL STORS', '', '93/32-a av theater annadueru road , COIMBATORE', 'I6', '10112', '2018-12-20', 'Steel', '', '50', '', '201', 'nos', 'D7-18', 'D7201218', 1, 0, '');


#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (1, '2018-11-21', '', 'VGFX,H', '2018-11-21', 'GFJVT', 'Cash', '0', '', '', '0', '', '58286', 'Credit Card', 'Cash', '58286', '1', 'worker', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (2, '2018-11-27', '1', 'tea', '2018-11-27', 'advance', 'Cash', '0', '', '', '0', '', '1000', 'Credit Card', 'Cash', '1000', '1', 'tea', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (3, '2018-11-29', '2', 'raja', '2018-11-29', 'novrent', 'Cash', '0', '', '', '0', '', '10000', 'Credit Card', 'Cash', '10000', '1', 'rent', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (4, '2018-11-29', '3', 'tea', '2018-11-29', 'k', 'Cash', '0', '', '', '0', '', '50', 'Credit Card', 'Cash', '50', '1', 'tea', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (5, '2018-11-30', '4', 'Dhv', '2018-11-30', 'Ugh Inc j', 'Cash', '0', '', '', '0', '', '599', 'Credit Card', 'Cash', '599', '1', 'worker', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (6, '2018-12-03', '5', 'g', '2018-12-03', 'of', 'Cash', '0', '', '', '0', '', '10000', 'Credit Card', 'Cash', '10000', '1', 'rent', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (7, '2018-12-07', '6', 'vincent', '2018-12-07', 'Service', 'Cash', '0', '', '', '0', '', '10000', 'Credit Card', 'Cash', '10000', '1', 'labour', '');
INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (8, '2018-12-07', '7', 'Mr.low', '2018-12-07', 'accounting', 'Cash', '0', '', '', '0', '', '6389', 'Credit Card', 'Cash', '6389', '1', 'accounting fee', '');


#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS headers;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (1, '2018-11-16', 1, 'worker');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (2, '2018-11-16', 1, 'labour');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (3, '2018-11-27', 1, 'tea');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (4, '2018-11-29', 1, 'rent');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (5, '2018-12-07', 1, 'accounting fee');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (6, '2018-12-07', 1, 'bank cnarge');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES (7, '2018-12-07', 1, 'donation');


#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS invoice_details;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (1, '2018-11-21', '2018-11-16', '5021', '2018-11-09', 'INV', NULL, 'Sales Invoice', 'Direct Invoice', 0, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', 'Trichy', 'Trucks', 'TN 45 PR 9601', 'interstate', 'interstate', '', '', 'igst', NULL, '0', NULL, '201||202||205||206', 'Steel||Paper bundle||Ribbon paper||Colour paper', '||||||', 'nos||mtr||mtr||gram', '150||200||100||100', '2||10||10||15', '241.94||2000.00||1000.00||1428.57', '0||0||0||0', 'percent_wise', '0.00||0.00||0.00||1500', '300.00||2000.00||1000.00||1500.00', '12||9||2.5||2.5', '29.03||180.00||25.00||35.71', '12||9||2.5||2.5', '29.03||180.00||25.00||35.71', '24||18||5||5', '58.06||360.00||50.00||71.43', '300.00||2360.00||1050.00||1500.00', '5210.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '5210.00', NULL, NULL, 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (2, '2018-11-16', '2018-11-16', '502', '2018-11-08', 'INV1', NULL, 'Sales Invoice', 'Direct Invoice', 2, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', '', 'van', 'TN 58 PR 9841', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '203', 'Tissues paper', '', 'mtr', '150', '10', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '12', '180.00', '12', '180.00', '24', '360.00', '1860.00', '1860.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1860.00', 'INV1161118', 'INV1-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (3, '2018-11-27', '2018-11-27', '', '2018-11-20', 'INV2', NULL, 'Sales Invoice', 'Direct Invoice', 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '207', 'Reynolds pen', '', 'nos', '100', '10', '1000.00', '0', 'percent_wise', '0.00', '1000.00', '9', '90.00', '9', '90.00', '18', '180.00', '1180.00', '1180.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1180.00', 'INV2271118', 'INV2-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (4, '2018-11-27', '2018-11-27', '', '1970-01-01', 'INV3', NULL, 'Sales Invoice', 'Against PO', 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', '7', '202', 'Paper bundle', '', 'mtr', '200', '5', '1000.00', '0', 'percent_wise', '', '1000.00', '9', '90.00', '9', '90.00', '18', '', '1180.00', '1180.00', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '0', '0', '0', '1', '1180.00', 'INV3271118', 'INV3-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (5, '2018-11-27', '2018-11-27', '', '1970-01-01', 'INV4', NULL, 'Sales Invoice', 'Direct Invoice', 2, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '111', 'fanta orange', '', 'ltr', '500', '100', '50000.00', '0', 'percent_wise', '0.00', '50000.00', '9', '4500.00', '9', '4500.00', '18', '9000.00', '59000.00', '59242.00', '100', '9', '9.00', '9', '9.00', '18', '18.00', '118.00', '100', '12', '12.00', '12', '12.00', '24', '24.00', '124.00', '0', '0', '1', '59242.00', 'INV4271118', 'INV4-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (6, '2018-12-01', '2018-11-29', '', '2018-11-29', 'INV5', NULL, 'Sales Invoice', 'Direct Invoice', 0, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '', '', '', 'interstate', 'interstate', '', '', 'igst', NULL, '0', NULL, '0', 'paint', '', 'ltr', '100', '15', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '135.00', '9', '135.00', '18', '270.00', '1770.00', '1770.00', '', '0', '0.00', '0', '0.00', '0', '0.00', '0.00', '', '0', '0.00', '0', '0.00', '0', '0.00', '0.00', '0', '0', '1', '1770.00', NULL, NULL, 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (7, '2018-12-04', '2018-12-04', '101', '2018-12-01', 'INV6', NULL, 'Labour Bill', 'Direct Invoice', 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', 'Erode', 'cad', 'fdfd', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '201', 'Steel', '', 'nos', '150', '10', '1209.68', '0', 'percent_wise', '0.00', '1500.00', '12', '145.16', '12', '145.16', '24', '290.32', '1500.00', '1500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1500.00', 'INV6041218', 'INV6-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (8, '2018-12-05', '2018-12-05', '', '1970-01-01', 'INV7', NULL, 'Sales Invoice', 'Against PO', 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', '10||11', '202||205', 'Paper bundle||Ribbon paper', '||', 'mtr||mtr', '200||100', '5||10', '1000.00||1000.00', '0||0', 'percent_wise', '||', '1000.00||1000.00', '9||2.5', '90.00||25.00', '9||2.5', '90.00||25.00', '18||5', '||', '1180.00||1050.00', '2230.00', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '0', '0', '0', '1||1', '2230.00', 'INV7051218', 'INV7-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (9, '2018-12-20', '2018-12-20', '', '1970-01-01', 'INV8', 'D6||D7', 'Sales Invoice', 'Against DC', 6, 'STAND MILL STORS', '93/32-a av theater annadueru road , COIMBATORE, TAMILNADU, ', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'D6||D7', '10', '15||16', '201||201', 'Steel||Steel', '||', 'nos||nos', '150||150', '50||50', '7500.00||7500.00', '0||0', 'percent_wise', '||', '7500.00||7500.00', '12||12', '900.00||900.00', '12||12', '900.00||900.00', '24||24', '||', '9300.00||9300.00', '18600.00', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '0', '0', '0', '1||1', '18600.00', 'INV8201218', 'INV8-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (10, '2018-12-27', '2018-12-27', '1042', '2018-12-06', 'INV9', NULL, 'Sales Invoice', 'Direct Invoice', 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '', 'fdsfsf', 'ffff', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '201', 'Steel', '', 'nos', '150', '10', '1209.68', '0', 'percent_wise', '0.00', '1500.00', '12', '145.16', '12', '145.16', '24', '290.32', '1500.00', '1500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1500.00', 'INV9271218', 'INV9-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (11, '2018-12-27', '2018-12-27', '14552', '2018-12-27', 'INV9', NULL, 'Sales Invoice', 'Direct Invoice', 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '203', 'Tissues paper', '', 'mtr', '150', '10', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '12', '180.00', '12', '180.00', '24', '360.00', '1860.00', '1860.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1860.00', 'INV9271218', 'INV9-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (12, '2018-12-27', '2018-12-27', '7410', '2018-12-07', 'INV10', NULL, 'Sales Invoice', 'Direct Invoice', 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', 'Trichy', 'van', 'TN 48 PR 85', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '201', 'Steel', '', 'nos', '150', '10', '1209.68', '0', 'percent_wise', '0.00', '1500.00', '12', '145.16', '12', '145.16', '24', '290.32', '1500.00', '1500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1500.00', 'INV10271218', 'INV10-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (13, '2018-12-27', '2018-12-27', '32102', '2018-12-26', 'INV11', NULL, 'Sales Invoice', 'Direct Invoice', 6, 'STAND MILL STORS', '93/32-a av theater annadueru road , COIMBATORE, TAMILNADU, ', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '206', 'Colour paper', '', 'gram', '100', '5', '476.19', '0', 'percent_wise', '0.00', '500.00', '2.5', '11.90', '2.5', '11.90', '5', '23.81', '500.00', '500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '500.00', 'INV10271218', 'INV10-2018', 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (14, '2018-12-29', '2018-12-27', '4102', '2018-12-22', 'INV12', NULL, 'Sales Invoice', 'Direct Invoice', 0, 'Manjupriya', ', Namakkal road,, Erode, Tamil Nadu', 'Trichy', 'tempo', 'TN 48 DA 5410', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '207', 'Reynolds pen', '', 'nos', '100', '10', '1000.00', '0', 'percent_wise', '0.00', '1000.00', '9', '90.00', '9', '90.00', '18', '180.00', '1180.00', '1180.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1180.00', NULL, NULL, 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (15, '2018-12-29', '2018-12-27', '4101', '2018-12-22', 'INV13', NULL, 'Sales Invoice', 'Direct Invoice', 0, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', 'Trichy', 'Tempo', 'TN 45 DB 2255', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '202', 'Paper bundle', '', 'mtr', '200', '5', '1000.00', '0', 'percent_wise', '0.00', '1000.00', '9', '90.00', '9', '90.00', '18', '180.00', '1180.00', '1180.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1180.00', NULL, NULL, 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (16, '2018-12-29', '2018-12-27', '41025', '2018-12-28', 'INV14', NULL, 'Sales Invoice', 'Direct Invoice', 0, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', 'Trichy', 'Tempo', 'TN 48 PR 8410', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '206', 'Colour paper', '', 'gram', '100', '12', '1142.86', '0', 'percent_wise', '0.00', '1200.00', '2.5', '28.57', '2.5', '28.57', '5', '57.14', '1200.00', '1200.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1200.00', NULL, NULL, 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (17, '2018-12-29', '2018-12-27', '85410', '2018-12-08', 'INV15', NULL, 'Sales Invoice', 'Direct Invoice', 0, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', 'Trichy', 'Tempo', 'TN 48 DC 9841', 'interstate', 'interstate', '', '', 'igst', NULL, '0', NULL, '206', 'Colour paper', '', 'gram', '100', '13', '1176.19', '5', 'percent_wise', '65.00', '1235.00', '2.5', '29.40', '2.5', '29.40', '5', '58.81', '1235.00', '1780.00', '500', '4.5', '22.50', '4.5', '22.50', '9', '45.00', '545.00', '', '0', '0.00', '0', '0.00', '0', '0.00', '0.00', '0', '0', '1', '1780.00', NULL, NULL, 1, 1);
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (18, '2018-12-29', '2018-12-29', '84510', '2018-12-28', 'INV16', NULL, 'Sales Invoice', 'Direct Invoice', 3, 'Manjupriya', ', Namakkal road,, Erode, Tamil Nadu', 'Erode', 'tempo', 'TN 45 DC5562', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '201||203||111', 'Steel||Tissues paper||fanta orange', '||||', 'nos||mtr||ltr', '150||150||1000', '2||2||5', '241.94||300.00||5000.00', '0||0||0', 'percent_wise', '0.00||0.00||0.00', '300.00||300.00||5000.00', '12||12||9', '29.03||36.00||450.00', '12||12||9', '29.03||36.00||450.00', '24||24||18', '58.06||72.00||900.00', '300.00||372.00||5900.00', '6572.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1', '6572.00', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS invoice_party_statement;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '-', '-', NULL, '2018-11-16', 'INV1', 2, 'chandrasekar', '', '', '', 'Tissues paper', '', '', '', NULL, NULL, '', '', '1', '2018-11-16', '2018-11-16', '1860.00', '-', '-', '', '', '-', '-', NULL, '4520', '-', '-', '-', '-', '1860.00', '-', '1860.00', NULL, NULL, 'INV1-2018', 'INV1161118', '2');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '-', '-', NULL, '2018-11-16', 'INV', 2, 'chandrasekar', '', '', '', 'Steel||Paper bundle||Ribbon paper||Colour paper', '||||||', '', '', NULL, NULL, '', '', '1', '2018-11-16', '2018-11-16', '5210.00', '-', '-', '', '', '-', '-', NULL, '7070', '-', '-', '-', '-', '5210.00', '-', '5210.00', NULL, NULL, NULL, NULL, '1');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '-', '-', NULL, '2018-11-27', 'INV2', 1, 'kumareesh', '', '', '', 'Reynolds pen', '', '', '', NULL, NULL, '', '', '1', '2018-11-27', '2018-11-27', '1180.00', '-', '-', '', '', '-', '-', NULL, '1180', '-', '-', '-', '-', '1180.00', '-', '1180.00', NULL, NULL, 'INV2-2018', 'INV2271118', '3');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '-', '-', NULL, '2018-11-27', 'INV3', 1, 'kumareesh', '', '', '', 'Paper bundle', '', '', '', NULL, NULL, '', '', '1', '2018-11-27', '2018-11-27', '1180.00', '-', '-', '', '', '-', '-', NULL, '2360', '-', '-', '-', '-', '1180.00', '-', '1180.00', NULL, NULL, 'INV3-2018', 'INV3271118', '4');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '-', '-', NULL, '2018-11-27', 'INV4', 2, 'chandrasekar', '', '', '', 'fanta orange', '', '', '', NULL, NULL, '', '', '1', '2018-11-27', '2018-11-27', '59242.00', '-', '-', '', '', '-', '-', NULL, '66312', '-', '-', '-', '-', '59242.00', '-', '59242.00', NULL, NULL, 'INV4-2018', 'INV4271118', '5');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, 'R1', '', NULL, '2018-11-27', '-', 0, 'chandrasekar', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2018-11-27', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '56312', NULL, NULL, NULL, 'Cash', NULL, '10000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, 'R2', '', NULL, '2018-11-29', '-', 0, 'chandrasekar', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2018-11-29', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '46312', NULL, NULL, NULL, 'Cash', NULL, '10000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '-', '-', NULL, '2018-11-29', 'INV5', 1, 'kumareesh', '', '', '', 'paint', '', '', '', NULL, NULL, '', '', '1', '2018-11-29', '2018-11-29', '1770.00', '-', '-', '', '', '-', '-', NULL, '4130', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, NULL, NULL, '6');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '-', '-', NULL, '2018-12-04', 'INV6', 1, 'kumareesh', '', '', '', 'Steel', '', '', '', NULL, NULL, '', '', '1', '2018-12-04', '2018-12-04', '1500.00', '-', '-', '', '', '-', '-', NULL, '5630', '-', '-', '-', '-', '1500.00', '-', '1500.00', NULL, NULL, 'INV6-2018', 'INV6041218', '7');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, '-', '-', NULL, '2018-12-05', 'INV7', 1, 'kumareesh', '', '', '', 'Paper bundle||Ribbon paper', '||', '', '', NULL, NULL, '', '', '1', '2018-12-05', '2018-12-05', '2230.00', '-', '-', '', '', '-', '-', NULL, '7860', '-', '-', '-', '-', '2230.00', '-', '2230.00', NULL, NULL, 'INV7-2018', 'INV7051218', '8');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, 'R3', '', NULL, '2018-12-11', '-', 0, 'chandrasekar', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2018-12-11', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '26312', NULL, NULL, NULL, 'Cheque INDIAN OVERSEAS 123233', NULL, '20000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '-', '-', NULL, '2018-12-20', 'INV8', 6, 'STAND MILL STORS', '', '', '', 'Steel||Steel', '||', '', '', NULL, NULL, '', '', '1', '2018-12-20', '2018-12-20', '18600.00', '-', '-', '', '', '-', '-', NULL, '43600', '-', '-', '-', '-', '18600.00', '-', '18600.00', NULL, NULL, 'INV8-2018', 'INV8201218', '9');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '-', '-', NULL, '2018-12-27', 'INV9', 1, 'kumareesh', '', '', '', 'Steel', '', '', '', NULL, NULL, '', '', '1', '2018-12-27', '2018-12-27', '1500.00', '-', '-', '', '', '-', '-', NULL, '9360', '-', '-', '-', '-', '1500.00', '-', '1500.00', NULL, NULL, 'INV9-2018', 'INV9271218', '10');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '-', '-', NULL, '2018-12-27', 'INV9', 1, 'kumareesh', '', '', '', 'Tissues paper', '', '', '', NULL, NULL, '', '', '1', '2018-12-27', '2018-12-27', '1860.00', '-', '-', '', '', '-', '-', NULL, '11220', '-', '-', '-', '-', '1860.00', '-', '1860.00', NULL, NULL, 'INV9-2018', 'INV9271218', '11');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '-', '-', NULL, '2018-12-27', 'INV10', 1, 'kumareesh', '', '', '', 'Steel', '', '', '', NULL, NULL, '', '', '1', '2018-12-27', '2018-12-27', '1500.00', '-', '-', '', '', '-', '-', NULL, '12720', '-', '-', '-', '-', '1500.00', '-', '1500.00', NULL, NULL, 'INV10-2018', 'INV10271218', '12');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '-', '-', NULL, '2018-12-27', 'INV10', 6, 'STAND MILL STORS', '', '', '', 'Colour paper', '', '', '', NULL, NULL, '', '', '1', '2018-12-27', '2018-12-27', '500.00', '-', '-', '', '', '-', '-', NULL, '44100', '-', '-', '-', '-', '500.00', '-', '500.00', NULL, NULL, 'INV10-2018', 'INV10271218', '13');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (23, '-', '-', NULL, '2018-12-27', 'INV15', 0, 'chandrasekar', '', '', '', 'Colour paper', '', '', '', NULL, NULL, '', '', '1', '2018-12-27', '2018-12-27', '1780.00', '-', '-', '', '', '-', '-', NULL, '27512', '-', '-', '-', '-', '1780.00', '-', '1780.00', NULL, NULL, NULL, NULL, '17');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (24, '-', '-', NULL, '2018-12-27', 'INV14', 2, 'chandrasekar', '', '', '', 'Colour paper', '', '', '', NULL, NULL, '', '', '1', '2018-12-27', '2018-12-27', '1200.00', '-', '-', '', '', '-', '-', NULL, '27512', '-', '-', '-', '-', '1200.00', '-', '1200.00', NULL, NULL, NULL, NULL, '16');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (25, '-', '-', NULL, '2018-12-27', 'INV13', 1, 'kumareesh', '', '', '', 'Paper bundle', '', '', '', NULL, NULL, '', '', '1', '2018-12-27', '2018-12-27', '1180.00', '-', '-', '', '', '-', '-', NULL, '13900', '-', '-', '-', '-', '1180.00', '-', '1180.00', NULL, NULL, NULL, NULL, '15');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (27, '-', '-', NULL, '2018-12-27', 'INV12', 0, 'Manjupriya', '', '', '', 'Reynolds pen', '', '', '', NULL, NULL, '', '', '1', '2018-12-27', '2018-12-27', '1180.00', '-', '-', '', '', '-', '-', NULL, '-4920', '-', '-', '-', '-', '1180.00', '-', '1180.00', NULL, NULL, NULL, NULL, '14');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (31, '-', '-', NULL, '2018-12-29', 'INV16', 3, 'Manjupriya', '', '', '', 'Steel||Tissues paper||fanta orange', '||||', '', '', NULL, NULL, '', '', '1', '2018-12-29', '2018-12-29', '6572.00', '-', '-', '', '', '-', '-', NULL, '1652', '-', '-', '-', '-', '6572.00', '-', '6572.00', NULL, NULL, NULL, NULL, '18');


#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS invoice_reports;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '2018-11-16', 'INV1', '2018-11-16', NULL, NULL, 2, 'chandrasekar', NULL, NULL, NULL, '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', 'intrastate', 'intrastate', '', 'TN 58 PR 9841', NULL, '2018-11-08', '502', NULL, '203', NULL, 'Tissues paper', '', '1', '10', '1', NULL, '1860.00', NULL, NULL, '1860.00', NULL, NULL, '1', 'INV1-2018', 'INV1161118', '2');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '2018-11-21', 'INV', '2018-11-16', NULL, NULL, 0, 'chandrasekar', NULL, NULL, NULL, '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', 'interstate', 'interstate', 'Trichy', 'TN 45 PR 9601', NULL, '2018-11-09', '5021', NULL, '201', NULL, 'Steel', '', '150', '2', '300.00', NULL, '5210.00', NULL, NULL, '5210.00', NULL, NULL, '1', NULL, NULL, '1');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '2018-11-21', 'INV', '2018-11-16', NULL, NULL, 0, 'chandrasekar', NULL, NULL, NULL, '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', 'interstate', 'interstate', 'Trichy', 'TN 45 PR 9601', NULL, '2018-11-09', '5021', NULL, '202', NULL, 'Paper bundle', '', '200', '10', '2360.00', NULL, '5210.00', NULL, NULL, '5210.00', NULL, NULL, '1', NULL, NULL, '1');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '2018-11-21', 'INV', '2018-11-16', NULL, NULL, 0, 'chandrasekar', NULL, NULL, NULL, '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', 'interstate', 'interstate', 'Trichy', 'TN 45 PR 9601', NULL, '2018-11-09', '5021', NULL, '205', NULL, 'Ribbon paper', '', '100', '10', '1050.00', NULL, '5210.00', NULL, NULL, '5210.00', NULL, NULL, '1', NULL, NULL, '1');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '2018-11-21', 'INV', '2018-11-16', NULL, NULL, 0, 'chandrasekar', NULL, NULL, NULL, '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', 'interstate', 'interstate', 'Trichy', 'TN 45 PR 9601', NULL, '2018-11-09', '5021', NULL, '206', NULL, 'Colour paper', '', '100', '15', '1500.00', NULL, '5210.00', NULL, NULL, '5210.00', NULL, NULL, '1', NULL, NULL, '1');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '2018-11-27', 'INV2', '2018-11-27', NULL, NULL, 1, 'kumareesh', NULL, NULL, NULL, ', West , Raithina puram, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '2018-11-20', '', NULL, '207', NULL, 'Reynolds pen', '', '1', '10', '1', NULL, '1180.00', NULL, NULL, '1180.00', NULL, NULL, '1', 'INV2-2018', 'INV2271118', '3');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '2018-11-27', 'INV3', '2018-11-27', NULL, NULL, 1, 'kumareesh', NULL, NULL, NULL, ', West , Raithina puram, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '202', NULL, 'Paper bundle', '', '2', '5', '1', NULL, '1180.00', NULL, NULL, '1180.00', NULL, NULL, '1', 'INV3-2018', 'INV3271118', '4');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '2018-11-27', 'INV4', '2018-11-27', NULL, NULL, 2, 'chandrasekar', NULL, NULL, NULL, '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '111', NULL, 'fanta orange', '', '5', '100', '5', NULL, '59242.00', NULL, NULL, '59242.00', NULL, NULL, '1', 'INV4-2018', 'INV4271118', '5');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, '2018-12-01', 'INV5', '2018-11-29', NULL, NULL, 0, 'kumareesh', NULL, NULL, NULL, ', West , Raithina puram, Coimbatore, Tamil Nadu', 'interstate', 'interstate', '', '', NULL, '2018-11-29', '', NULL, '0', NULL, 'paint', '', '100', '15', '1770.00', NULL, '1770.00', NULL, NULL, '1770.00', NULL, NULL, '1', NULL, NULL, '6');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, '2018-12-04', 'INV6', '2018-12-04', NULL, NULL, 1, 'kumareesh', NULL, NULL, NULL, ', West , Raithina puram, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', 'Erode', 'fdfd', NULL, '2018-12-01', '101', NULL, '201', NULL, 'Steel', '', '1', '10', '1', NULL, '1500.00', NULL, NULL, '1500.00', NULL, NULL, '1', 'INV6-2018', 'INV6041218', '7');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '2018-12-05', 'INV7', '2018-12-05', NULL, NULL, 1, 'kumareesh', NULL, NULL, NULL, ', West , Raithina puram, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '202', NULL, 'Paper bundle', '', '2', '5', '1', NULL, '2230.00', NULL, NULL, '2230.00', NULL, NULL, '1', 'INV7-2018', 'INV7051218', '8');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '2018-12-05', 'INV7', '2018-12-05', NULL, NULL, 1, 'kumareesh', NULL, NULL, NULL, ', West , Raithina puram, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '205', NULL, 'Ribbon paper', '', '0', '10', '1', NULL, '2230.00', NULL, NULL, '2230.00', NULL, NULL, '1', 'INV7-2018', 'INV7051218', '8');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '2018-12-20', 'INV8', '2018-12-20', NULL, NULL, 6, 'STAND MILL STORS', NULL, NULL, NULL, '93/32-a av theater annadueru road , COIMBATORE, TAMILNADU, ', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '201', NULL, 'Steel', '', '1', '50', '9', NULL, '18600.00', NULL, NULL, '18600.00', NULL, NULL, '1', 'INV8-2018', 'INV8201218', '9');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '2018-12-20', 'INV8', '2018-12-20', NULL, NULL, 6, 'STAND MILL STORS', NULL, NULL, NULL, '93/32-a av theater annadueru road , COIMBATORE, TAMILNADU, ', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '201', NULL, 'Steel', '', '5', '50', '3', NULL, '18600.00', NULL, NULL, '18600.00', NULL, NULL, '1', 'INV8-2018', 'INV8201218', '9');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '2018-12-27', 'INV9', '2018-12-27', NULL, NULL, 1, 'kumareesh', NULL, NULL, NULL, ', West , Raithina puram, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', 'ffff', NULL, '2018-12-06', '1042', NULL, '201', NULL, 'Steel', '', '1', '10', '1', NULL, '1500.00', NULL, NULL, '1500.00', NULL, NULL, '1', 'INV9-2018', 'INV9271218', '10');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (19, '2018-12-27', 'INV9', '2018-12-27', NULL, NULL, 1, 'kumareesh', NULL, NULL, NULL, ', West , Raithina puram, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '2018-12-27', '14552', NULL, '203', NULL, 'Tissues paper', '', '1', '10', '1', NULL, '1860.00', NULL, NULL, '1860.00', NULL, NULL, '1', 'INV9-2018', 'INV9271218', '11');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '2018-12-27', 'INV10', '2018-12-27', NULL, NULL, 1, 'kumareesh', NULL, NULL, NULL, ', West , Raithina puram, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', 'Trichy', 'TN 48 PR 85', NULL, '2018-12-07', '7410', NULL, '201', NULL, 'Steel', '', '1', '10', '1', NULL, '1500.00', NULL, NULL, '1500.00', NULL, NULL, '1', 'INV10-2018', 'INV10271218', '12');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, '2018-12-27', 'INV10', '2018-12-27', NULL, NULL, 6, 'STAND MILL STORS', NULL, NULL, NULL, '93/32-a av theater annadueru road , COIMBATORE, TAMILNADU, ', 'intrastate', 'intrastate', '', '', NULL, '2018-12-26', '32102', NULL, '206', NULL, 'Colour paper', '', '1', '5', '5', NULL, '500.00', NULL, NULL, '500.00', NULL, NULL, '1', 'INV10-2018', 'INV10271218', '13');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (26, '2018-12-29', 'INV15', '2018-12-27', NULL, NULL, 0, 'chandrasekar', NULL, NULL, NULL, '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', 'interstate', 'interstate', 'Trichy', 'TN 48 DC 9841', NULL, '2018-12-08', '85410', NULL, '206', NULL, 'Colour paper', '', '100', '13', '1235.00', NULL, '1780.00', NULL, NULL, '1780.00', NULL, NULL, '1', NULL, NULL, '17');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (27, '2018-12-29', 'INV14', '2018-12-27', NULL, NULL, 0, 'chandrasekar', NULL, NULL, NULL, '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', 'intrastate', 'intrastate', 'Trichy', 'TN 48 PR 8410', NULL, '2018-12-28', '41025', NULL, '206', NULL, 'Colour paper', '', '100', '12', '1200.00', NULL, '1200.00', NULL, NULL, '1200.00', NULL, NULL, '1', NULL, NULL, '16');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (28, '2018-12-29', 'INV13', '2018-12-27', NULL, NULL, 0, 'kumareesh', NULL, NULL, NULL, ', West , Raithina puram, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', 'Trichy', 'TN 45 DB 2255', NULL, '2018-12-22', '4101', NULL, '202', NULL, 'Paper bundle', '', '200', '5', '1180.00', NULL, '1180.00', NULL, NULL, '1180.00', NULL, NULL, '1', NULL, NULL, '15');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (30, '2018-12-29', 'INV12', '2018-12-27', NULL, NULL, 0, 'Manjupriya', NULL, NULL, NULL, ', Namakkal road,, Erode, Tamil Nadu', 'intrastate', 'intrastate', 'Trichy', 'TN 48 DA 5410', NULL, '2018-12-22', '4102', NULL, '207', NULL, 'Reynolds pen', '', '100', '10', '1180.00', NULL, '1180.00', NULL, NULL, '1180.00', NULL, NULL, '1', NULL, NULL, '14');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (35, '2018-12-29', 'INV16', '2018-12-29', NULL, NULL, 0, 'Manjupriya', NULL, NULL, NULL, ', Namakkal road,, Erode, Tamil Nadu', 'intrastate', 'intrastate', 'Erode', 'TN 45 DC5562', NULL, '2018-12-28', '84510', NULL, '201', NULL, 'Steel', '', '150', '2', '300.00', NULL, '6572.00', NULL, NULL, '6572.00', NULL, NULL, '1', NULL, NULL, '18');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (36, '2018-12-29', 'INV16', '2018-12-29', NULL, NULL, 0, 'Manjupriya', NULL, NULL, NULL, ', Namakkal road,, Erode, Tamil Nadu', 'intrastate', 'intrastate', 'Erode', 'TN 45 DC5562', NULL, '2018-12-28', '84510', NULL, '203', NULL, 'Tissues paper', '', '150', '2', '372.00', NULL, '6572.00', NULL, NULL, '6572.00', NULL, NULL, '1', NULL, NULL, '18');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (37, '2018-12-29', 'INV16', '2018-12-29', NULL, NULL, 0, 'Manjupriya', NULL, NULL, NULL, ', Namakkal road,, Erode, Tamil Nadu', 'intrastate', 'intrastate', 'Erode', 'TN 45 DC5562', NULL, '2018-12-28', '84510', NULL, '111', NULL, 'fanta orange', '', '1000', '5', '5900.00', NULL, '6572.00', NULL, NULL, '6572.00', NULL, NULL, '1', NULL, NULL, '18');


#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS inward_delivery;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (1, 1, '2018-11-16', 'I', '2018-11-16', 'chandrasekar', '12th, lakshmi puram Street,, West main road', '102', '2018-11-16', 'Steel', '', '2', '2', 'goods', '201', 'nos', 'I-18', 'I161118', 1, 1);
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (2, 2, '2018-11-16', 'I1', '2018-11-16', 'kumareesh', ', West , Raithina puram', '103', '2018-11-16', 'Steel', '', '2', '2', 'return', '201', 'nos', 'I1-18', 'I1161118', 1, 1);
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (3, 3, '2018-11-16', 'I2', '2018-11-16', 'kumareesh', ', West , Raithina puram', '201', '2018-11-16', 'Steel', '', '1', '1', 'rettr', '201', 'nos', 'I2-18', 'I2161118', 1, 1);
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (4, 4, '2018-11-27', 'I3', '2018-11-27', 'kumareesh', ', West , Raithina puram', '45621', '2018-11-27', 'Paper bundle', '', '100', '90', 'Welding', '202', 'mtr', 'I3-18', 'I3271118', 1, 1);
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (5, 5, '2018-12-05', 'I4', '2018-12-05', 'kumareesh', ', West , Raithina puram', '1451', '2018-12-05', 'Paper bundle', '', '50', '0', '', '202', 'mtr', 'I4-18', 'I4051218', 1, 0);
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (6, 6, '2018-12-05', 'I5', '2018-12-05', 'kumareesh', ', West , Raithina puram', '55', '2018-12-05', 'bush', '', '10', '5', '', '789', 'NOS', 'I5-18', 'I5051218', 1, 1);
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES (7, 7, '2018-12-20', 'I6', '2018-12-20', 'STAND MILL STORS', '93/32-a av theater annadueru road , COIMBATORE', '10112', '2018-12-20', 'Steel', '', '100', '0', '', '201', 'nos', 'I6-18', 'I6201218', 1, 0);


#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS inward_details;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (1, '2018-11-16', 'I', '2018-11-16', 'chandrasekar', '12th, lakshmi puram Street,, West main road', '102', '2018-11-16', 'Steel', '', '2', 'goods', '201', 'nos', 'I-18', 'I161118', 1, 1, '1');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (2, '2018-11-16', 'I1', '2018-11-16', 'kumareesh', ', West , Raithina puram', '103', '2018-11-16', 'Steel', '', '2', 'return', '201', 'nos', 'I1-18', 'I1161118', 1, 1, '2');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (3, '2018-11-16', 'I2', '2018-11-16', 'kumareesh', ', West , Raithina puram', '201', '2018-11-16', 'Steel', '', '1', 'rettr', '201', 'nos', 'I2-18', 'I2161118', 1, 1, '3');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (4, '2018-11-27', 'I3', '2018-11-27', 'kumareesh', ', West , Raithina puram', '45621', '2018-11-27', 'Paper bundle', '', '100', 'Welding', '202', 'mtr', 'I3-18', 'I3271118', 1, 0, '4');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (5, '2018-12-05', 'I4', '2018-12-05', 'kumareesh', ', West , Raithina puram', '1451', '2018-12-05', 'Paper bundle', '', '50', '', '202', 'mtr', 'I4-18', 'I4051218', 1, 0, '5');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (6, '2018-12-05', 'I5', '2018-12-05', 'kumareesh', ', West , Raithina puram', '55', '2018-12-05', 'bush', '', '10', '', '789', 'NOS', 'I5-18', 'I5051218', 1, 0, '6');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (7, '2018-12-20', 'I6', '2018-12-20', 'STAND MILL STORS', '93/32-a av theater annadueru road , COIMBATORE', '10112', '2018-12-20', 'Steel', '', '100', '', '201', 'nos', 'I6-18', 'I6201218', 1, 0, '7');


#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS job_data;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS job_details;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS jobinward_data;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS jobinward_details;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS login_details;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (1, 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'Myoffice!@#$%', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (5, 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', 1, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (6, 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', 0, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (7, 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', 0, 0, 0);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (8, 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', 1, 0, 0);


#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS po_party_statements;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2018-11-02', '2018-11-16', '-', 'P1', 4, 'uma gowri', NULL, NULL, 'Paper bundle', NULL, '2381.40', '-', '-', '-', NULL, '-', '2381.4', NULL, '-', '-', '-', '-', '-', '2360.00', '-', NULL, '-', NULL, '2381.40', NULL, '8502', '2018-11-02', '1', 'P1161118', 'P1-2018', '2');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (3, '2018-11-04', '2018-11-16', '-', 'P2', 3, 'Harish kumar', NULL, NULL, 'Tissues paper', NULL, '1860.00', '-', '-', '-', NULL, '-', '1860', NULL, '-', '-', '-', '-', '-', '1860.00', '-', NULL, '-', NULL, '1860.00', NULL, '502', '2018-11-04', '1', 'P2161118', 'P2-2018', '3');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (5, '2018-11-16', '2018-11-16', 'C001', 'P', 0, 'Ganesh kumar', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2874', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'It is damgeded', NULL, NULL, '880.40', NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL);
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (6, '2018-11-20', '2018-11-21', '-', 'P3', 7, 'ganesh mill stores', NULL, NULL, 'SENIOR DELEX', NULL, '17570.00', '-', '-', '-', NULL, '-', '20070', NULL, '-', '-', '-', '-', '-', '17000.00', '-', NULL, '-', NULL, '17570.00', NULL, '201', '2018-11-20', '1', 'P3211118', 'P3-2018', '4');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (7, '2018-11-21', NULL, 'R', NULL, 0, 'ganesh mill stores', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '5070', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '15000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (8, '2018-11-21', '2018-11-21', 'C002', 'P3', 0, 'ganesh mill stores', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '-4000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'damage', NULL, NULL, '9070.00', NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL);
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (9, '2018-11-29', '2018-11-29', '-', 'P4', 5, 'Ganesh kumar', NULL, NULL, 'paint', NULL, '118000.00', '-', '-', '-', NULL, '-', '120874', NULL, '-', '-', '-', '-', '-', '118000.00', '-', NULL, '-', NULL, '118000.00', NULL, '111', '2018-11-29', '1', 'P4291118', 'P4-2018', '5');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (10, '2018-11-01', '2018-11-16', '-', 'P', 0, 'Ganesh kumar', NULL, NULL, 'Steel||Tissues paper', NULL, '3754.40', '-', '-', '-', NULL, '-', '120874', NULL, '-', '-', '-', '-', '-', '1500.00||2232.00', '-', NULL, '-', NULL, '3754.40', NULL, '123', '2018-11-01', '1', NULL, NULL, '1');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (11, '2018-12-11', NULL, 'R4', NULL, 0, 'Ganesh kumar', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '70874', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '50000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (12, '2018-12-04', '2018-12-27', '-', 'P5', 5, 'Ganesh kumar', NULL, NULL, 'Reynolds pen', NULL, '1180.00', '-', '-', '-', NULL, '-', '72054', NULL, '-', '-', '-', '-', '-', '1180.00', '-', NULL, '-', NULL, '1180.00', NULL, '1040', '2018-12-04', '1', 'P5271218', 'P5-2018', '6');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (13, '2018-12-19', '2018-12-27', '-', 'P6', 4, 'uma gowri', NULL, NULL, 'Tissues paper', NULL, '1860.00', '-', '-', '-', NULL, '-', '4241.4', NULL, '-', '-', '-', '-', '-', '1860.00', '-', NULL, '-', NULL, '1860.00', NULL, '1525', '2018-12-19', '1', 'P6271218', 'P6-2018', '7');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (14, '2018-12-04', '2018-12-27', '-', 'P6', 5, 'Ganesh kumar', NULL, NULL, 'Tissues paper', NULL, '1860.00', '-', '-', '-', NULL, '-', '73914', NULL, '-', '-', '-', '-', '-', '1860.00', '-', NULL, '-', NULL, '1860.00', NULL, '8520', '2018-12-04', '1', 'P6271218', 'P6-2018', '8');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (15, '2018-12-04', '2018-12-27', '-', 'P7', 5, 'Ganesh kumar', NULL, NULL, 'Reynolds pen', NULL, '1180.00', '-', '-', '-', NULL, '-', '75094', NULL, '-', '-', '-', '-', '-', '1180.00', '-', NULL, '-', NULL, '1180.00', NULL, '4101', '2018-12-04', '1', 'P7271218', 'P7-2018', '9');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (16, '2018-12-27', '2018-12-27', '-', 'P7', 4, 'uma gowri', NULL, NULL, 'paint', NULL, '590.00', '-', '-', '-', NULL, '-', '4831.4', NULL, '-', '-', '-', '-', '-', '590.00', '-', NULL, '-', NULL, '590.00', NULL, '155', '2018-12-27', '1', 'P7271218', 'P7-2018', '10');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (17, '2018-12-19', '2018-12-27', '-', 'P9', 5, 'Ganesh kumar', NULL, NULL, 'Colour paper', NULL, '1000.00', '-', '-', '-', NULL, '-', '76094', NULL, '-', '-', '-', '-', '-', '1000.00', '-', NULL, '-', NULL, '1000.00', NULL, '1562', '2018-12-19', '1', 'P9271218', 'P9-2018', '11');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (18, '2018-12-04', '2018-12-27', '-', 'P9', 4, 'uma gowri', NULL, NULL, 'Tissues paper', NULL, '1860.00', '-', '-', '-', NULL, '-', '6691.4', NULL, '-', '-', '-', '-', '-', '1860.00', '-', NULL, '-', NULL, '1860.00', NULL, '741', '2018-12-04', '1', 'P9271218', 'P9-2018', '12');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (19, '2018-12-05', '2018-12-27', '-', 'P10', 5, 'Ganesh kumar', NULL, NULL, 'Reynolds pen', NULL, '1180.00', '-', '-', '-', NULL, '-', '77274', NULL, '-', '-', '-', '-', '-', '1180.00', '-', NULL, '-', NULL, '1180.00', NULL, '74596', '2018-12-05', '1', 'P10271218', 'P10-2018', '13');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (20, '2018-12-27', '2018-12-27', '-', 'P10', 4, 'uma gowri', NULL, NULL, 'Ribbon paper', NULL, '525.00', '-', '-', '-', NULL, '-', '7216.4', NULL, '-', '-', '-', '-', '-', '525.00', '-', NULL, '-', NULL, '525.00', NULL, '1525', '2018-12-27', '1', 'P10271218', 'P10-2018', '14');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (21, '2018-12-14', '2018-12-27', '-', 'P11', 5, 'Ganesh kumar', NULL, NULL, 'Steel', NULL, '1500.00', '-', '-', '-', NULL, '-', '78774', NULL, '-', '-', '-', '-', '-', '1500.00', '-', NULL, '-', NULL, '1500.00', NULL, '854120', '2018-12-14', '1', 'P11271218', 'P11-2018', '15');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (22, '2018-12-26', '2018-12-27', '-', 'P12', 5, 'Ganesh kumar', NULL, NULL, 'paint', NULL, '236.00', '-', '-', '-', NULL, '-', '79010', NULL, '-', '-', '-', '-', '-', '236.00', '-', NULL, '-', NULL, '236.00', NULL, '152', '2018-12-26', '1', 'P12271218', 'P12-2018', '16');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (23, '2018-12-19', '2018-12-27', '-', 'P14', 4, 'uma gowri', NULL, NULL, 'Tissues paper', NULL, '930.00', '-', '-', '-', NULL, '-', '8146.4', NULL, '-', '-', '-', '-', '-', '930.00', '-', NULL, '-', NULL, '930.00', NULL, '15', '2018-12-19', '1', 'P14271218', 'P14-2018', '17');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (24, '2018-12-07', '2018-12-27', '-', 'P14', 5, 'Ganesh kumar', NULL, NULL, 'Steel', NULL, '3000.00', '-', '-', '-', NULL, '-', '82010', NULL, '-', '-', '-', '-', '-', '3000.00', '-', NULL, '-', NULL, '3000.00', NULL, '8552323', '2018-12-07', '1', 'P14271218', 'P14-2018', '18');
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (25, '2018-12-28', '2018-12-28', 'C003', 'P6', 0, 'Ganesh kumar', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '81080', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'returns', NULL, NULL, '930.00', NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL);
INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (26, '2018-12-28', '2018-12-28', 'C004', 'P7', 0, 'Ganesh kumar', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '80962', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'returns', NULL, NULL, '118.00', NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS preference_details;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS preference_settings;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO preference_settings (`id`, `quotation`, `expenses`, `dc`, `voucher`, `debit`, `credit`, `purchase`, `invoicePrefix`, `invoice`, `proforma_invoicePrefix`, `proforma_invoice`, `inward`, `cashbill_invoice`, `purchaseorder`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`) VALUES (1, '', '', '', '', '', '', '', 'INV', '', 'P', '', '', '', '', 'Myoffice Solutions', '04222570103', '8608701222', '#91, Dr. Jaganathan Nagar, ', 'Civil Aerodrome Post', 'Coimbatore', '641 014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '04222570103', '8608701333', '#91, Dr. Jaganathan Nagar, ', 'Civil Aerodrome Post', 'Coimbatore', '641 014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'percent_wise', 'without_stock', 'with_item');


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS profile;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO profile (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`) VALUES (1, NULL, 'Myoffice BILLING', 'Myoffice BILLING', '9943744177', '0422-2668244', ' #91, Dr, Jaganathan Nagar CMC opp', 'Civil Aerodrome Post', 'Dharmapuri', '641035', 'Tamil Nadu', 'info@idreamdevelopers.com', 'www.idreamdevelopers.org', '12345', '54321', '33AFYPV3340K1ZT', '', '1', 'admin', 'Myoffice!@#$%', 'THE KARUR VYSYA BANK LTD.,', '1748115000002961', 'SARAVANAMPATTI', 'KVBL0001748');


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS proforma_invoice_details;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO proforma_invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (1, '2018-11-16', '2018-11-16', '4021', '2018-11-16', 'P', NULL, 'Sales Invoice', '0', 1, 'Arul Murgan', NULL, 'Trichy', 'Trucks', 'TN 48 CM 8512', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '201', 'Steel', '', 'nos', '150', '2', '241.94', '0', 'percent_wise', '0.00', '300.00', '12', '29.03', '12', '29.03', '24', '58.06', '300.00', '300.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '300.00', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS proforma_invoice_reports;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO proforma_invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2018-11-16', 'P', '2018-11-16', NULL, NULL, 0, 'Arul Murgan', NULL, NULL, NULL, NULL, 'intrastate', 'intrastate', 'Trichy', 'TN 48 CM 8512', NULL, '2018-11-16', '4021', NULL, '201', NULL, 'Steel', '', '150', '2', '300.00', NULL, '300.00', NULL, NULL, '300.00', NULL, NULL, '1', NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS proinvoice_party_statement;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO proinvoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '-', '-', NULL, '2018-11-16', 'P', 1, 'Arul Murgan', '', '', '', 'Steel', '', '', '', NULL, NULL, '', '', '1', '2018-11-16', '2018-11-16', '300.00', '-', '-', '', '', '-', '-', NULL, '300', '-', '-', '-', '-', '300.00', '-', '300.00', NULL, NULL, NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS purchase_collection;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO purchase_collection (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2018-11-21', '0000-00-00', NULL, NULL, '2018-11-21', NULL, 'R', 'ganesh mill stores', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, '15000', NULL, NULL, NULL, NULL, NULL);
INSERT INTO purchase_collection (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2018-12-11', '0000-00-00', NULL, NULL, '2018-12-11', NULL, 'R4', 'Ganesh kumar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, '50000', NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS purchase_details;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2018-11-16', '2018-11-16', '2018-11-01', 'P', 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '123', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '201||203', 'Steel||Tissues paper', 'nos||mtr', '150||150', '10||12', '1209.68||1800.00', '0||', 'percent_wise', '||', '1500.00||1800.00', '12||12', '145.16||216.00', '12||12', '145.16||216.00', '24||24', '290.32||432.00', '1500.00||2232.00', '3754.40', '10', '2', '0.20', '2', '0.20', '4', '0.40', '10.40', '10', '10', '1.00', '10', '1.00', '20', '2.00', '12.00', '0', '0', '1||1', '3754.40', 'P161118', 'P-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2018-11-16', '2018-11-16', '2018-11-02', 'P1', 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '8502', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '202', 'Paper bundle', 'mtr', '200', '10', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '180.00', '9', '180.00', '18', '360.00', '2360.00', '2381.40', '10', '5', '0.50', '5', '0.50', '10', '1.00', '11.00', '10', '2', '0.20', '2', '0.20', '4', '0.40', '10.40', '0', '0', '1', '2381.40', 'P1161118', 'P1-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (3, '2018-11-16', '2018-11-16', '2018-11-04', 'P2', 3, 'Harish kumar', 'kumaren nagar, Namakkal road,, Erode, Tamil Nadu', '502', 'interstate', 'interstate', '', '', 'igst', '203', 'Tissues paper', 'mtr', '150', '10', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '12', '180.00', '12', '180.00', '24', '360.00', '1860.00', '1860.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1860.00', 'P2161118', 'P2-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (4, '2018-11-21', '2018-11-21', '2018-11-20', 'P3', 7, 'ganesh mill stores', 'ADDRESS1, ADDRESS2, COIMBATORE, TAMILNADU', '201', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '001', 'SENIOR DELEX', 'nos', '8500', '2', '16190.48', '0', 'percent_wise', '17000', '17000.00', '2.5', '404.76', '2.5', '404.76', '5', '809.52', '17000.00', '17570.00', '500', '05', '25.00', '05', '25.00', '10', '50.00', '550.00', '20', '0', '0.00', '0', '0.00', '0', '0.00', '20.00', '0', '0', '0', '17570.00', 'P3211118', 'P3-2018', 1, 0);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (5, '2018-11-29', '2018-11-29', '2018-11-29', 'P4', 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '111', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '0', 'paint', 'ltr', '100', '1000', '100000.00', '0', 'percent_wise', '0.00', '100000.00', '9', '9000.00', '9', '9000.00', '18', '18000.00', '118000.00', '118000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '118000.00', 'P4291118', 'P4-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (6, '2018-12-27', '2018-12-27', '2018-12-04', 'P5', 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '1040', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '207', 'Reynolds pen', 'nos', '100', '10', '1000.00', '0', 'percent_wise', '0.00', '1000.00', '9', '90.00', '9', '90.00', '18', '180.00', '1180.00', '1180.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1180.00', 'P5271218', 'P5-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (7, '2018-12-27', '2018-12-27', '2018-12-19', 'P6', 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '1525', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '203', 'Tissues paper', 'mtr', '150', '10', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '12', '180.00', '12', '180.00', '24', '360.00', '1860.00', '1860.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '0', '1860.00', 'P6271218', 'P6-2018', 1, 0);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (8, '2018-12-27', '2018-12-27', '2018-12-04', 'P6', 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '8520', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '203', 'Tissues paper', 'mtr', '150', '10', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '12', '180.00', '12', '180.00', '24', '360.00', '1860.00', '1860.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '0', '1860.00', 'P6271218', 'P6-2018', 1, 0);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (9, '2018-12-27', '2018-12-27', '2018-12-04', 'P7', 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '4101', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '207', 'Reynolds pen', 'nos', '100', '10', '1000.00', '0', 'percent_wise', '0.00', '1000.00', '9', '90.00', '9', '90.00', '18', '180.00', '1180.00', '1180.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '0', '1180.00', 'P7271218', 'P7-2018', 1, 0);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (10, '2018-12-27', '2018-12-27', '2018-12-27', 'P8', 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '155', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '0', 'paint', 'ltr', '100', '5', '500.00', '0', 'percent_wise', '0.00', '500.00', '9', '45.00', '9', '45.00', '18', '90.00', '590.00', '590.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '590.00', 'P7271218', 'P7-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (11, '2018-12-27', '2018-12-27', '2018-12-19', 'P9', 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '1562', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '206', 'Colour paper', 'gram', '100', '10', '952.38', '0', 'percent_wise', '1000', '1000.00', '2.5', '23.81', '2.5', '23.81', '5', '47.62', '1000.00', '1000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1000.00', 'P9271218', 'P9-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (12, '2018-12-27', '2018-12-27', '2018-12-04', 'P9', 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '741', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '203', 'Tissues paper', 'mtr', '150', '10', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '12', '180.00', '12', '180.00', '24', '360.00', '1860.00', '1860.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1860.00', 'P9271218', 'P9-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (13, '2018-12-27', '2018-12-27', '2018-12-05', 'P10', 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '74596', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '207', 'Reynolds pen', 'nos', '100', '10', '1000.00', '0', 'percent_wise', '0.00', '1000.00', '9', '90.00', '9', '90.00', '18', '180.00', '1180.00', '1180.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1180.00', 'P10271218', 'P10-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (14, '2018-12-27', '2018-12-27', '2018-12-27', 'P11', 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '1525', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '205', 'Ribbon paper', 'mtr', '100', '5', '500.00', '0', 'percent_wise', '0.00', '500.00', '2.5', '12.50', '2.5', '12.50', '5', '25.00', '525.00', '525.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '525.00', 'P10271218', 'P10-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (15, '2018-12-27', '2018-12-27', '2018-12-14', 'P12', 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '854120', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '201', 'Steel', 'nos', '150', '10', '1209.68', '0', 'percent_wise', '1500', '1500.00', '12', '145.16', '12', '145.16', '24', '290.32', '1500.00', '1500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1500.00', 'P11271218', 'P11-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (16, '2018-12-27', '2018-12-27', '2018-12-26', 'P13', 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '152', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '0', 'paint', 'ltr', '100', '2', '200.00', '0', 'percent_wise', '0.00', '200.00', '9', '18.00', '9', '18.00', '18', '36.00', '236.00', '236.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '236.00', 'P12271218', 'P12-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (17, '2018-12-27', '2018-12-27', '2018-12-19', 'P14', 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '15', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '203', 'Tissues paper', 'mtr', '150', '5', '750.00', '0', 'percent_wise', '0.00', '750.00', '12', '90.00', '12', '90.00', '24', '180.00', '930.00', '930.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '930.00', 'P14271218', 'P14-2018', 1, 1);
INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (18, '2018-12-27', '2018-12-27', '2018-12-07', 'P15', 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '8552323', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '201', 'Steel', 'nos', '150', '20', '2419.35', '0', 'percent_wise', '3000', '3000.00', '12', '290.32', '12', '290.32', '24', '580.65', '3000.00', '3000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '3000.00', 'P14271218', 'P14-2018', 1, 1);


#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS purchase_reports;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '2', '2018-11-16', 'P1', '2018-11-16', NULL, 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '8502', '2018-11-02', NULL, NULL, '202', 'Paper bundle', '2', '10', '2', '2381.40', NULL, NULL, NULL, NULL, NULL, '2381.40', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P1-2018', 'P1161118');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '3', '2018-11-16', 'P2', '2018-11-16', NULL, 3, 'Harish kumar', 'kumaren nagar, Namakkal road,, Erode, Tamil Nadu', '502', '2018-11-04', NULL, NULL, '203', 'Tissues paper', '1', '10', '1', '1860.00', NULL, NULL, NULL, NULL, NULL, '1860.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P2-2018', 'P2161118');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (6, '4', '2018-11-21', 'P3', '2018-11-21', NULL, 7, 'ganesh mill stores', 'ADDRESS1, ADDRESS2, COIMBATORE, TAMILNADU', '201', '2018-11-20', NULL, NULL, '001', 'SENIOR DELEX', '8', '2', '1', '17570.00', NULL, NULL, NULL, NULL, NULL, '17570.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P3-2018', 'P3211118');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (7, '5', '2018-11-29', 'P4', '2018-11-29', NULL, 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '111', '2018-11-29', NULL, NULL, '0', 'paint', '1', '1000', '1', '118000.00', NULL, NULL, NULL, NULL, NULL, '118000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P4-2018', 'P4291118');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (8, '1', '2018-12-10', 'P', '2018-11-16', NULL, 0, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '123', '2018-11-01', NULL, NULL, '201', 'Steel', '1', '10', '1', '3754.40', NULL, NULL, NULL, NULL, NULL, '3754.40', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (9, '1', '2018-12-10', 'P', '2018-11-16', NULL, 0, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '123', '2018-11-01', NULL, NULL, '203', 'Tissues paper', '5', '12', '5', '3754.40', NULL, NULL, NULL, NULL, NULL, '3754.40', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (10, '6', '2018-12-27', 'P5', '2018-12-27', NULL, 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '1040', '2018-12-04', NULL, NULL, '207', 'Reynolds pen', '1', '10', '1', '1180.00', NULL, NULL, NULL, NULL, NULL, '1180.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P5-2018', 'P5271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (11, '7', '2018-12-27', 'P6', '2018-12-27', NULL, 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '1525', '2018-12-19', NULL, NULL, '203', 'Tissues paper', '1', '10', '1', '1860.00', NULL, NULL, NULL, NULL, NULL, '1860.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P6-2018', 'P6271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (12, '8', '2018-12-27', 'P6', '2018-12-27', NULL, 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '8520', '2018-12-04', NULL, NULL, '203', 'Tissues paper', '1', '10', '1', '1860.00', NULL, NULL, NULL, NULL, NULL, '1860.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P6-2018', 'P6271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (13, '9', '2018-12-27', 'P7', '2018-12-27', NULL, 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '4101', '2018-12-04', NULL, NULL, '207', 'Reynolds pen', '1', '10', '1', '1180.00', NULL, NULL, NULL, NULL, NULL, '1180.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P7-2018', 'P7271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (14, '10', '2018-12-27', 'P7', '2018-12-27', NULL, 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '155', '2018-12-27', NULL, NULL, '0', 'paint', '1', '5', '5', '590.00', NULL, NULL, NULL, NULL, NULL, '590.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P7-2018', 'P7271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (15, '11', '2018-12-27', 'P9', '2018-12-27', NULL, 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '1562', '2018-12-19', NULL, NULL, '206', 'Colour paper', '1', '10', '1', '1000.00', NULL, NULL, NULL, NULL, NULL, '1000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P9-2018', 'P9271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (16, '12', '2018-12-27', 'P9', '2018-12-27', NULL, 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '741', '2018-12-04', NULL, NULL, '203', 'Tissues paper', '1', '10', '1', '1860.00', NULL, NULL, NULL, NULL, NULL, '1860.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P9-2018', 'P9271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (17, '13', '2018-12-27', 'P10', '2018-12-27', NULL, 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '74596', '2018-12-05', NULL, NULL, '207', 'Reynolds pen', '1', '10', '1', '1180.00', NULL, NULL, NULL, NULL, NULL, '1180.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P10-2018', 'P10271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (18, '14', '2018-12-27', 'P10', '2018-12-27', NULL, 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '1525', '2018-12-27', NULL, NULL, '205', 'Ribbon paper', '1', '5', '5', '525.00', NULL, NULL, NULL, NULL, NULL, '525.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P10-2018', 'P10271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (19, '15', '2018-12-27', 'P11', '2018-12-27', NULL, 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '854120', '2018-12-14', NULL, NULL, '201', 'Steel', '1', '10', '1', '1500.00', NULL, NULL, NULL, NULL, NULL, '1500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P11-2018', 'P11271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (20, '16', '2018-12-27', 'P12', '2018-12-27', NULL, 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '152', '2018-12-26', NULL, NULL, '0', 'paint', '1', '2', '2', '236.00', NULL, NULL, NULL, NULL, NULL, '236.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P12-2018', 'P12271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (21, '17', '2018-12-27', 'P14', '2018-12-27', NULL, 4, 'uma gowri', 'mariamman  temple, Near by city union bank, Salem, TamilNadu', '15', '2018-12-19', NULL, NULL, '203', 'Tissues paper', '1', '5', '9', '930.00', NULL, NULL, NULL, NULL, NULL, '930.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P14-2018', 'P14271218');
INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (22, '18', '2018-12-27', 'P14', '2018-12-27', NULL, 5, 'Ganesh kumar', 'kumaren street, Trichy road, THANJAVUR, Tamil Nadu', '8552323', '2018-12-07', NULL, NULL, '201', 'Steel', '1', '20', '3', '3000.00', NULL, NULL, NULL, NULL, NULL, '3000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P14-2018', 'P14271218');


#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS purchaseorder_details;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2018-11-16', '2018-11-16', '2018-11-16', 'Direct PO', 'P', '201', NULL, 0, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '207||205', 'Reynolds pen||Ribbon paper', 'nos||mtr', '100||100', '20||10', '20', '0', '2000.00||1000.00', '0||0', 'percent_wise', '||0.00', '2000.00||1000.00', '9||2.5', '180.00||25.00', '9||2.5', '180.00||25.00', '0||0', '0||0', '2360.00||1050.00', '3410.00', '', '0', '', '0', '', '0', '0', '', '', '0', '', '0', '', '0', '0', '', '0', '0', '1||1', '3410.00', 'P161118', 'P-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2018-11-16', '2018-11-16', '2018-11-16', 'Direct PO', 'P1', '302', NULL, 2, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '202', 'Paper bundle', 'mtr', '200', '10', '10', '0', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '180.00', '9', '180.00', '0', '0', '2360.00', '2360.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '2360.00', 'P1161118', 'P1-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (3, '2018-11-16', '2018-11-16', '2018-11-16', 'Direct PO', 'P2', '603', NULL, 1, 'Arul Murgan', '15th Gopala Puram, West , Raithina puram, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '205', 'Ribbon paper', 'mtr', '100', '2', '2', '0', '200.00', '0', 'percent_wise', '0.00', '200.00', '2.5', '5.00', '2.5', '5.00', '0', '0', '210.00', '210.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '210.00', 'P2161118', 'P2-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (4, '2018-11-27', '2018-11-27', '2018-11-27', 'Direct PO', 'P3', '1452', NULL, 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '202', 'Paper bundle', 'mtr', '200', '10', '10', '0', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '180.00', '9', '180.00', '0', '0', '2360.00', '2360.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '2360.00', 'P3271118', 'P3-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (5, '2018-11-27', '2018-11-27', '2018-11-27', 'Direct PO', 'P4', '6564', NULL, 2, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '202||203', 'Paper bundle||Tissues paper', 'mtr||mtr', '200||150', '5||8', '5||8', '0||0', '1000.00||1200.00', '0||0', 'percent_wise', '0.00||0.00', '1000.00||1200.00', '9||12', '90.00||144.00', '9||12', '90.00||144.00', '0||0', '0||0', '1180.00||1488.00', '2668.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '2668.00', 'P4271118', 'P4-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (6, '2018-11-30', '2018-11-30', '2018-11-30', 'Direct PO', 'P5', '45626', NULL, 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '202||205', 'Paper bundle||Ribbon paper', 'mtr||mtr', '200||100', '50||20', '50||20', '0||0', '10000.00||2000.00', '0||0', 'percent_wise', '0.00||0.00', '10000.00||2000.00', '9||2.5', '900.00||50.00', '9||2.5', '900.00||50.00', '0||0', '0||0', '11800.00||2100.00', '13900.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '13900.00', 'P5301118', 'P5-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (7, '2018-12-07', '2018-12-07', '2018-12-07', 'Direct PO', 'P6', '101', NULL, 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '203', 'Tissues paper', 'mtr', '150', '10', '10', '0', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '12', '180.00', '12', '180.00', '0', '0', '1860.00', '1860.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1860.00', 'P6071218', 'P6-2018', 1, 1);
INSERT INTO purchaseorder_details (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (8, '2018-12-27', '2018-12-27', '2018-12-27', 'Direct PO', 'P7', '152632', NULL, 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '202', 'Paper bundle', 'mtr', '200', '5', '5', '0', '1000.00', '0', 'percent_wise', '0.00', '1000.00', '9', '90.00', '9', '90.00', '0', '0', '1180.00', '1180.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1180.00', 'P7271218', 'P7-2018', 1, 1);


#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS purchaseorder_reports;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '2', '2018-11-16', 'Direct PO', 'P1', '302', NULL, '2018-11-16', NULL, 2, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', '0', '2018-11-16', NULL, NULL, '202', 'Paper bundle', 'mtr', '2', '10', '10', '0', '2360.00', '2360.00', NULL, NULL, NULL, NULL, NULL, '2360.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P1-2018', 'P1161118');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '1', '2018-11-16', '', 'P', '201', NULL, '2018-11-16', NULL, 0, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', NULL, '2018-11-16', NULL, NULL, '207', 'Reynolds pen', 'nos', '1', '20', NULL, '', '2360.00', '3410.00', NULL, NULL, NULL, NULL, NULL, '3410.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P-2018', 'P161118');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (5, '1', '2018-11-16', '', 'P', '201', NULL, '2018-11-16', NULL, 0, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', NULL, '2018-11-16', NULL, NULL, '205', 'Ribbon paper', 'mtr', '0', '10', NULL, '', '1050.00', '3410.00', NULL, NULL, NULL, NULL, NULL, '3410.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P-2018', 'P161118');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (6, '3', '2018-11-16', 'Direct PO', 'P2', '603', NULL, '2018-11-16', NULL, 1, 'Arul Murgan', '15th Gopala Puram, West , Raithina puram, Coimbatore, Tamil Nadu', '0', '2018-11-16', NULL, NULL, '205', 'Ribbon paper', 'mtr', '1', '2', '2', '0', '210.00', '210.00', NULL, NULL, NULL, NULL, NULL, '210.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P2-2018', 'P2161118');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (7, '4', '2018-11-27', 'Direct PO', 'P3', '1452', NULL, '2018-11-27', NULL, 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '0', '2018-11-27', NULL, NULL, '202', 'Paper bundle', 'mtr', '2', '10', '10', '0', '2360.00', '2360.00', NULL, NULL, NULL, NULL, NULL, '2360.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P3-2018', 'P3271118');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (8, '5', '2018-11-27', 'Direct PO', 'P4', '6564', NULL, '2018-11-27', NULL, 2, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', '0', '2018-11-27', NULL, NULL, '202', 'Paper bundle', 'mtr', '2', '5', '5', '0', '1180.00', '2668.00', NULL, NULL, NULL, NULL, NULL, '2668.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P4-2018', 'P4271118');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (9, '5', '2018-11-27', 'Direct PO', 'P4', '6564', NULL, '2018-11-27', NULL, 2, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', '0', '2018-11-27', NULL, NULL, '203', 'Tissues paper', 'mtr', '0', '8', '8', '0', '1488.00', '2668.00', NULL, NULL, NULL, NULL, NULL, '2668.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P4-2018', 'P4271118');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (10, '6', '2018-11-30', 'Direct PO', 'P5', '45626', NULL, '2018-11-30', NULL, 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '0', '2018-11-30', NULL, NULL, '202', 'Paper bundle', 'mtr', '2', '50', '50', '0', '11800.00', '13900.00', NULL, NULL, NULL, NULL, NULL, '13900.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P5-2018', 'P5301118');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (11, '6', '2018-11-30', 'Direct PO', 'P5', '45626', NULL, '2018-11-30', NULL, 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '0', '2018-11-30', NULL, NULL, '205', 'Ribbon paper', 'mtr', '0', '20', '20', '0', '2100.00', '13900.00', NULL, NULL, NULL, NULL, NULL, '13900.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P5-2018', 'P5301118');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (12, '7', '2018-12-07', 'Direct PO', 'P6', '101', NULL, '2018-12-07', NULL, 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '0', '2018-12-07', NULL, NULL, '203', 'Tissues paper', 'mtr', '1', '10', '10', '0', '1860.00', '1860.00', NULL, NULL, NULL, NULL, NULL, '1860.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P6-2018', 'P6071218');
INSERT INTO purchaseorder_reports (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (13, '8', '2018-12-27', 'Direct PO', 'P7', '152632', NULL, '2018-12-27', NULL, 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', '0', '2018-12-27', NULL, NULL, '202', 'Paper bundle', 'mtr', '2', '5', '5', '0', '1180.00', '1180.00', NULL, NULL, NULL, NULL, NULL, '1180.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P7-2018', 'P7271218');


#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS quotation_details;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO quotation_details (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2018-11-21', '2018-11-21', NULL, NULL, 'Q', 6, 'STAND MILL STORS', '93/32-a av theater annadueru road , COIMBATORE, TAMILNADU', NULL, NULL, 'intrastate', NULL, NULL, NULL, '001||207', 'SENIOR DELEX||Reynolds pen', NULL, 'nos||nos', '850||100', '1||2', '808.54||200.00', '0||0', '850.00||0.00', '850.00||200.00', '2.5||9', '20.73||18.00', '2.5||9', '20.73||18.00', '5||18', '||', '850.00||236.00', '1086.00', NULL, NULL, '0', NULL, '1086.00', NULL, NULL, 1, 1);
INSERT INTO quotation_details (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2018-11-22', '2018-11-22', NULL, NULL, 'Q1', 6, 'STAND MILL STORS', '93/32-a av theater annadueru road , COIMBATORE, TAMILNADU, ', NULL, NULL, 'intrastate', NULL, NULL, NULL, '202||205', 'Paper bundle||Ribbon paper', NULL, 'mtr||mtr', '200||100', '1||1', '200.00||100.00', '0||0', '0.00||0.00', '200.00||100.00', '9||2.5', '18.00||2.50', '9||2.5', '18.00||2.50', '18||5', '||', '236.00||105.00', '341.00', NULL, NULL, '0', NULL, '341.00', NULL, NULL, 1, 1);
INSERT INTO quotation_details (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (3, '2018-11-29', '2018-11-29', NULL, NULL, 'Q2', 1, 'kumareesh', ', West , Raithina puram, Coimbatore, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '111', 'fanta orange', NULL, 'ltr', '1000', '10', '10000.00', '0', '0.00', '10000.00', '9', '900.00', '9', '900.00', '18', '', '11800.00', '11800.00', NULL, NULL, '0', NULL, '11800.00', NULL, NULL, 1, 1);
INSERT INTO quotation_details (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (4, '2018-11-29', '2018-11-29', NULL, NULL, 'Q3', 2, 'chandrasekar', '12th, lakshmi puram Street,, West main road, coimbatore., Tamil nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '0', 'paint', NULL, 'ltr', '110', '10', '1100.00', '0', '0.00', '1100.00', '9', '99.00', '9', '99.00', '18', '', '1298.00', '1298.00', NULL, NULL, '0', NULL, '1298.00', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS sales_return;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO sales_return (`id`, `date`, `returndate`, `types`, `time`, `dateofissue`, `customername`, `customerid`, `supplierid`, `gsttype`, `suppliername`, `openingbal`, `outstandingamount`, `returnno`, `description`, `invoiceno`, `purchaseno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `uom`, `amount`, `discount`, `taxableamount`, `discountamount`, `cgst`, `cgstamount`, `sgst`, `sgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `grandtotal`, `status`) VALUES (1, '2018-11-16', '2018-11-16', 'Credit', '05:15:12 PM', '2018-11-16', '-', '-', '5', 'intrastate', 'Ganesh kumar', '3754.4', NULL, 'C001', 'It is damgeded', '-', 'P', NULL, '201||203', 'Steel||Tissues paper', '150||150', '2||3', 'nos||mtr', '241.94||450.00', '0||', '300.00||450.00', '300.00||0', '12||12', '29.03||54.00', '12||12', '29.03||54.00', '24||24', '||', '300.00||558.00', '880.40', '10', '2', '0.20', '2', '0.20', '4', '0.40', '10.40', '10', '10', '1.00', '10', '1.00', '20', '2.00', '12.00', '0', '880.40', '1');
INSERT INTO sales_return (`id`, `date`, `returndate`, `types`, `time`, `dateofissue`, `customername`, `customerid`, `supplierid`, `gsttype`, `suppliername`, `openingbal`, `outstandingamount`, `returnno`, `description`, `invoiceno`, `purchaseno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `uom`, `amount`, `discount`, `taxableamount`, `discountamount`, `cgst`, `cgstamount`, `sgst`, `sgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `grandtotal`, `status`) VALUES (2, '2018-11-21', '2018-11-21', 'Credit', '09:04:39 PM', '2018-11-21', '-', '-', '7', 'intrastate', 'ganesh mill stores', '5070', NULL, 'C002', 'damage', '-', 'P3', NULL, '001', 'SENIOR DELEX', '8500', '1', 'nos', '8095.24', '0', '8500.00', '8500.00', '2.5', '202.38', '2.5', '202.38', '5', '', '8500.00', '9070.00', '500', '05', '25.00', '05', '25.00', '10', '50.00', '550.00', '20', '0', '0.00', '0', '0.00', '0', '0.00', '20.00', '0', '9070.00', '1');
INSERT INTO sales_return (`id`, `date`, `returndate`, `types`, `time`, `dateofissue`, `customername`, `customerid`, `supplierid`, `gsttype`, `suppliername`, `openingbal`, `outstandingamount`, `returnno`, `description`, `invoiceno`, `purchaseno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `uom`, `amount`, `discount`, `taxableamount`, `discountamount`, `cgst`, `cgstamount`, `sgst`, `sgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `grandtotal`, `status`) VALUES (3, '2018-12-28', '2018-12-28', 'Credit', '01:02:20 PM', '2018-12-28', '-', '-', '5', 'intrastate', 'Ganesh kumar', '82010', NULL, 'C003', 'returns', '-', 'P6', NULL, '203', 'Tissues paper', '150', '5', 'mtr', '750.00', '0', '750.00', '0.00', '12', '90.00', '12', '90.00', '24', '', '930.00', '930.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '930.00', '1');
INSERT INTO sales_return (`id`, `date`, `returndate`, `types`, `time`, `dateofissue`, `customername`, `customerid`, `supplierid`, `gsttype`, `suppliername`, `openingbal`, `outstandingamount`, `returnno`, `description`, `invoiceno`, `purchaseno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `uom`, `amount`, `discount`, `taxableamount`, `discountamount`, `cgst`, `cgstamount`, `sgst`, `sgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `grandtotal`, `status`) VALUES (4, '2018-12-28', '2018-12-28', 'Credit', '01:25:43 PM', '2018-12-28', '-', '-', '5', 'intrastate', 'Ganesh kumar', '81080', NULL, 'C004', 'returns', '-', 'P7', NULL, '207', 'Reynolds pen', '100', '1', 'nos', '100.00', '0', '100.00', '0.00', '9', '9.00', '9', '9.00', '18', '', '118.00', '118.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '118.00', '1');


#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS stock;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (1, '2018-12-29', '201', NULL, '12', '12', '24', 'Steel', '20', '150', '20', '', '', '-98', NULL, NULL, '', '2018-12-27', 'Inclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (2, '2018-12-29', '202', NULL, '9', '9', '18', 'Paper bundle', '10', '200', '10', '', '', '-16', NULL, NULL, '', '2018-11-16', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (3, '2018-12-29', '203', NULL, '12', '12', '24', 'Tissues paper', '5', '150', '5', '', '', '25', NULL, NULL, '', '2018-12-27', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (4, '2018-11-21', '001', NULL, '2.5', '2.5', '5', 'SENIOR DELEX', '2', '8500', '2', '', '', '0', NULL, NULL, '', '2018-11-21', 'Inclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (5, '2018-12-29', '111', NULL, '9', '9', '18', 'fanta orange', '10000', '1000', '10000', '', '1', '9895', NULL, NULL, '', '2018-11-27', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (6, '2018-12-27', '0', NULL, '9', '9', '18', 'paint', '2', '100', '2', '', '1', '1082', NULL, NULL, '', '2018-12-27', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (7, '2018-12-05', '789', NULL, '9', '9', '18', 'bush', '1000', '50', '1000', '', '1', '1000', NULL, NULL, '', '2018-12-05', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (8, '2018-12-29', '207', NULL, '9', '9', '18', 'Reynolds pen', '10', '100', '10', '', '', '29', NULL, NULL, '', '2018-12-27', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (9, '2018-12-29', '206', NULL, '2.5', '2.5', '5', 'Colour paper', '10', '100', '10', '', '', '-15', NULL, NULL, '', '2018-12-27', 'Inclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (10, '2018-12-27', '205', NULL, '2.5', '2.5', '5', 'Ribbon paper', '5', '100', '5', '', '', '5', NULL, NULL, '', '2018-12-27', 'Exclusive');


#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS stock_reports;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (2, '2018-11-16', '202', NULL, 'Paper bundle', NULL, '10', '', '2018-11-16', '2', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (3, '2018-11-16', '203', NULL, 'Tissues paper', NULL, '10', '', '2018-11-16', '3', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (6, '2018-11-21', '001', NULL, 'SENIOR DELEX', NULL, '2', '', '2018-11-21', '4', NULL, 'Inclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (7, '2018-11-27', '111', NULL, 'fanta orange', '1', '10000', 'FromAddStock', '2018-11-27', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (8, '2018-11-29', '0', NULL, 'paint', '1', '100', 'FromAddStock', '2018-11-29', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (9, '2018-11-29', '0', NULL, 'paint', NULL, '1000', '', NULL, '5', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (10, '2018-12-05', '789', NULL, 'bush', '1', '1000', 'FromAddStock', '2018-12-05', NULL, NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (11, '2018-12-10', '201', NULL, 'Steel', NULL, '10', '', '2018-11-16', '1', NULL, 'Inclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (12, '2018-12-10', '203', NULL, 'Tissues paper', NULL, '12', '', '2018-11-16', '1', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (13, '2018-12-27', '207', NULL, 'Reynolds pen', NULL, '10', '', '2018-12-27', '6', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (14, '2018-12-27', '203', NULL, 'Tissues paper', NULL, '10', '', NULL, '7', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (15, '2018-12-27', '203', NULL, 'Tissues paper', NULL, '10', '', NULL, '8', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (16, '2018-12-27', '207', NULL, 'Reynolds pen', NULL, '10', '', NULL, '9', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (17, '2018-12-27', '0', NULL, 'paint', NULL, '5', '', NULL, '10', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (18, '2018-12-27', '206', NULL, 'Colour paper', NULL, '10', '', '2018-12-27', '11', NULL, 'Inclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (19, '2018-12-27', '203', NULL, 'Tissues paper', NULL, '10', '', NULL, '12', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (20, '2018-12-27', '207', NULL, 'Reynolds pen', NULL, '10', '', NULL, '13', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (21, '2018-12-27', '205', NULL, 'Ribbon paper', NULL, '5', '', '2018-12-27', '14', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (22, '2018-12-27', '201', NULL, 'Steel', NULL, '10', '', NULL, '15', NULL, 'Inclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (23, '2018-12-27', '0', NULL, 'paint', NULL, '2', '', NULL, '16', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (24, '2018-12-27', '203', NULL, 'Tissues paper', NULL, '5', '', NULL, '17', NULL, 'Exclusive');
INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (25, '2018-12-27', '201', NULL, 'Steel', NULL, '20', '', NULL, '18', NULL, 'Inclusive');


#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS tbl_person;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS uom;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (1, '2018-11-16', 'nos', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (2, '2018-11-16', 'mtr', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (3, '2018-11-16', 'gram', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (4, '2018-11-21', 'NOS', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (5, '2018-11-27', 'ltr', 1);
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES (6, '2018-11-29', 'pcs', 1);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS user_menu;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS vat_details;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (1, '2018-11-16', 'gst', '24', 'gst @ 24 %', '12', '12', '24', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (2, '2018-11-16', 'gst', '18', 'gst @ 18 %', '9', '9', '18', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (3, '2018-11-16', 'gst', '32', 'gst @ 32 %', '16', '16', '32', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (4, '2018-11-16', 'gst', '5', 'gst @ 5 %', '2.5', '2.5', '5', '1');
INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (6, '2018-11-29', 'gst', '12', 'gst @ 12 %', '6', '6', '12', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS vendor_details;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS voucher;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (1, '2018-11-21', 'R', 7, 'ganesh mill stores', '2018-11-21', 'receipt', '', 'Cash', '0', '', '', '0', '', '15000', 'Cash', NULL, NULL, '15000', '15000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (2, '2018-11-27', 'R1', 2, 'chandrasekar', '2018-11-27', 'payment', 'k', 'Cash', '0', '', '', '0', '', '10000', 'Cash', NULL, NULL, '10000', '10000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (3, '2018-11-29', 'R2', 2, 'chandrasekar', '2018-11-29', 'payment', 'k', 'Cash', '0', '', '', '0', '', '10000', 'Cash', NULL, NULL, '10000', '10000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (4, '2018-12-11', 'R3', 2, 'chandrasekar', '2018-12-11', 'payment', '', 'Cheque', 'INDIAN OVERSEAS', '123233', '20000', '0', '', '', 'Cheque INDIAN OVERSEAS 123233', NULL, '25-12-2018', '20000', '20000', '1', 0);
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `otherBank`) VALUES (5, '2018-12-11', 'R4', 5, 'Ganesh kumar', '2018-12-11', 'receipt', '', 'Cash', '0', '', '', '0', '', '50000', 'Cash', NULL, NULL, '50000', '50000', '1', 0);


